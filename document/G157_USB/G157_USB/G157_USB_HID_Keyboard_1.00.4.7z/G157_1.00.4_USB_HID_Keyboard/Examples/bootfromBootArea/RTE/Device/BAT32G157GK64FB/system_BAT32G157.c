/**************************************************************************//**
 * @file     system_BAT32G157.c
 * @brief    CMSIS Cortex-M0+ Device Peripheral Access Layer Source File for
 *           Device BAT32G157
 * @version  1.0.0
 * @date     2020/9/15
 ******************************************************************************/
/*
 * Copyright (c) 2009-2018 Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdint.h>
#include "BAT32G157.h"


/** @addtogroup Configuration_of_User_Option_Byte
  * @{
  */

typedef enum {
  HOCO_FREQ_64MHZ = 0xF8, 	/*!< fHOCO = 64MHz, fIH = 64MHz  	*/
  HOCO_FREQ_48MHZ = 0xF0, 	/*!< fHOCO = 48MHz, fIH = 48MHz  	*/
  HOCO_FREQ_32MHZ = 0xE8, 	/*!< fHOCO = 32MHz, fIH = 32MHz  	*/
  HOCO_FREQ_24MHZ = 0xE0, 	/*!< fHOCO = 24MHz, fIH = 24MHz  	*/
  HOCO_FREQ_16MHZ = 0xE9, 	/*!< fHOCO = 32MHz, fIH = 16MHz  	*/
  HOCO_FREQ_12MHZ = 0xE1, 	/*!< fHOCO = 24MHz, fIH = 12MHz  	*/
  HOCO_FREQ_8MHZ  = 0xEA, 	/*!< fHOCO = 32MHz, fIH =  8MHz  	*/
  HOCO_FREQ_6MHZ  = 0xE2, 	/*!< fHOCO = 24MHz, fIH =  6MHz  	*/
  HOCO_FREQ_4MHZ  = 0xEB, 	/*!< fHOCO = 32MHz, fIH =  4MHz  	*/
  HOCO_FREQ_3MHZ  = 0xE3, 	/*!< fHOCO = 24MHz, fIH =  3MHz  	*/
  HOCO_FREQ_2MHZ  = 0xEC, 	/*!< fHOCO = 32MHz, fIH =  2MHz  	*/
  HOCO_FREQ_1MHZ  = 0xED  	/*!< fHOCO = 32MHz, fIH =  1MHz  	*/
} hoco_freq_t;

/*----------------------------------------------------------------------------
  User Option Byte 
 *----------------------------------------------------------------------------*/
/* ToDo: add here your necessary defines for device initialization
         following is an example for different system frequencies */


/*----------------------------------------------------------------------------
  System Core Clock Variable
 *----------------------------------------------------------------------------*/
/* ToDo: initialize SystemCoreClock with the system core clock frequency value
         achieved after system intitialization.
         This means system core clock frequency after call to SystemInit() */
uint32_t SystemCoreClock;  		/* System Clock Frequency (Core Clock)*/



/*----------------------------------------------------------------------------
  Clock functions
 *----------------------------------------------------------------------------*/
uint32_t CLK_GetHocoFreq(void)
{

  uint32_t freq;
  uint8_t  frqsel  = (*(uint8_t *)0x000000C2U);
           frqsel &= 0xF8;  	/* Mask the lower 3 bits */
           frqsel |= CGC->HOCODIV;	/* Refer the value of HOCODIV */ 
		   
  freq = 1000000U;  /* fIH = 1MHz except for the following cases */
		
  switch(frqsel)
  {
      case HOCO_FREQ_64MHZ: 
          freq = 64000000U; 	/* fIH = 64MHz 	*/
          break;
      case HOCO_FREQ_48MHZ: 
          freq = 48000000U; 	/* fIH = 48MHz 	*/
          break;
      case HOCO_FREQ_32MHZ: 
          freq = 32000000U; 	/* fIH = 32MHz 	*/
          break;
      case HOCO_FREQ_24MHZ: 
          freq = 24000000U; 	/* fIH = 24MHz 	*/
          break;
      case HOCO_FREQ_16MHZ: 
          freq = 16000000U; 	/* fIH = 16MHz 	*/
          break;
      case HOCO_FREQ_12MHZ: 
          freq = 12000000U; 	/* fIH = 12MHz 	*/
          break;
      case HOCO_FREQ_8MHZ: 
          freq = 8000000U; 	/* fIH = 8MHz 	*/
          break;
      case HOCO_FREQ_6MHZ: 
          freq = 6000000U; 	/* fIH = 6MHz 	*/
          break;
      case HOCO_FREQ_4MHZ: 
          freq = 4000000U; 	/* fIH = 4MHz 	*/
          break;
      case HOCO_FREQ_3MHZ: 
          freq = 3000000U; 	/* fIH = 3MHz 	*/
          break;
      case HOCO_FREQ_2MHZ: 
          freq = 2000000U; 	/* fIH = 2MHz 	*/
          break;
      case HOCO_FREQ_1MHZ: 
          freq = 1000000U; 	/* fIH = 1MHz 	*/
          break;
  }

  return(freq);
}

void SystemCoreClockUpdate (void)            /* Get Core Clock Frequency      */
{
/* ToDo: add code to calculate the system frequency based upon the current
         register settings.
         This function can be used to retrieve the system core clock frequeny
         after user changed register sittings. */
  SystemCoreClock = CLK_GetHocoFreq();
}

void SystemInit (void)
{
/* ToDo: add code to initialize the system
         do not use global variables because this function is called before
         reaching pre-main. RW section maybe overwritten afterwards. */
  SystemCoreClock = CLK_GetHocoFreq();

  /* RAM Parity Error Reset Disable */
  SAF->RPECTL = 0x80U;

  /* NVIC Clear Pending IRQ */
  NVIC->ICPR[0U] = 0xFFFFFFFF;

  /* NVIC Enable IRQs */
  NVIC->ISER[0U] = 0xFFFFFFFF;

  /* NVIC Lower Priority */
  NVIC->IP[0U] = 0xC0C0C0C0;
  NVIC->IP[1U] = 0xC0C0C0C0;
  NVIC->IP[2U] = 0xC0C0C0C0;
  NVIC->IP[3U] = 0xC0C0C0C0;
  NVIC->IP[4U] = 0xC0C0C0C0;
  NVIC->IP[5U] = 0xC0C0C0C0;
  NVIC->IP[6U] = 0xC0C0C0C0;
  NVIC->IP[7U] = 0xC0C0C0C0;

  /* restart watchdog timer */
  WDT->WDTE = 0xACU;   
}
