/*******************************************************************************
 * File Name    : usb_pcdc_descriptor.c
 * Description  : USB PCDC Descriptor data.
 *******************************************************************************/

/******************************************************************************
 Includes   <System Includes> , "Project Includes"
 ******************************************************************************/

#include "usb_basic_mini_if.h"
#include "usb_pcdc_apl_config.h"

/******************************************************************************
 Macro definitions
 ******************************************************************************/

/* bcdUSB */
#define USB_BCDNUM                      (0x0200u)
/* Release Number */
#define USB_RELEASE                     (0x0100u)
/* DCP max packet size */
#define USB_DCPMAXP                     (64u)
/* Configuration number */
#define USB_CONFIGNUM                   (1u)
/* Vendor ID */
#define USB_VENDORID                    (0x12D1u)
/* Product ID */
#define USB_PRODUCTID                   (0x1091u)

/* Miscellaneous Device Class */
#define USB_MISC_CLASS                  (0xEF)
/* Common Class */
#define USB_COMMON_CLASS                (0x02)
/* Interface Association Descriptor */
#define USB_IAD_DESC                    (0x01)
/* Interface Association Descriptor Type */
#define USB_IAD_TYPE                    (0x0B)

/* ----- Subclass Codes ----- */
#define USB_IFSUB_NOBOOT                ((uint8_t)0x00)   /* No Subclass */
#define USB_IFSUB_BOOT                  ((uint8_t)0x01)   /* Boot Interface Subclass */

#define USB_DT_TYPE_HIDDESCRIPTOR       ((uint8_t)0x21)   /* HID descriptor type */

/* Class-Specific Configuration Descriptors */
#define     USB_PCDC_CS_INTERFACE                               (0x24u)

/* bDescriptor SubType in Communications Class Functional Descriptors */
/* Header Functional Descriptor */
#define     USB_PCDC_DT_SUBTYPE_HEADER_FUNC                     (0x00u)
/* Call Management Functional Descriptor. */
#define     USB_PCDC_DT_SUBTYPE_CALL_MANAGE_FUNC                (0x01u)
/* Abstract Control Management Functional Descriptor. */
#define     USB_PCDC_DT_SUBTYPE_ABSTRACT_CTR_MANAGE_FUNC        (0x02u)
/* Union Functional Descriptor */
#define     USB_PCDC_DT_SUBTYPE_UNION_FUNC                      (0x06u)

/* Communications Class Subclass Codes */
#define     USB_PCDC_CLASS_SUBCLASS_CODE_ABS_CTR_MDL            (0x02u)

/* USB Class Definitions for Communications Devices Specification
 release number in binary-coded decimal. */
#define     USB_PCDC_BCD_CDC          (0x0110u)

/* Descriptor length */
#define USB_CFG_LEN										(115u)
#define USB_PCDC_QD_LEN               (10u)
#define USB_PCDC_CD1_LEN              (67u)
#define STRING_DESCRIPTOR0_LEN        (4u)
#define STRING_DESCRIPTOR1_LEN        (20u)
#define STRING_DESCRIPTOR2_LEN        (46u)
#define STRING_DESCRIPTOR3_LEN        (46u)
#define STRING_DESCRIPTOR4_LEN        (22u)
#define STRING_DESCRIPTOR5_LEN        (18u)
#define STRING_DESCRIPTOR6_LEN        (28u)

#if OPERATION_MODE == USB_ECHO
    #define USB_IFPROTOCOL      (USB_IFPRO_NONE)
    #define ITEM_LEN            (34)
    #define MXPS                (64)
    #define NUM_EP              (2)
#else   /* OPERATION_MODE == USB_ECHO */
    #define USB_IFPROTOCOL      (USB_IFPRO_KBD)
    #define ITEM_LEN            (76)
    #define MXPS                (8)
    #define NUM_EP              (1)
#endif

/*******************************************************************************
 Typedef definitions
 ******************************************************************************/

/*******************************************************************************
 Exported global variables (to be accessed by other files)
 ******************************************************************************/

/* Standard Device Descriptor */
uint8_t g_apl_device[USB_DD_BLENGTH + ( USB_DD_BLENGTH % 2)] =
{
    USB_DD_BLENGTH,                                     /*  0:bLength */
    USB_DT_DEVICE,                                      /*  1:bDescriptorType */
    (USB_BCDNUM & (uint8_t) 0xffu),                     /*  2:bcdUSB_lo */
    ((uint8_t) (USB_BCDNUM >> 8) & (uint8_t) 0xffu),    /*  3:bcdUSB_hi */
    USB_MISC_CLASS,                                     /*  4:bDeviceClass */
    USB_COMMON_CLASS,                                   /*  5:bDeviceSubClass */
    USB_IAD_DESC,                                       /*  6:bDeviceProtocol */
    (uint8_t) USB_DCPMAXP,                              /*  7:bMAXPacketSize(for DCP) */
    (USB_VENDORID & (uint8_t) 0xffu),                   /*  8:idVendor_lo */
    ((uint8_t) (USB_VENDORID >> 8) & (uint8_t) 0xffu),  /*  9:idVendor_hi */
    ((uint16_t) USB_PRODUCTID & (uint8_t) 0xffu),       /* 10:idProduct_lo */
    ((uint8_t) (USB_PRODUCTID >> 8) & (uint8_t) 0xffu), /* 11:idProduct_hi */
    (USB_RELEASE & (uint8_t) 0xffu),                    /* 12:bcdDevice_lo */
    ((uint8_t) (USB_RELEASE >> 8) & (uint8_t) 0xffu),   /* 13:bcdDevice_hi */
    1,                                                  /* 14:iManufacturer */
    2,                                                  /* 15:iProduct */
    6,                                                  /* 16:iSerialNumber */
    USB_CONFIGNUM /* 17:bNumConfigurations */
};

/* Configuration Or Other_Speed_Configuration Descriptor*/
uint8_t g_apl_configuration[USB_CFG_LEN +( USB_CFG_LEN % 2)] =
{
    USB_CD_BLENGTH,                 /*  0:bLength */
    USB_DT_CONFIGURATION,           /*  1:bDescriptorType */
    USB_CFG_LEN % 256,         			/*  2:wTotalLength(L) */
    USB_CFG_LEN / 256,         			/*  3:wTotalLength(H) */
    3,                              /*  4:bNumInterfaces */
    1,                              /*  5:bConfigurationValue */
    0,                              /*  6:iConfiguration */
    USB_CF_RESERVED, 								/*  7:bmAttributes */
    0xFA,                       		/*  8:MAXPower (500mA unit) */
	
		/* Interface Association Descriptor (IAD) */
    0x08,                           /*  0:bLength */
    USB_IAD_TYPE,                   /*  1:bDescriptorType */
    0x00,                           /*  2:bFirstInterface */
    0x01,                           /*  3:bInterfaceCount */
    USB_IFCLS_HID,                  /*  4:bFunctionClass  */
    USB_IFSUB_NOBOOT, 							/*  5:bFunctionSubClass */
    0x00,                           /*  6:bFunctionProtocol */
    0x00,                           /*  7:iFunction */
	
		/* Interface Descriptor */
    USB_ID_BLENGTH,                 /*  0:bLength */
    USB_DT_INTERFACE,               /*  1:bDescriptor */
    0,                              /*  2:bInterfaceNumber */
    0,                              /*  3:bAlternateSetting */
    2,                              /*  4:bNumEndpoints */
    USB_IFCLS_HID,                  /*  5:bInterfaceClass */
    USB_IFSUB_NOBOOT,  						  /*  6:bInterfaceSubClass */
    0,                              /*  7:bInterfaceProtocol */
    0,                              /*  8:iInterface */
		
		/* HID Descriptor */
		9,                               /*  0:bLength */
		USB_DT_TYPE_HIDDESCRIPTOR,       /*  1:bDescriptor */
		0x11,                            /*  2:HID Ver */
		0x01,                            /*  3:HID Ver */
		0x00,                            /*  4:bCountryCode */
		0x01,                            /*  5:bNumDescriptors */
		0x22,                            /*  6:bDescriptorType */
		ITEM_LEN,                        /*  7:wItemLength(L) */
		0x00,                            /*  8:wItemLength(H) */
		
		/* Endpoint Descriptor 0 */
				USB_ED_BLENGTH,                                             /*  0:bLength */
				USB_DT_ENDPOINT,                                            /*  1:bDescriptorType */
				(uint8_t) (USB_EP_IN | USB_EP3),                            /*  2:bEndpointAddress */
				USB_EP_INT,                                                 /*  3:bmAttribute */
				MXPS,                                                       /*  4:wMaxPacketSize_lo */
				0,                                                          /*  5:wMaxPacketSize_hi */
				0x0A,                                                       /*  6:bInterval */
				#if OPERATION_MODE == USB_ECHO
				/* Endpoint Descriptor 1 */
				USB_ED_BLENGTH,                                             /*  0:bLength */
				USB_DT_ENDPOINT,                                            /*  1:bDescriptorType */
				(uint8_t) (USB_EP_OUT | USB_EP3),                           /*  2:bEndpointAddress */
				USB_EP_INT,                                                 /*  3:bmAttribute */
				MXPS,                                                       /*  4:wMaxPacketSize_lo */
				0,                                                          /*  5:wMaxPacketSize_hi */
				0x0A,                                                       /*  6:bInterval */
				#endif  /* OPERATION_MODE == USB_ECHO */
		
		
		/* Interface Association Descriptor (IAD) */
    0x08,                           /*  0:bLength */
    USB_IAD_TYPE,                   /*  1:bDescriptorType */
    0x01,                           /*  2:bFirstInterface */
    0x02,                           /*  3:bInterfaceCount */
    USB_IFCLS_CDCC,                 /*  4:bFunctionClass  */
    USB_PCDC_CLASS_SUBCLASS_CODE_ABS_CTR_MDL, 							/* 5:bFunctionSubClass */
    0x01,                           /*  6:bFunctionProtocol */	//laidi 00
    0x00,                           /*  7:iFunction */

    /* Interface Descriptor */
    USB_ID_BLENGTH,                 /*  0:bLength */
    USB_DT_INTERFACE,               /*  1:bDescriptor */
    1,                              /*  2:bInterfaceNumber */
    0,                              /*  3:bAlternateSetting */
    1,                              /*  4:bNumEndpoints */
    USB_IFCLS_CDCC,                 /*  5:bInterfaceClass */
    USB_PCDC_CLASS_SUBCLASS_CODE_ABS_CTR_MDL,   /*  6:bInterfaceSubClass */
    1,                              /*  7:bInterfaceProtocol */
    3,                              /*  8:iInterface */

    /* Communications Class Functional Descriptorss */
    5,                          /*  0:bLength */
    USB_PCDC_CS_INTERFACE,      /*  1:bDescriptorType */
    USB_PCDC_DT_SUBTYPE_HEADER_FUNC,    /*  2:bDescriptorSubtype */
    USB_PCDC_BCD_CDC % 256,     /*  3:bcdCDC_lo */
    USB_PCDC_BCD_CDC / 256,     /*  4:bcdCDC_hi */

    /* Communications Class Functional Descriptorss */
    4,                          /*  0:bLength */
    USB_PCDC_CS_INTERFACE,      /*  1:bDescriptorType */
    USB_PCDC_DT_SUBTYPE_ABSTRACT_CTR_MANAGE_FUNC,   /*  2:bDescriptorSubtype */
    2,                          /*  3:bmCapabilities */

    /* Communications Class Functional Descriptorss */
    5,                          /*  0:bLength */
    USB_PCDC_CS_INTERFACE,      /*  1:bDescriptorType */
    USB_PCDC_DT_SUBTYPE_UNION_FUNC, /*  2:bDescriptorSubtype */
    0,                          /*  3:bMasterInterface */
    1,                          /*  4:bSlaveInterface0 */

    /* Communications Class Functional Descriptorss */
    5,                          /*  0:bLength */
    USB_PCDC_CS_INTERFACE,      /*  1:bDescriptorType */
    USB_PCDC_DT_SUBTYPE_CALL_MANAGE_FUNC,   /*  2:bDescriptorSubtype */
    /* D1:1-Device can send/receive call management
     information over a Data Class interface. */
    /* D0:1-Device handles call management itself. */
    3,                          /*  3:bmCapabilities */
    1,                          /*  4:bDataInterface */

    /* Endpoint Descriptor 0 */
    7,                          /*  0:bLength */
    USB_DT_ENDPOINT,            /*  1:bDescriptorType */
    USB_EP_IN | USB_EP2,        /*  2:bEndpointAddress */
    USB_EP_INT,                 /*  3:bmAttribute */
    16,                         /*  4:wMAXPacketSize_lo */
    0,                          /*  5:wMAXPacketSize_hi */
    0x10,                       /*  6:bInterval */

    /* Interface Descriptor */
    USB_ID_BLENGTH,                 /*  0:bLength */
    USB_DT_INTERFACE,               /*  1:bDescriptor */
    2,                              /*  2:bInterfaceNumber */
    0,                              /*  3:bAlternateSetting */
    2,                              /*  4:bNumEndpoints */
    USB_IFCLS_CDCD,                 /*  5:bInterfaceClass */
    0,                              /*  6:bInterfaceSubClass */
    0,                              /*  7:bInterfaceProtocol */
    0,                              /*  8:iInterface */

    /* Endpoint Descriptor 0 */
    USB_ED_BLENGTH,             /*  0:bLength */
    USB_DT_ENDPOINT,            /*  1:bDescriptorType */
    USB_EP_IN | USB_EP1,        /*  2:bEndpointAddress */
    USB_EP_BULK,                /*  3:bmAttribute */
    64,                         /*  4:wMAXPacketSize_lo */
    0,                          /*  5:wMAXPacketSize_hi */
    0,                          /*  6:bInterval */

    /* Endpoint Descriptor 1 */
    USB_ED_BLENGTH,             /*  0:bLength */
    USB_DT_ENDPOINT,            /*  1:bDescriptorType */
    USB_EP_OUT | USB_EP1,       /*  2:bEndpointAddress */
    USB_EP_BULK,                /*  3:bmAttribute */
    64,                         /*  4:wMAXPacketSize_lo */
    0,                          /*  5:wMAXPacketSize_hi */
    0,                          /*  6:bInterval */
};

/*******************************************************************************
 Private global variables and functions
 ******************************************************************************/

/* String Descriptor */
static uint8_t gs_cdc_string_descriptor0[STRING_DESCRIPTOR0_LEN + ( STRING_DESCRIPTOR0_LEN % 2)] =
{
    /* UNICODE 0x0409 English (United States) */
    STRING_DESCRIPTOR0_LEN,     /*  0:bLength */
    USB_DT_STRING,              /*  1:bDescriptorType */
    0x09, 0x04                  /*  2:wLANGID[0] */
};

/* iManufacturer */
static uint8_t gs_cdc_string_descriptor1[STRING_DESCRIPTOR1_LEN + ( STRING_DESCRIPTOR1_LEN % 2)] =
{
    STRING_DESCRIPTOR1_LEN,     /*  0:bLength */
    USB_DT_STRING,              /*  1:bDescriptorType */
    'C', 0x00,                  /*  2:wLANGID[0] */
    'M', 0x00,
    'S', 0x00,
    'e', 0x00,
    'm', 0x00,
    'i', 0x00,
    'c', 0x00,
    'o', 0x00,
    'n', 0x00,
};

/* iProduct */
static uint8_t gs_cdc_string_descriptor2[STRING_DESCRIPTOR2_LEN + ( STRING_DESCRIPTOR2_LEN % 2)] =
{
    STRING_DESCRIPTOR2_LEN, /*  0:bLength */
    USB_DT_STRING,          /*  1:bDescriptorType */
    'C', 0x00,
    'D', 0x00,
    'C', 0x00,
    ' ', 0x00,
    'H', 0x00,
    'I', 0x00,
    'D', 0x00,
    ' ', 0x00,
    'C', 0x00,
    'o', 0x00,
    'm', 0x00,
    'p', 0x00,
    'o', 0x00,
    's', 0x00,
    'i', 0x00,
    't', 0x00,
    'e', 0x00,
    ' ', 0x00,
    'D', 0x00,
    'e', 0x00,
    'm', 0x00,
		'o', 0x00,
};

/* iInterface */
static uint8_t gs_cdc_string_descriptor3[STRING_DESCRIPTOR3_LEN + ( STRING_DESCRIPTOR3_LEN % 2)] =
{
    STRING_DESCRIPTOR3_LEN, /*  0:bLength */
    USB_DT_STRING,          /*  1:bDescriptorType */
    'C', 0x00,
    'o', 0x00,
    'm', 0x00,
    'm', 0x00,
    'u', 0x00,
    'n', 0x00,
    'i', 0x00,
    'c', 0x00,
    'a', 0x00,
    't', 0x00,
    'i', 0x00,
    'o', 0x00,
    'n', 0x00,
    's', 0x00,
    ' ', 0x00,
    'D', 0x00,
    'e', 0x00,
    'v', 0x00,
    'i', 0x00,
    'c', 0x00,
    'e', 0x00,
    's', 0x00
};

/* iConfiguration */
static uint8_t gs_cdc_string_descriptor4[STRING_DESCRIPTOR4_LEN + ( STRING_DESCRIPTOR4_LEN % 2)] =
{
    STRING_DESCRIPTOR4_LEN, /*  0:bLength */
    USB_DT_STRING,          /*  1:bDescriptorType */
    'F', 0x00,              /*  2:wLANGID[0] */
    'u', 0x00,
    'l', 0x00,
    'l', 0x00,
    '-', 0x00,
    'S', 0x00,
    'p', 0x00,
    'e', 0x00,
    'e', 0x00,
    'd', 0x00
};

/* iConfiguration */
static uint8_t gs_cdc_string_descriptor5[STRING_DESCRIPTOR5_LEN + ( STRING_DESCRIPTOR5_LEN % 2)] =
{
    STRING_DESCRIPTOR5_LEN, /*  0:bLength */
    USB_DT_STRING,          /*  1:bDescriptorType */
    'H', 0x00,              /*  2:wLANGID[0] */
    'i', 0x00,
    '-', 0x00,
    'S', 0x00,
    'p', 0x00,
    'e', 0x00,
    'e', 0x00,
    'd', 0x00
};

/* iSerialNumber */
static uint8_t gs_cdc_string_descriptor6[STRING_DESCRIPTOR6_LEN + ( STRING_DESCRIPTOR6_LEN % 2)] =
{
    STRING_DESCRIPTOR6_LEN, /*  0:bLength */
    USB_DT_STRING,          /*  1:bDescriptorType */
    '0', 0x00,              /*  2:wLANGID[0] */
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '0', 0x00,
    '1', 0x00,
};

/* String Descriptor */
uint8_t *gp_apl_string_table[] =
{
    gs_cdc_string_descriptor0,
    gs_cdc_string_descriptor1,
    gs_cdc_string_descriptor2,
    gs_cdc_string_descriptor3,
    gs_cdc_string_descriptor4,
    gs_cdc_string_descriptor5,
    gs_cdc_string_descriptor6
};


/************************************************************
 *  HID Report Discriptor for Echo mode                     *
 ************************************************************/
const uint8_t g_apl_report[] =
{
    0x06, 0xA0, 0xFF,                               /* Usage Page - Vendor defined*/
    0x09, 0x00,                                     /* Usage ID within this page (Vendor defined)*/
    0xA1, 0x01,                                     /* Collection App (Windows requires an Application Collection) */

    /* *** The INPUT REPORT *** */
    0x09, 0x00,                                     /* Usage ID within this page*/
    0x15, 0x00,                                     /* Logical Min 0 */
    0x26, 0xFF, 0x00,                               /* Logical Max 255 */
    0x75, 0x08,                                     /* Size 8 Bits (Each Field will be 8bits) */
    0x95, 0x40,                                     /* Count(Number of fields(bytes) in INPUT report) */
    0x81, 0x02,                                     /* Input Report - type variable data */

    /* *** The OUTPUR REPORT *** */
    0x09, 0x00,                                     /* Usage ID within this page (Vendor defined)*/
    0x15, 0x00,                                     /* Logical Min 0 */
    0x26, 0xFF, 0x00,                               /* Logical Max 255 */
    0x75, 0x08,                                     /* Size 8 Bits (Each Field will be 8bits) */
    0x95, 0x40,                                     /* Count(Number of fields(bytes) in OUTPUT report)*/
    0x91, 0x02,                                     /* Output Report - type variable data */
    0xC0,                                           /* End collection */
};

/******************************************************************************
 End  Of File
 ******************************************************************************/
