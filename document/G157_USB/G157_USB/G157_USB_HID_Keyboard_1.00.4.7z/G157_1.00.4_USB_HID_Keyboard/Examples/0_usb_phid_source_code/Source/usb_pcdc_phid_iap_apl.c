/******************************************************************************
 * File Name    : usb_phid_keyboard_apl.c
 * Description  : USB HID application code
 ******************************************************************************/

/*******************************************************************************
 Includes   <System Includes> , "Project Includes"
 ******************************************************************************/
#include "usb.h"
#include "usb_basic_mini_if.h"
#include "usb_pcdc_phid_apl.h"
#include "usb_iap_apl.h"
#include "usb_pcdc_apl_config.h"
#include "BAT32G157.h"
#include "fmc_user.h"

#if OPERATION_MODE == USB_ECHO

/*******************************************************************************
 Macro definitions
 ******************************************************************************/
 #define IN_EP_MAX_PKT_SIZE	 	 	64
 #define OUT_EP_MAX_PKT_SIZE	  64

/*******************************************************************************
 Typedef definitions
 ******************************************************************************/

/*******************************************************************************
 Exported global variables (to be accessed by other files)
 ******************************************************************************/

/*******************************************************************************
 Private global variables and functions
 ******************************************************************************/
#define BUFF_SIZE	0x40
static uint8_t  cdc_buf[BUFF_SIZE], hid_buf[BUFF_SIZE];
static usb_pcdc_linecoding_t gs_line_coding;

const static usb_descriptor_t gs_usb_descriptor =
{
    g_apl_device,                   /* Pointer to the device descriptor */
    g_apl_configuration,            /* Pointer to the configuration descriptor for Full-speed */
    gp_apl_string_table,             /* Pointer to the string descriptor table */
    NUM_STRING_DESCRIPTOR
};


//laidi Pipe number see 'g_usb_pstd_pipe_no_tbl'
#define PCDC_IN_PIPE				USB_PIPE2
#define PCDC_OUT_PIPE				USB_PIPE1
#define PCDC_IN_INT_PIPE		USB_PIPE8	//not use
#define PHID_IN_PIPE				USB_PIPE6
#define PHID_OUT_PIPE				USB_PIPE7


/******************************************************************************
  * Function Name: usb_main
  * Description  : Peripheral CDC application main process
  * Arguments    : none
  * Return Value : none
 ******************************************************************************/
usb_ctrl_t  ctrl;
usb_cfg_t   cfg;
uint8_t response_size;
void usb_main (void)
{
		usb_info_t  info;
    usb_err_t   ret_code = USB_SUCCESS;

    ctrl.type       = USB_PVND;
    cfg.usb_mode    = USB_PERI;
    /* Descriptor registration */
    cfg.p_usb_reg   = (usb_descriptor_t *)&gs_usb_descriptor;
    USB_Open(&ctrl, &cfg);

    /* Loop back between PC(TerminalSoft) and USB MCU */
    while (1)
    {
        switch (USB_GetEvent(&ctrl))
        {
						//���´�����ʾ ����CDC��HID�յ�����Ϣ
            case USB_STS_CONFIGURED :
								ctrl.type = USB_PVND;
								ctrl.pipe = PCDC_IN_PIPE;
								USB_PipeRead(&ctrl, cdc_buf, BUFF_SIZE);
						
								ctrl.pipe = PHID_IN_PIPE;
								USB_PipeRead(&ctrl, hid_buf, BUFF_SIZE);
								break;
            case USB_STS_WRITE_COMPLETE :
								ctrl.type = USB_PVND;
								if(ctrl.pipe == PCDC_OUT_PIPE)
								{
										ctrl.pipe = PCDC_IN_PIPE;
										USB_PipeRead(&ctrl, cdc_buf, BUFF_SIZE);
								}
								if(ctrl.pipe == PHID_OUT_PIPE)
								{
										ctrl.pipe = PHID_IN_PIPE;
										USB_PipeRead(&ctrl, hid_buf, BUFF_SIZE);
								}
                break;

            case USB_STS_READ_COMPLETE :
								ctrl.type = USB_PVND;
								if(ctrl.pipe == PCDC_IN_PIPE)
								{
									 ctrl.pipe = PCDC_OUT_PIPE;
									 USB_PipeWrite(&ctrl, cdc_buf, ctrl.size);
								}
								if(ctrl.pipe == PHID_IN_PIPE)
								{
									 ctrl.pipe = PHID_OUT_PIPE;
									 USB_PipeWrite(&ctrl, hid_buf, ctrl.size);
								}
                break;

            case USB_STS_REQUEST : /* Receive Class Request */
								//CDC Request
                if (USB_PCDC_SET_LINE_CODING == (ctrl.setup.type & USB_BREQUEST))
                {
                    ctrl.type = USB_REQUEST;
                    /* Receive Line coding parameter */
                    USB_Read(&ctrl, (uint8_t *) &gs_line_coding, LINE_CODING_LENGTH);
                }
                else if (USB_PCDC_GET_LINE_CODING == (ctrl.setup.type & USB_BREQUEST))
                {
                    ctrl.type = USB_REQUEST;
                    /* Send Line coding parameter */
                    USB_Write(&ctrl, (uint8_t *) &gs_line_coding, LINE_CODING_LENGTH);
                }
								
								//HID Request
								if (USB_GET_DESCRIPTOR == (ctrl.setup.type & USB_BREQUEST))
                {
                    if (USB_GET_REPORT_DESCRIPTOR == ctrl.setup.value)
                    {
                        /* Send ReportDescriptor */
                        ctrl.type = USB_REQUEST;
                        USB_Write(&ctrl, (uint8_t *)g_apl_report, 34);
                    }
                    else if (USB_GET_HID_DESCRIPTOR == ctrl.setup.value)
                    {
                        /* Configuration Discriptor address set. */
                        ctrl.type = USB_REQUEST;
                        USB_Write(&ctrl, (uint8_t *) &g_apl_configuration[26], 9);	//18, laidi HID Descriptor offset in config Descriptor
                    }
                    else
                    {
                        ctrl.status = USB_STALL;
                        ctrl.type = USB_REQUEST;
                        USB_Write(&ctrl, (uint8_t*)USB_NULL, (uint32_t)USB_NULL);
                    }
                }
								
                else
                {
                    ctrl.type = USB_REQUEST;
                    ctrl.status = USB_ACK;
                    USB_Write(&ctrl, (uint8_t*)USB_NULL, (uint32_t)USB_NULL);
                }

                break;

            case USB_STS_SUSPEND :
            case USB_STS_DETACH :
                #if defined(USE_LPW)
                /* Do Nothing */
                #endif /* defined(USE_LPW) */
                break;
						case USB_STS_NONE : /* No event */
								ret_code = USB_GetInformation(&info);

								if (USB_SUCCESS == ret_code)
								{
										if (USB_STS_CONFIGURED == info.status)
										{
											// do something here
											
										}
								}

								break;

            default :
                break;
        }

    }
} /* End of function usb_main() */
		
#endif  /* OPERATION_MODE == USB_ECHO */

/******************************************************************************
 End  Of File
 ******************************************************************************/

