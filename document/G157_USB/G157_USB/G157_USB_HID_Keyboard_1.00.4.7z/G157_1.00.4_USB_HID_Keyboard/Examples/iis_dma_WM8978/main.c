/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :  
* Device(s)    : BAT32G157
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/4/30
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <stdio.h>
#include "BAT32G157.h"
#include "userdefine.h"
#include "dma.h"
#include "spi.h"
#include "pcbz.h"
#include "iica.h"
#include "wm8978.h"
#include "ssie.h"
#include "ssi_api_if.h"

#include "spi_flash.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint32_t g_ticks;

uint8_t dummy;
uint16_t ssi_dma_dat;

uint16_t iistxbuff[2][512],iisrxbuff[512];

extern volatile uint32_t iisdmacount;

extern volatile uint32_t spihs1dmacount;



//=======================================================================
void delayMS(uint32_t n)
{
		g_ticks = n;
		while(g_ticks);
}

//=======================================================================
int main()
{
	uint32_t msCnt; 	// count value of 1ms
	uint32_t i;
	uint16_t spitemp;
	
//-----------------------------------------------------------------------
// Systick setting 
//-----------------------------------------------------------------------   
	g_ticks = 1000; 	// 1000ms
	SystemCoreClockUpdate();
	msCnt = SystemCoreClock / 1000;
	SysTick_Config(msCnt); 
	
//-----------------------------------------------------------------------
// WM8978 setting 
//----------------------------------------------------------------------- 	
	WM8978_Init();				//��ʼ��WM8978
	WM8978_HPvol_Set(40,40);	//������������
	WM8978_SPKvol_Set(60);		//������������
	WM8978_ADDA_Cfg(1,1);		//����ADC, DAC
	WM8978_Input_Cfg(1,1,0);	//��������ͨ��(MIC&LINE IN)
	WM8978_Output_Cfg(1,0);		//����DAC��� 
	WM8978_MIC_Gain(46);		//MIC�������� 
	WM8978_I2S_Cfg(2,0);		//�����ֱ�׼,16λ���ݳ���
	
//-----------------------------------------------------------------------
// SSI I2S Format transceive
//-----------------------------------------------------------------------
	PCBZ_Init(PCBZ_CHANNEL_0, PCBZ_FMAIN_2); // PA00/CLKBUZ0 Output AUDIO MCK 12MHz
	
	SPI1_MasterInit(SPI_MODE_0);
	SPI1_Start();
	
	SPIHS1->SPIC1 &= ~_0007_SPI_SLAVE_MODE;
	SPIHS1->SPIC1 |= _0004_SPI_SCK_fCLK_4;
	
	SPIHS1->SPIM1 &= ~_0004_SPI_LENGTH_16;
	SPIHS1->SPIM1 &= ~_0002_SPI_CONTINOUS_RECEPTION;
	SPIHS1->SPIM1 |= _0040_SPI_RECEPTION_TRANSMISSION;
	
	/* /CS: active */
    SPI_CS_LOW();

    /* Send command 0x0B: Read data */
    SPIHS1_Send(0x0B);
    /* Send 24-bit start address */
    SPIHS1_Send( (SPI_FLASH_ADDR >> 16) & 0xFF);
    SPIHS1_Send( (SPI_FLASH_ADDR >> 8) & 0xFF);
    SPIHS1_Send(SPI_FLASH_ADDR & 0xFF);
    SPIHS1_Send(0x00);//dummy
#if 1	
	SPIHS1->SPIM1 |= _0004_SPI_LENGTH_16;
//	SPIHS1->SPIM1 |= _0002_SPI_CONTINOUS_RECEPTION;
	SPIHS1->SPIM1 &= ~_0040_SPI_RECEPTION_TRANSMISSION;//reception only
	
    DMAVEC->VEC[DMA_VECTOR_SPIHS1] = SPI_DMA_CHANNEL;
    
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMACR = (DMA_SIZE_HALF << CTRL_DMACR_SZ_Pos)  | (0<<CTRL_DMACR_CHNE_Pos) | (0 << CTRL_DMACR_RPTINT_Pos) |
                                        (1 << CTRL_DMACR_DAMOD_Pos)  | (0 << CTRL_DMACR_SAMOD_Pos) |
                                        (0 << CTRL_DMACR_RPTSEL_Pos)| (DMA_MODE_NORMAL << CTRL_DMACR_MODE_Pos);
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMBLS = 1;
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMACT = sizeof(iistxbuff)/(2);
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMRLD = sizeof(iistxbuff)/(2);
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMSAR = (uint32_t)(&SPIHS1->SDRI1);
    DMAVEC->CTRL[SPI_DMA_CHANNEL].DMDAR = (uint32_t)((uint16_t*)&iistxbuff[0][0]);//(uint32_t)&SSIE0.SSIFTDR.HALF;//((uint16_t*)(&SSI->SSIFTDR));
	
    /* init DMA registers */
    CGC->PER1   |= CGC_PER1_DMAEN_Msk;
    DMA->DMABAR  = DMAVEC_BASE;

	DMA_Enable(DMA_VECTOR_SPIHS1);
	spihs1dmacount = 0;//block 0
	
	//SPI->SPIM = _0080_SPI_START_TRG_ON | _0000_SPI_MSB | _0000_SPI_LENGTH_8 ;//| _0008_SPI_BUFFER_EMPTY;//_0040_SPI_RECEPTION_TRANSMISSION | 
//	SPIHS1->SDRO1 = 0xff;
	dummy = SPIHS1->SDRI1;
	
//	INTC_ClearPendingIRQ(SPI1_IRQn);
//	INTC_EnableIRQ(SPI1_IRQn);
//	DMA->IFPRCR  = 0xF1U;
//	DMA_Trigger(DMA_VECTOR_SPI);
#else
	
	SPIHS1->SPIM1 |= _0004_SPI_LENGTH_16;
	
	for(i=0;i<15*1024*1024/2;i++)
	{
//		spitemp = SPIHS1_Send(0x00)<<8;
//		spitemp |= SPIHS1_Send(0x00);
//		
//		SSIE0.SSIFTDR.HALF = spitemp;
		
		SSIE0.SSIFTDR.HALF = SPIHS1_SendWord(0x00);
		
	}

    /* /CS: inactive */
    SPI_CS_HIGH();
#endif		
	
	
#if 1
	//-------------------------------------------------------
  // Initial DMA Vector Table
  //-------------------------------------------------------
  DMAVEC->VEC[DMA_VECTOR_SSI_TX] = IISTX_DMA_CHANNEL;  // SSI TX IRQ
  DMAVEC->VEC[DMA_VECTOR_SSI_RX] = IISRX_DMA_CHANNEL;  // SSI RX IRQ

  //-------------------------------------------------------
  // SSI transmission: RAM --> FIFO
  // src address increment, dst address fixed
  //-------------------------------------------------------
  // word transfer
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMACR = ((1 << FIFO_Pos) | (1 << SZ_Pos) | (0 << DAMOD_Pos) | (1 << SAMOD_Pos) | (0 << RPTSEL_Pos) | (0 << MODE_Pos)); 
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMBLS = 8;
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMACT = sizeof(iistxbuff)/(8*2*2);
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMRLD = sizeof(iistxbuff)/(8*2*2);
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMSAR = (uint32_t)((uint16_t*)&iistxbuff[0][0]);//(uint32_t)txbuf;
  DMAVEC->CTRL[IISTX_DMA_CHANNEL].DMDAR = (uint32_t)((uint16_t*)(&SSI->SSIFTDR));//(uint32_t)&SSIE0.SSIFTDR.HALF;

  //-------------------------------------------------------
  // SSI reception: FIFO --> RAM
  // src address fixed, dst address increment
  //-------------------------------------------------------
  // word transfer
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMACR = ((1 << FIFO_Pos) | (1 << SZ_Pos) | (1 << DAMOD_Pos) | (0 << SAMOD_Pos) | (0 << RPTSEL_Pos) | (0 << MODE_Pos)); 
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMBLS = 8;
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMACT = sizeof(iisrxbuff)/(8*2);
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMRLD = sizeof(iisrxbuff)/(8*2);
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMSAR = (uint32_t)((uint16_t*)(&SSI->SSIFRDR));//(uint32_t)&SSIE0.SSIFRDR.HALF;
  DMAVEC->CTRL[IISRX_DMA_CHANNEL].DMDAR = (uint32_t)iisrxbuff;

  /* Initial DMA Register */
  CGC->PER1   |= CGC_PER1_DMAEN_Msk;
  DMA->DMABAR = DMAVEC_BASE;
  DMA->DMAEN3 = 3<<6;
  
  iisdmacount = 0;//block 0
  INTC_ClearPendingIRQ(SSIDMATX_IRQn);
  INTC_EnableIRQ(SSIDMATX_IRQn);
  
#endif	
	
  SSI_Open(SSI_CH0);
  SSI_Start(SSI_CH0);

	
	while(1)
	{
		
	}
	
	
//	SSI_Stop(SSI_CH0);

}

/***********************************************************************************************************************
* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
	g_ticks--;
}


