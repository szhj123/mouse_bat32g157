/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :  
* Device(s)    : BAT32G157
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/4/30
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <stdio.h>
#include "BAT32G157.h"
#include "userdefine.h"
#include "adc.h"
#include "sci.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint32_t g_ticks;

uint16_t get_value[16];
uint16_t avg_value;

int main()
{
	MD_STATUS status;
	uint32_t i;
	
//-----------------------------------------------------------------------
// Init UART0 for retarget printf/scanf etc. 
//----------------------------------------------------------------------- 
#if 1
	SystemCoreClockUpdate();
	status = UART0_Init(SystemCoreClock, 19200);
	if(status == MD_ERROR)
	{
		while(1);
	}
	
	printf("Hello, UART\n");
#endif

	
//-----------------------------------------------------------------------
// ADC Selft Test
//-----------------------------------------------------------------------
	ADC_Init();					/* ADC inital according to macro defines in Macro Definitions section */
	
  printf("ADC zero code test...\n");
	avg_value = ADC_SelfTest(ADTES_ZERO_CODE, 8, get_value);
  printf("adcr = 0x%04X\n", avg_value);

  printf("ADC half code test...\n");
	avg_value = ADC_SelfTest(ADTES_HALF_CODE, 8, get_value);
  printf("ADCR = 0x%04X\n", avg_value);

  printf("ADC full code test...\n");
	avg_value = ADC_SelfTest(ADTES_FULL_CODE, 8, get_value);
  printf("ADCR = 0x%04X\n", avg_value);

  printf("ADC free code test...\n");
	avg_value = ADC_SelfTest(ADTES_FREE_CODE, sizeof(get_value)/sizeof(get_value[0]), get_value);
	for(i=0; i<sizeof(get_value)/sizeof(get_value[0]); i++)
	{
		printf("ADCR = 0x%04X\n", get_value[i]);
		//printf("ADCR = %04d\n", get_value[i]);
	}
	
	ADC_Stop();	
}
/***********************************************************************************************************************
* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
	g_ticks--;
}


