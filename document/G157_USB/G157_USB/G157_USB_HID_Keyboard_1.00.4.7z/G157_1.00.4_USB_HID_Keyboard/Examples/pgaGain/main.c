/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :  
* Device(s)    : BAT32G133
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/4/30
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/
#define PGA0_OPEN
//#define PGA1_OPEN
//#define USE_VREFTO

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <stdio.h>
#include "BAT32G157.h"
#include "userdefine.h"
#include "pga.h"
#include "adc.h"
#include "sci.h"
#include "cmp.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint32_t g_ticks;
uint16_t get_value[8];
uint16_t avg;

void delayMS(uint32_t n)
{
		g_ticks = n;
		while(g_ticks);
}

int main()
{
	MD_STATUS status;
	uint32_t msCnt; 	// count value of 1ms
	uint32_t i;
	double voltage = 3.0;
	double pga0_i, pga0_o;
	double pga1_i, pga1_o;

//-----------------------------------------------------------------------
// Systick setting 
//-----------------------------------------------------------------------   
	g_ticks = 1000; 	// 1000ms
	SystemCoreClockUpdate();
	msCnt = SystemCoreClock / 1000;
	SysTick_Config(msCnt); 
	
//-----------------------------------------------------------------------
// Init UART0 for retarget printf/scanf etc. 
//----------------------------------------------------------------------- 
	SystemCoreClockUpdate();
	status = UART0_Init(SystemCoreClock, 19200);
	if(status == MD_ERROR)
	{
		while(1); // The baud rate cannot get at the current system clock frequency.
	}
	printf("Hello, UART\n");

#if 1
//-----------------------------------------------------------------------
// PGA0 Test
// P22/PGA0IN --> PGA0 --> ADC/P20/PGAO0
//-----------------------------------------------------------------------
	CGC->PER1 |= CGC_PER1_PGACMPEN_Msk;    /* enables input clock supply */
#ifdef PGA0_OPEN
	PGA_Init(PGA_CHANNEL_0, PGA_VSS_REFERENCE_VOLTAGE, PGA_GAIN_X4, 1); 
	PGA_Start(PGA_CHANNEL_0);
#endif
#ifdef PGA1_OPEN
	PGA_Init(PGA_CHANNEL_1, PGA_VSS_REFERENCE_VOLTAGE, PGA_GAIN_X4, 0); 
	PGA_Start(PGA_CHANNEL_1);
#endif
	
	ADC_Init();	
	for(i = 1; i < 16; i++)
//	while(1)
	{
		avg = ADC_Converse(ADC_CHANNEL_2, sizeof(get_value)/sizeof(get_value[0]), get_value);
		pga0_i = (double)avg * voltage / 4096;
		delayMS(20);
		//avg = ADC_Converse(ADC_CHANNEL_0, sizeof(get_value)/sizeof(get_value[0]), get_value);
		avg = ADC_Converse(ADC_CHANNEL_PGA0, sizeof(get_value)/sizeof(get_value[0]), get_value);
		pga0_o = (double)avg * voltage / 4096;
		delayMS(20);

		printf("ADC Get Value = %3.2fV, %3.2fV, ", pga0_i , pga0_o);
		printf("PGA Gain = %3.2f\n", pga0_o / pga0_i);
	}

#else
//-----------------------------------------------------------------------
// PGA1 --> PGA0 cascade
// P31/PGA1IN --> PGA1 --> P32/PGA1O/PGA0IN --> PGA0
//-----------------------------------------------------------------------
	CGC->PER1 |= CGC_PER1_PGACMPEN_Msk;    /* enables input clock supply */
#ifdef PGA0_OPEN
	PGA_Init(PGA_CHANNEL_0, PGA_VSS_REFERENCE_VOLTAGE, PGA_GAIN_X4, 0); 
	PGA_Start(PGA_CHANNEL_0);
#endif
#ifdef PGA1_OPEN
	PGA_Init(PGA_CHANNEL_1, PGA_VSS_REFERENCE_VOLTAGE, PGA_GAIN_X4, 1); 
	PGA_Start(PGA_CHANNEL_1);
#endif
	
	ADC_Init();	
	//for(i = 1; i < 16; i++)
	while(1)
	{
		delayMS(20);
		avg = ADC_Converse(ADC_CHANNEL_8, sizeof(get_value)/sizeof(get_value[0]), get_value);
		pga1_i = (double)avg * voltage / 4096;
		delayMS(20);
		avg = ADC_Converse(ADC_CHANNEL_9, sizeof(get_value)/sizeof(get_value[0]), get_value);
		pga1_o = (double)avg * voltage / 4096;
		delayMS(20);
		avg = ADC_Converse(ADC_CHANNEL_PGA0, sizeof(get_value)/sizeof(get_value[0]), get_value);
		pga0_o = (double)avg * voltage / 4096;

		printf("ADC Get Value = %3.2fV, %3.2fV, %3.2fV, ", pga1_i , pga1_o, pga0_o);
		printf("PGA Gain = %3.2f, %3.2f\n", pga1_o / pga1_i, pga0_o / pga1_o);
	}	
#endif	
	ADC_Stop();	
}


/***********************************************************************************************************************

* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
	g_ticks--;
}


