/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :  
* Device(s)    : BAT32G157
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/4/30
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <stdio.h>
#include "BAT32G157.h"
#include "lcdb.h"
#include "spi.h"

#include "lcd.h"


/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint32_t g_ticks;
LCDB_Typedef Lcdb;

uint8_t uImage;

void delayMS(uint32_t n)
{
		g_ticks = n;
		while(g_ticks);
}

int main()
{
	uint32_t msCnt; 	// count value of 1ms

//-----------------------------------------------------------------------
// Systick setting 
//-----------------------------------------------------------------------
//	g_ticks = 1000; 	// 1000ms
	SystemCoreClockUpdate();
	msCnt = SystemCoreClock / 1000;
	SysTick_Config(msCnt);
	
//-----------------------------------------------------------------------
// LED blinky on target board 
// PD02 and PD03 drives LED on EVB
//----------------------------------------------------------------------- 
	PORT->PA = 0x0000U;  
	PORT->PMA = 0x0000U;
	PORT->PMCA = 0x0000U;
	PORT->PB = 0x0000U;  
	PORT->PMB = 0x0008U;//PB03->SWDCLK
	PORT->PMCB = 0x0000U;
	PORT->PC = 0x0000U;  
	PORT->PMC = 0x0000U;
	PORT->PMCC = 0x0000U;
	PORT->PD = 0x0000U;  
	PORT->PMD = 0x0000U;
	PORT->PMCD = 0x0000U;
	PORT->PH = 0x0000U;  
	PORT->PMH = 0x0002U;//PH01->SWDDAT
	
	Lcdb.mode = LCDB_MODE_TYPE_8080;	/* 8080 Mode */
	Lcdb.clock_div = LCDB_CLOCK_DIV_1;	/* 1 divider */
	Lcdb.cycle = LDB_CYCLE_8T;//LDB_CYCLE_6T;	/* 6T cycles */
	Lcdb.wait_cycle = LDB_WAIT_CYCLE_2T;	/* 2T wait cycles */
	
	LCDB_Init(&Lcdb);
	
	LCD_Init();
	
	SPI1_MasterInit(SPI_MODE_0);
	SPI1_Start();
	
	while(1)
	{
		delayMS(1000);
		
		ShowImage(uImage);
		if(++uImage>=7)
		uImage = 0;
		
//		Clear_Display(0xf800);
		delayMS(1000);
//		Clear_Display(0x07e0);
//		delayMS(1000);
//		Clear_Display(0x001f);
//		delayMS(1000);
//		Clear_Display(0xffff);
//		delayMS(1000);
//		Clear_Display(0x0000);
	}
}

/***********************************************************************************************************************
* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
	g_ticks--;
}


