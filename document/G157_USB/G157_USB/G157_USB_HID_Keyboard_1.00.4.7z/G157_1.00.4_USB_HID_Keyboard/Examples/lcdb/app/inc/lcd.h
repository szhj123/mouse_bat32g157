#ifndef __LCD_H__
#define __LCD_H__

#define DMA_CTRL_DATA_LCDB 0

typedef struct
{
	uint8_t x_start;
	uint8_t x_end;
	uint8_t y_start;
	uint8_t y_end;
	uint16_t size;
}ORG_TypeDef;


//#define LCD_POWER_ON() PORT->P3 &= ~(1<<0)//P30
//#define LCD_POWER_OFF() PORT->P3 |= (1<<0)//P30

//#define BACKLIGHT_ON() //PORT->P1 |= (1<<6)//P16
//#define BACKLIGHT_OFF() //PORT->P1 &= ~(1<<6)//P16

//#define LCD_CS_HIGH() PORT->P1 |= (1<<3)//P13
//#define LCD_CS_LOW() PORT->P1 &= ~(1<<3)//P13
//#define LCD_RST_HIGH() PORT->P1 |= (1<<4)//P14
//#define LCD_RST_LOW() PORT->P1 &= ~(1<<4)//P14
//#define LCD_DC_HIGH() PORT->P1 |= (1<<0)//P10
//#define LCD_DC_LOW() PORT->P1 &= ~(1<<0)//P10
//#define LCD_WR_HIGH() PORT->P0 |= (1<<0)//P00
//#define LCD_WR_LOW() PORT->P0 &= ~(1<<0)//P00

#define LCD_POWER_ON() //PORT->PCLR3 = (1<<0)//P30
#define LCD_POWER_OFF() //PORT->PSET3 = (1<<0)//P30

#define BACKLIGHT_ON() PORT->PSETA = (1<<4)//PA04 //PORT->P1 |= (1<<6)//P16
#define BACKLIGHT_OFF() PORT->PCLRA =  (1<<4)//PA04 //PORT->P1 &= ~(1<<6)//P16

#define LCD_CS_HIGH() PORT->PSETA = (1<<10)//PA00//PORT->PSETA = (1<<0)//PA00
#define LCD_CS_LOW() PORT->PCLRA =  (1<<10)//PA00//PORT->PCLRA =  (1<<0)//PA00
#define LCD_RST_HIGH() PORT->PSETA = (1<<2)//PA01//PORT->PSETA = (1<<1)//PA01
#define LCD_RST_LOW() PORT->PCLRA =  (1<<2)//PA01//PORT->PCLRA =  (1<<1)//PA01
#define LCD_DC_HIGH() PORT->PSETD = (1<<0)//PA02//PORT->PSETA = (1<<2)//PA02
#define LCD_DC_LOW() PORT->PCLRD =  (1<<0)//PA02//PORT->PCLRA =  (1<<2)//PA02
#define LCD_WR_HIGH() PORT->PSETC = (1<<11)//PC11
#define LCD_WR_LOW() PORT->PCLRC =  (1<<11)//PC11

#define LCD_W 320
#define LCD_H 240
#define TFT_X_OFFSET 0
#define TFT_Y_OFFSET 0
//==================================================================================================================================
void LCD_Init(void);
void Set_Position(uint16_t x1,uint16_t x2,uint16_t y1,uint16_t y2);
void Clear_Display(uint16_t color);
void ShowImage(uint8_t imagenum);
void Show_Second_Image(uint8_t imagenum,ORG_TypeDef* pos);

void Second_Image(void);

#endif
