/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :  
* Device(s)    : BAT32G157
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/4/30
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "stdio.h"
#include "BAT32G157.h"
#include "userdefine.h"
#include "gpio.h"
#include "key.h"
#include "rtc.h"
#include "clk.h"

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint32_t g_ticks;

void delayMS(uint32_t n)
{
		g_ticks = n;
		while(g_ticks);
}

int main()
{
	uint32_t msCnt; 	// count value of 1ms
	uint32_t i;

//-----------------------------------------------------------------------
// Initialize the ports to prevent the leakage current 
//-----------------------------------------------------------------------  	
	GPIO_PullUp_Enable(&PORT->PA, 0xFFFF);
	GPIO_PullUp_Enable(&PORT->PB, 0xFFFF);
	GPIO_PullUp_Enable(&PORT->PC, 0xFFFF);
	GPIO_PullUp_Enable(&PORT->PD, 0xFFFF);
	GPIO_Output_Enable(&PORT->PH, 0x001E);	// PH1/X1, PH2/X2, PH3/XT1, PH4/XT2 output low level
	
//-----------------------------------------------------------------------
// Systick setting 
//-----------------------------------------------------------------------   
	SystemCoreClockUpdate();
	msCnt = SystemCoreClock / 1000;
	SysTick_Config(msCnt);

//-----------------------------------------------------------------------
// PCLBUZ0 output 
//-----------------------------------------------------------------------  
	CLKBUZ0_PORT_SETTING();
	PCBZ->CKS0  = 0x83;    	// FMAIN/2^3
	
//-----------------------------------------------------------------------
// Enable KR0 falling edge interrupt request to wakeup system
//-----------------------------------------------------------------------   
	KEY_Init(1 << 0);                       // Initializes P70/KR0
	KEY_Start();                            // Enable KEY Interrupt
	
//-----------------------------------------------------------------------
// LED ON (500ms) --> LED OFF
//----------------------------------------------------------------------- 
	GPIO_Output_Enable(&PORT->PC, 3 << 1);   // PC01, PC02 output enable
	GPIO_Set_Value(&PORT->PC, 0x00);         // LED ON: PC01, PC02 output low Level
	delayMS(500);                            // LED ON: 500ms for reconnect debugger
	GPIO_Set_Value(&PORT->PC, 0x06);         // LED OFF: PC01, PC02 output High Level
	
//-----------------------------------------------------------------------
// RTC Constant Period Interrupt Demo (1 second)
//-----------------------------------------------------------------------
	//CLK_SubOsc_Setting(OSC_OSCILLATOR, OSC_ULTRA_LOW_POWER); 		/* SubOSC enable */
	CLK_SubOsc_Setting(OSC_OSCILLATOR, OSC_LOW_POWER); 		/* SubOSC enable */
	//CLK_SubOsc_Setting(OSC_OSCILLATOR, OSC_NORMAL_POWER); 	/* SubOSC enable */
	RTC_Init(RTC_FSUB);
	CLK_Fclk_Select(MAINCLK_FSUB);
	CLK_Hoco_Stop();
	RTC_Start();
	date_time.year  = 0x19;
	date_time.month = 0x08;
	date_time.week  = SATURDAY; 
	date_time.day   = 0x31;
	date_time.hour  = 0x08;
	date_time.min   = 0x30;
	date_time.sec   = 0x00;
	RTC_Set_CounterValue(&date_time);
	RTC_Set_ConstPeriodInterruptOn(ONESEC);  // interrupt every second 

//-----------------------------------------------------------------------  
// Systick setting
//-----------------------------------------------------------------------
	SysTick->CTRL  &= ~SysTick_CTRL_ENABLE_Msk;  /* Disable SysTick */
	
//-----------------------------------------------------------------------
// RTC interrupt wakeup system
// Blinky PC02/LED every 5 seconds
// Press PC06/KR0 key to break the while loop
//-----------------------------------------------------------------------
	i = 0;
	while(1)
	{
		__STOP(); 			// Deep Sleep
		i++;
		if(i % 5 == 0)
		{
			PORT->PC ^= (1 << 2); 	// PC02 toggle 
		}
		if(g_keyIntTaken)
		{
			break;
		}
	}

//-----------------------------------------------------------------------  
// Systick setting
//----------------------------------------------------------------------- 
	CLK_Hoco_Start();
	CLK_Fclk_Select(MAINCLK_FIH);  
	SysTick->CTRL  |= SysTick_CTRL_ENABLE_Msk;  /* Enable SysTick */
	
//-----------------------------------------------------------------------
// LED blinky on target board 
// PC01, PC02 drives LED on board
//----------------------------------------------------------------------- 
	// LED Blinky
	PORT->PC = 0x02U;  
	while(1)
	{
		delayMS(250);
		PORT->PC ^= (3<<1); 	// Toggle PC01, PC02
	}
}

/***********************************************************************************************************************
* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
	g_ticks--;
}

