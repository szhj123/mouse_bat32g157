/***********************************************************************************************************************
* Copyright (C) . All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      :
* Device(s)    : BAT32G135
* Tool-Chain   : MDK(armcc)
* Description  : This file is a template.
* Creation Date: 2019/12/25
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include <stdbool.h>
#include <stdio.h>
#include "BAT32G157.h"
#include "userdefine.h"
#include "clk.h"
#include "usb.h"
#include "sci.h"

/***********************************************************************************************************************
Macro Definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

extern void usb_app(void);
	
uint32_t g_ticks;

void usb_cpu_delay_xms(uint32_t n)
{
    g_ticks = n;

    while(g_ticks);
}

void usb_cpu_delay_1us (uint16_t time)
{
    uint16_t sf_cnt;
    sf_cnt = time * 20;

    while(sf_cnt)
    {
        sf_cnt --;
    }
}


/******************************************************************************
 * Function Name: main
 * Description  : Main task
 * Arguments    : none
 * Return Value : none
 ******************************************************************************/
int main (void)
{
		MD_STATUS status;
    uint32_t msCnt; 	// count value of 1ms
//-----------------------------------------------------------------------
// Systick setting
//-----------------------------------------------------------------------
    g_ticks = 1000; 	// 1000ms
    SystemCoreClockUpdate();
//		msCnt = SystemCoreClock / 1000;
    msCnt = 64000000U / 1000;				// USB use 48MHz
    SysTick_Config(msCnt);
	
//-----------------------------------------------------------------------
// MainOSC and SubOSC enable
//-----------------------------------------------------------------------
    //CLK_Osc_Setting(OSC_OSCILLATOR, OSC_OSCILLATOR);
    //CLK_SubOsc_Setting(OSC_OSCILLATOR, OSC_LOW_POWER);
	
//-----------------------------------------------------------------------
// HOCO = 32MHz / fIH = 16MHz, UPLL = 48MHz, FPLL = 64MHz
//-----------------------------------------------------------------------
	CLK_PLL_Setting(PLL_SR_fIH,PLL_DIV_4,PLL_MUL_16);
	CLK_UPLL_Setting(PLL_SR_fIH,PLL_DIV_4,PLL_MUL_12);
	CLK_PLL_Start();
	usb_cpu_delay_xms(2);
	CLK_UPLL_Start();
	usb_cpu_delay_xms(2);
	CLK_Fclk_Select(MAINCLK_FPLL);

#if 1
	status = UART0_Init(64000000U, 19200);
	if(status == MD_ERROR)
	{
		while(1);
	}
	
	printf("Hello, UART\n");
#endif

	//set PD01(USBEN) high
	PORT->PMD &= ~(1<<1);
	PORT->PMCD &= ~(1<<1);
	PORT->POMD &= ~(1<<1);
	PORT->PD |= (1<<1);

	usb_app();	/* USB sample application */

} /* End of function main() */

/***********************************************************************************************************************
* Function Name: SysTick Handler
* Description  : Decreament the g_ticks value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void SysTick_Handler(void)
{
    g_ticks--;
}

/******************************************************************************
 End  Of File
 ******************************************************************************/

