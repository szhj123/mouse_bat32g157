/******************************************************************************
* File Name     : usb_hhid_mini_config_reference.h
* Version       : 1.00
* Description   : USB Host HID User definition
******************************************************************************/

#ifndef USB_HHID_MINI_CONFIG_H
#define USB_HHID_MINI_CONFIG_H

/*******************************************************************************
 Macro definitions
 ******************************************************************************/

/** [Setting pipe to be used]
 * USB_CFG_HHID_INT_IN      : Pipe number (USB_PIPE6 to USB_PIPE9) 1st Device HID Interrupt In Pipe
 */
#define USB_CFG_HHID_INT_IN         (USB_PIPE6)

/** [Setting pipe to be used]
 * USB_CFG_HHID_INT_OUT     : Pipe number (USB_PIPE6 to USB_PIPE9) 1st Device HID Interrupt Out Pipe
 */
#define USB_CFG_HHID_INT_OUT        (USB_PIPE7)


#endif  /* USB_HHID_MINI_CONFIG_H */
/******************************************************************************
End Of File
******************************************************************************/
