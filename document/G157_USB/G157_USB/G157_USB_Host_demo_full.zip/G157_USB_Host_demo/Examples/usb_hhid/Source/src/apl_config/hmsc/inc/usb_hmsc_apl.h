#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "usb_basic_mini_if.h"

#include "usb_hmsc_mini_if.h"
#include "usb_media_driver_mini_if.h"
//#include "usb_hmsc_apl_config.h"

void usb_app(void);
