#include "BAT32G157.h"
#include <stdio.h>
#include "usb_basic_mini_if.h"
#include "usb_hhid_mini_if.h"


void usb_app(void)
{
	usb_ctrl_t ctrl;
	usb_err_t err;
	usb_cfg_t   cfg;
	uint8_t g_buf[256];
	uint8_t event;
	uint8_t type;
	uint16_t mxps, i;
	
	ctrl.type       = USB_HHID;
	cfg.usb_mode    = USB_HOST;
	err = USB_Open (&ctrl, &cfg);   /* Initializes the USB module */
	if (USB_SUCCESS != err)
	{
		printf("USB Init Error\r\n");
	}
	
	while (1)
 {
	 event = USB_GetEvent(&ctrl);
//	 switch (USB_GetEvent(&ctrl))
	 switch (event)
	 {
		 case USB_STS_CONFIGURED:
			 USB_HhidGetType(&type);
			 if(USB_HID_KEYBOARD == type)
			 {
					printf("Keyboard attach\r\n");
			 }else if(USB_HID_MOUSE == type){
				  printf("mouse attach\r\n");
			 }else{
				  printf("unknown device attach\r\n");
			 }
			 
			 USB_HhidGetMxps(&mxps, USB_IN);
			 printf("max package size is:%d\r\n", mxps);
			 
			 USB_Read(&ctrl, g_buf, mxps);
			 
			 break;
			 
		 case USB_STS_READ_COMPLETE:
			 //Byte0: 0x01, Byte1: key, Byte2~3: left right move, left->0, right->0xffff, 
		   //Byte4~5: top down move, down->0, top->0xffff, Byte6: scroll, up->0, down->0xff, Byte7: unknown
			 for(i = 0; i < mxps; i++)
			 {
				 printf("%02x ", g_buf[i]);
			 }
			 printf("\r\n");
			 
			 USB_Read(&ctrl, g_buf, mxps);
			 break;
				 
		 case USB_STS_DETACH:
				printf("Device Detach\r\n");
				break;
		default:
			 if(event != USB_STS_NONE)
			 {
					printf("event:%d\r\n",event);
			 }
			 break;
		}
	 
	}
}

