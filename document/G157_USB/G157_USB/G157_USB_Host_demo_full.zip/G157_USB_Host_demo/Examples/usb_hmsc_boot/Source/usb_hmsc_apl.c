#include "usb_hmsc_apl.h"
#include "ff.h"
#include "fmc_user.h"

uint32_t g_hmsc_sector_size = 512;	//default 512, update when Device atteched
uint32_t g_hmsc_sector_count = 0;		//default 0, update when Device atteched

#define DISK_DEFAULT		 0x00
#define DISK_MOUNT 			 0x01
#define DISK_READLIST 	 0x02
#define DISK_READFILE 	 0x03
#define DISK_WRITEFILE   0x04
#define DISK_UPDATE   	 0x05
#define DISK_DEMOEND	   0x06

void disk_update_rountine(void);

FATFS fatfs;
FIL file;
FRESULT fatres;
FILINFO fno;
DIR dir;

uint8_t demo_state;
uint8_t configed_flag;
uint8_t WriteTextBuff[] = "BAT32G157 Hmsc Demo application using FAT_FS ";

uint8_t file_buff[4096];
uint32_t read_len;
uint8_t update_result = 0;

void usb_app(void)
{
	usb_ctrl_t ctrl;
	usb_err_t err;
	usb_cfg_t   cfg;
	uint8_t g_buf[512];
	uint8_t event;
	
	ctrl.type       = USB_HMSC;
	cfg.usb_mode    = USB_HOST;
	err = USB_Open (&ctrl, &cfg);   /* Initializes the USB module */
	if (USB_SUCCESS != err)
	{
		printf("USB Init Error\r\n");
	}
	
	while (1)
 {
	 event = USB_GetEvent(&ctrl);
//	 switch (USB_GetEvent(&ctrl))
	 switch (event)
	 {
		 case USB_STS_CONFIGURED:
			 USB_HmscStrgCmd(g_buf, USB_ATAPI_READ_CAPACITY );
		   printf("Disk emum success, Read disk Capacity\r\n");
			 break;
		 case USB_STS_MSC_CMD_COMPLETE:
			 if( ctrl.status == USB_CSW_SUCCESS)
			 {
				 	g_hmsc_sector_size = (g_buf[6]<<8) + g_buf[7];
					g_hmsc_sector_count = (g_buf[1]<<16) + (g_buf[2]<<8) + g_buf[3];
					printf("Capacity:%d sector, %d size\r\n", g_hmsc_sector_count, g_hmsc_sector_size);
					configed_flag = 1;
			 }else{
				  printf("Read disk Capacity fail\r\n");
			 }
			 break;
		 case USB_STS_DETACH:
				printf("Device Detach\r\n");
				configed_flag = 0;
				demo_state = DISK_DEFAULT;
				break;
		default:
			 if(event != USB_STS_NONE)
			 {
					printf("event:%d\r\n",event);
			 }
			 break;
		}
	 
		if(configed_flag ==1)
		{
				disk_update_rountine();
		}
	}
}


void disk_update_rountine(void)
{
	uint16_t bytesWritten, bytesToWrite;
	uint16_t   res[10];
	uint32_t file_size, file_pos = 0;
	
	usb_hstd_DeviceInformation(0, (uint16_t *)res); /* Get device connect state */
	if ( USB_STS_DETACH == res[1] )    /* Check detach */
	{
			printf("Device Detach\r\n");
			configed_flag = 0;
			return;
	}
	
	switch(demo_state)
	{
		case DISK_DEFAULT:
			printf("Fatfs start\r\n");
			demo_state = DISK_MOUNT;
			break;
		case DISK_MOUNT:
			if (FR_OK != f_mount(&fatfs, "0:/", 0)) {
				printf("Cannot mount disk\r\n");
			}
			printf("Mount disk OK\r\n");
			demo_state = DISK_UPDATE;
			break;
	  case DISK_UPDATE:
			update_result = 0;
			fatres = f_open(&file,  "0:/update.bin", FA_READ);
			printf("open file 'update.bin'\r\n");
			if(FR_OK == fatres)
			{
				file_size = file.obj.objsize;
				file_pos = 0;
				//erase flash
				EraseAP(FMC_APROM_BASE, (FMC_APROM_BASE + APROM_SIZE));
				printf("Erase flash\r\n");
				while(file_pos < file_size)
				{
						fatres = f_read(&file, (void*)file_buff, sizeof(file_buff), &read_len);
						if(fatres == FR_OK)
						{
							WriteData(FMC_APROM_BASE + file_pos, FMC_APROM_BASE + file_pos + read_len, (uint32_t*)file_buff);
							//check write data
							if(0 != memcmp((void*)file_buff, (void*)(FMC_APROM_BASE + file_pos), read_len))
							{
								printf("Check data error\r\n");
								demo_state = DISK_DEMOEND;
								update_result = 1;
								break;
							}
							file_pos += read_len;
							f_lseek(&file, file_pos);
						}else
						{
							printf("Read file error\r\n");
							demo_state = DISK_DEMOEND;
							update_result = 1;
							break;
						}
				}
				
				f_close(&file);	//close file
			}else
			{
				printf("Open file fail, make sure file 'update.bin' is exist\r\n");
				demo_state = DISK_DEMOEND;
				update_result = 1;
			}
			
			if(update_result == 0)
			{
				printf("Update success��\r\n");
			}
			demo_state = DISK_DEMOEND;
			break;
	case DISK_DEMOEND:
			break;
	}
}

