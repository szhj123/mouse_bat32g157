/******************************************************************************
 * File Name    : usb_pmsc_apl.h
 * Description  : USB Phelipheral MSC Sample Code
 ******************************************************************************/

/******************************************************************************
 Includes   <System Includes> , "Project Includes"
 ******************************************************************************/

//#include "Pin.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "usb_basic_mini_if.h"

#include "usb_pmsc_mini_if.h"
#include "usb_media_driver_mini_if.h"
#include "ext_flash_disk.h"
#include "usb_pmsc_apl_config.h"

#ifndef USB_PMSC_APL_H
    #define USB_PMSC_APL_H


    /******************************************************************************
    Macro definitions
    ******************************************************************************/

    #define NUM_STRING_DESCRIPTOR (7u)

    /*******************************************************************************
    Typedef definitions
    ******************************************************************************/

    /*******************************************************************************
    Exported global variables
    ******************************************************************************/

    extern uint8_t g_apl_device[];
    extern uint8_t g_apl_configuration[];
    extern uint8_t *gp_apl_string_table[];

    /*******************************************************************************
    Exported global functions (to be accessed by other files)
    ******************************************************************************/

    extern void usb_main (void);

#endif /* USB_PMSC_APL_H */
/******************************************************************************
 End  Of File
 ******************************************************************************/
