#ifndef __LED_DRIVER_H__
#define __LED_DRIVER_H__
#include ".\include\Variable.h"


extern void Led_Init(void);

extern void DPILed_Init(void);

extern void DPILED_Disable(void);

extern void DPILed_BreathProc(void);


extern int  RandSub(void);

//extern void ClrLedBuf(void);

extern void SetPwmBuf(U8 r,U8 g,U8 b);

extern void Led_Mode_Show(void);

//**********************************************************************************
extern void AuroraProc(void);

extern void AuroraSpecialInit(U8 pwm_max);

//**********************************************************************************
extern void LedBreathProc(void);

extern void TailLED_Proc(void);

//**********************************************************************************
extern void LedNeonlight_Proc(void);

//**********************************************************************************
extern void PwmDownNew(void);

//extern void LedLaser_Proc(void);
//**********************************************************************************

//extern void PaomaProc(void);

extern void PaomaProc_RGB(void);

//**********************************************************************************
extern void LedMulticolor_Proc(void);

extern void LedHuncai_Set(void);

//**********************************************************************************
//extern void LedFlash_Init(void);

extern void LedFlash_Proc(void);
//**********************************************************************************
extern void AllLedOnInit(void);
//**********************************************************************************
extern void RandSetLedBuf3(void);

extern void RandSetLedBuf4(void);
//**********************************************************************************
extern void LEDMode_Change(void);

extern void LEDdata_analysis(U8 *led_buffer);
//**********************************************************************************
extern void Set_DPI_LED(void);
//**********************************************************************************
extern void Set_YaQiang_LED(void);
//**********************************************************************************
extern void ModeLED_Init(void);

extern void ModeLED_Flash(void);

//extern void Set_reportrate_LED(void);

//extern void WheelLED_Disable(void);

//extern void PowerON_LED_Init(void);

//extern void Set_LodColor(void);

//extern void IIC_Write(U8 address, U8 wdata);

//extern U8 IIC_Read(U8 address);

//extern void Set_LED_Param(U16 limit_period, U8 limit_cnt);

//**********************************************************************************

extern void Led_Speed_Changed(void);

extern void Led_Brightness_Changed(void);

extern void Led_Color_Changed(void); 
extern void ReportLED_Init(void);
#endif
