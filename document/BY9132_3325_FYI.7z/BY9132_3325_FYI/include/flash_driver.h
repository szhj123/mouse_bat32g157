#ifndef __IAP_H__
#define __IAP_H__
#include ".\include\Variable.h"


extern void Get_Flash_LedData(void);

extern void Get_Flash_KeyData(void);

extern void Get_Flash_Yaqiang_LedData(void);

extern void Get_Flash_Debounce_Data(void);

extern void Get_Flash_LodData(void);


extern void Save_flash_DebounceTime_Data(void);

extern void General_Buffer_Analysis(void);

extern void chk_keyboard_keydown(void);


//extern void LedParameter_Changed(void);

//extern void Buffer_Analysis(void);

//extern void Save_Test_MacroData(void);

extern void Save_Inf_Data(void);

extern void Save_flash_Profile(void);



extern void Update_Profile_Function(void);

extern void Scan_Key(void);

extern void Wheel_Handle(void);

extern void ProgramKey_Handle(void);


extern void LedMode_Changed(void);


extern void BT3_Init(void);

extern void IN1_Prog(void);

extern void IN2_Prog(void);

extern void YaQiang_Fuction(void);	

extern void YaQiang_DeaultData_Init(void);

#endif
