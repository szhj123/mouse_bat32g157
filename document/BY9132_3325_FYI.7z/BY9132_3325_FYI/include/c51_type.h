#ifndef __C51_TYPES_H
#define __C51_TYPES_H

//#include "lib_module.h"

typedef	unsigned char	U8;
typedef	unsigned int	U16;
typedef	unsigned long	U32;
typedef	signed   char	S8;
typedef	signed   int	S16;
typedef	signed   long	S32;

#define BOOL_OK					1
#define BOOL_FAIL				0

#endif