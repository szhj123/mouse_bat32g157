#ifndef   _VARIABLE_H
#define   _VARIABLE_H
#include "stdlib.h"
#include ".\include\intrins.h"
#include ".\include\ABSACC.H"
#include ".\include\define.h"
#include "..\include\SH68F91.h"
#include ".\include\hw.h"
#include ".\include\LedDriver.h" 
#include "..\include\CFG.h"
#include "..\include\usb_def.h"

extern void SetPwmBuf(U8 r,U8 g,U8 b);

#define LED_ModeCounts  			11 //  

#define Deay_Index_Counts			15

#define LED_MAX_MATRIX_COLUMN	 	 8 //6//7		// same with Total of ScanLine

#define DPILed_PWM   				1

#define Led_Flowing 				1
#define Led_FixedOn 				2
#define Led_Breath 					3
#define Led_Tail_Bothway 			4
#define Led_Neonlight 				5
#define Led_Huncai 					6
#define Led_Flash 					7
#define Led_Tail_Onlyway 			8
#define Led_Multicolor				9
#define Led_Noeffect				0


#define ProfileKey_YN	 			0

#define Aangle_UP					0xC0
#define Aangle_DN					0x00
#define Aangle_L					0x80
#define Aangle_R					0x40

#define LOD_Steps_Maximum			4

#define LED_Brightness_Maximum		4


#define Key_Debounce_4ms			2	
#define Key_Debounce_6ms			3	
#define Key_Debounce_8ms			4	
#define Key_Debounce_10ms			5
#define Key_Debounce_12ms			6
#define Key_Debounce_14ms			7
#define Key_Debounce_16ms			8


typedef enum 
{
    ERASE_FLAG = 0x3c,
    PROG_FLAG  = 0X69
};

/***************************************************************************************/
extern code const U8 Password[4];

extern code const U8 LEDRGB11[7][3];

extern code const U8 RGBLumin_TAB[5];
/***************************************************************************************/
extern U8 xdata PaomaLedPosition[2];

extern U8 xdata LedPWMBuff[LED_MAX_MATRIX_COLUMN][4];			//�������ȱ��ݻ��߰���״̬����

extern U8 xdata Key_DebounceTime_Buf[2];

/***************************************************************************************/
extern code const U8 Profile1_KeyTab[80];
extern code const U8 Profile2_KeyTab[80];
extern code const U8 Profile1_LedTab[LED_DataLength];
extern code const U8 Profile2_LedTab[LED_DataLength];
//extern code const U8 Yaqiang_DelayTab[512];

extern U8 xdata Flash_Temp_Buf[250];

//******************************************************************************************
extern U8 data  RdProgSW_TH;
extern U8 xdata KeyNum_bkBuf[16];
extern U8 idata ProgSW_bkBuf[16];
extern U8 xdata NormalKey_bkBuf[16];
extern U8 xdata SystemKey_bkBuf[16];
extern U8 xdata ConsumerKey_bkBuf1[16];
extern U8 xdata ConsumerKey_bkBuf2[16];
extern U8 xdata ConsumerKey_bkBuf3[16];
/***************************************************************************************/
extern U8 xdata LedLastMode;		//����LED����ǰģʽ
extern U8 xdata LedLastLum;
extern U8 xdata LedLastSpeed;
extern U8 xdata LedLastColorMode;

extern U8 idata CurrentLedMode;
extern U8 idata CurrentLedLumian;
extern U8 idata CurrentLedSpeed;
extern U8 idata CurrentLedColor;
extern U16 xdata usb_int_cnt;

extern volatile U16 idata CountTmp;
extern volatile U16 idata TimeCount1;
extern volatile U16 idata TimeCount2;

extern volatile U8 idata time_1ms_cn;
extern volatile U8 idata LedScanLine;
extern U8 idata DPI_BreathTime;


extern U16 idata Resetflag;

extern U8 data LedMode_cnt;

extern volatile bit fUpDateLed;
extern volatile bit fLoadDefaulData;
extern volatile bit fLedModeUpdata;

/***************************************************************************************/
extern U8 data pwm_stage;
extern U8 data pwm_r,pwm_b,pwm_g;
extern U8 data PwmDutyCount;
extern U8 data pwm_max;

extern volatile bit fg_Invert;
extern volatile bit fg_LedPar;
extern volatile bit fg_LedMode_Hd;


//******************************************************************************************
extern U8 idata Consumer_Buf[3];
extern U8 idata normalkey_Buf[7];

//******************************************************************************************
extern volatile bit fg_mouse_send;
extern volatile bit fg_NormalKey_send;
//extern volatile bit fg_NormalKey_Press;
extern volatile bit fg_ConsumerKey_send;
extern volatile bit fg_ConsumerKey_Press;
//******************************************************************************************
extern U8 data DPI_X;
extern U8 data DPI_Y;
extern U8 data DPI_Steps;
extern U8 data Sensor_DPI;

extern S8 data Tiltwheel;

extern U8 data sensor_type;
extern U8 data Sensor_Direction;
extern U8 data sensor_type_save1;
extern S16 data sensor_data_x,sensor_data_y;
extern S16 data sensor_data_x1,sensor_data_y1;

extern volatile bit fg_Sensor_OK;


extern U8 bdata sensor_data;
	extern bit sensor_DI;
	extern bit sensor_DO;

extern U8 idata burst_data[6];

extern U8 xdata DPI_Buffer[16];

//******************************************************************************************
extern volatile bit fg_DPI;
extern volatile bit fg_DPIShift;
extern U8 data DPI_Shift_Data;

//******************************************************************************************
extern U8 data Profile;
extern U8 data ReportRate;
extern S8 data wheel_data;
extern U8 data Button_Mouse;
extern U8 data Muse_button;
extern U8 data RdProgSW_TH;

//******************************************************************************************
extern volatile bit fg_Firkey;

extern volatile bit fg_scan_key;

extern volatile bit fg_scan_wheel;

extern volatile bit fg_key_status;

extern volatile bit fg_RGBOFF;

extern volatile bit fg_DPIOFF;

extern volatile bit fg_XY_axes;
//******************************************************************************************
extern U8 xdata fire_delay_time;

extern U8 xdata KB_fire_delay_time;

//******************************************************************************************

extern U8 xdata YaQiang_Count;
extern U8 xdata YaQiang_Number1;
extern U8 xdata YaQiang_Number2;

extern volatile bit fg_Modeled;

extern volatile bit fg_YaQiang_2times;

//******************************************************************************************
extern volatile bit fg_1ms;
extern volatile bit fg_2ms;
extern volatile bit fg_4ms;
extern volatile bit fg_8ms;
extern volatile bit fg_Remote;
extern volatile bit fg_suspend;
extern volatile bit device_remote_wakeup_f;

extern U16 xdata Suspend_Counter;

//******************************************************************************************
extern U8 xdata YaQiang_Color[];

extern volatile U8 xdata YaQiang_Macro[10];
//******************************************************************************************
extern U8 xdata DPI_color[24];

extern U8 xdata DPI_Buffer[16];

extern U8 xdata RGB_Color[30];

//******************************************************************************************
extern U8 xdata Key1Data_Buffer[80];
					 
extern U8 xdata Key2Data_Buffer[80];

extern U8 xdata Led1Data_Buffer[123];

extern U8 xdata Led2Data_Buffer[123];

extern U8 xdata MacroData_Buffer[512];

extern U8 xdata P3360_LOD_Parameter[3];

//extern U8 xdata MacroData_Temp[512];

//******************************************************************************************
extern volatile bit fg_Profile_LED;
extern volatile bit fg_Profile_Key;
extern volatile bit fg_Yaqiang_LED;
extern volatile bit fg_Yaqiang_Update;

extern volatile bit fg_Profile;
extern volatile bit fg_Macro_Key;
//******************************************************************************************
extern U8 data Macro_Style;

extern U8 data macro_index;

extern U8 xdata MacroRealse_TH;

extern U8 data macro_action_num;

extern U16 data macro_send_addr;

extern U16 data macro_Repeat_cnt;

extern U16 idata Macro_Delay_Time;

extern volatile bit fg_macro_send;

extern volatile bit fg_macro_head;

extern volatile bit fg_medical;

#define Macro_Repeat  0x01    // �ظ���ָ������
#define Macro_Always  0x02    // һֱ�ظ������������	
#define Macro_Realse  0x04    // �����ɿ�����?
//******************************************************************************************

extern U8 data  Yaqiang_Style;

extern U8 xdata YaQiang_data_addr;

extern U8 xdata YaQiang_action_num;

extern U8 xdata YaQiang_Repeat_cnt;

extern U8 xdata Yaqiang_RealseTH;

extern volatile bit Yaqiang_send;

#define Yaqiang_Repeat  0x01 // �ظ���ָ������	
#define Yaqiang_Realse  0x04 // �����ɿ�����?

//******************************************************************************************

extern U16 xdata LED_Flash_Period;

extern volatile bit fg_LED_Flash;


//extern volatile bit fg_correct;

//extern volatile bit fg_Mixture;

//extern U8 xdata LOD_Steps;

//extern volatile bit fg_height_Changed;

//extern U8 xdata LOD_height;

//extern volatile bit LOD_effect;

//extern volatile bit fg_PON;

//extern U16 xdata DPI_Flash_Period;

//extern U16 xdata DPI_limit_Period;

//extern volatile bit fg_DPILED_ON;

//extern volatile bit fg_DPILED_Flash;

//extern volatile bit fg_Speed;

//extern volatile bit fg_brightness;

//extern volatile bit fg_color;

extern volatile bit fg_DPIkey;

extern volatile bit fg_DebounceTime;
extern U8 xdata Key_DebounceTime;


extern U8 xdata Lift_height;

extern U8 xdata Lift_TMP;

extern U8 data Protocol_type1;

extern U8 data Protocol_type0;

extern U8 xdata Angle_snap;

extern U8 xdata Angle_snap_Tmp;

extern volatile bit fg_LOD_Update;
extern U16 xdata key_current;

#endif
