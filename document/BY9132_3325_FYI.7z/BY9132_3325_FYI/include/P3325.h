
#ifndef _P3325_H__
#define _P3325_H__

#define Product_ID_addr3325          0x00								  //0x43
#define MOTION_addr3325              0x02								  //0x00
#define Delta_XL_addr3325            0x03								  //0x00
#define Delta_XH_addr3325            0x04								  //0x00
#define Delta_YL_addr3325            0x05								  //0x00
#define Delta_YH_addr3325            0x06


#define SQUAL_addr3325               0x07								  //Any
#define pixel_sum_addr3325           0x08								  //Any
#define Max_pixel_addr3325           0x09								  //Any
#define Min_pixel_addr3325           0x0A								  //Any
#define Shutter_upper_addr3325       0x0B								  //Any
#define Shutter_lower_addr3325       0x0C								  //Any
#define Chip_Observation_addr3325    0x15
#define Brust_motion_addr3325        0x16								  //Any
#define pixel_Grab_addr3325          0x19
#define Resolution_addr3325       	 0x1b
#define Angle_Snap_addr3325      	 0x1e

#define AXIS_Control_addr3325		 0x20
#define Run_Downshift_addr3325       0x24
#define Rest1_preiod_addr3325        0x25								  //0x08
#define Rest1_Downshift_addr3325     0x26								  //0x08
#define Rest2_preiod_addr3325        0x27								  //0x08
#define Rest2_Downshift_addr3325     0x28	
#define Rest3_preiod_addr3325        0x29	
#define Pixel_Grab_addr3325          0x32
#define Power_UP_Reset_addr3325		 0x3a
#define D_POWERUP_RESET       		 0x5A

#define Shutdown_addr3325		     0x3b
#define Inv_PROD_ID_addr3325		 0x3F
#define Config_addr3325		 		 0x40	


#endif
