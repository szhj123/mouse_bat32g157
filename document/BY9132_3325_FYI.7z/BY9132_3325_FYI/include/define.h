
#ifndef	_DEFINE_H
#define	_DEFINE_H



#define MODIFYED_20210319			//DPI LED  PWM33CON

#define EEprom_MacroData_Addr 	0x000
#define EEprom_mode_Addr        0x400


#define S_EEPROM_Inf_SECTOR0	0
#define S_EEPROM_Inf_SECTOR1	1
#define S_EEPROM_Inf_SECTOR2	2
#define S_EEPROM_Inf_SECTOR3	3
#define S_EEPROM_Inf_SECTOR4	4
#define S_EEPROM_Inf_SECTOR5	5
#define S_EEPROM_Inf_SECTOR6	6
#define S_EEPROM_Inf_SECTOR7	7



#define S_fg_EEPROM			1
#define S_fg_FLASH			0


#define S_ReportRate_125		0x01
#define S_ReportRate_250		0x02
#define S_ReportRate_500		0x03
#define S_ReportRate_1000		0x04


#define switch_SFR_Bank0()		INSCON &= ~0xC0
#define switch_SFR_Bank1()		INSCON |= 0x40
#define SFR2BANK0				INSCON &= ~0xC0		//INSCON = 0x00
#define SFR2BANK1 				INSCON |= 0x40		//INSCON = BIT6

#define switch_info()   		FLASHCON |= 0x01
#define switch_main()   		FLASHCON &= ~0x01



//===============FW ����=================
#define S_FLASH_Key1_Addr   	  	0x5800	//sector 32
#define S_FLASH_Key2_Addr   	  	0x5900	
#define FLASH_Key_SECTOR 		  	44	

#define S_FLASH_Led1_Addr   		0x5a00	//sector 33
#define S_FLASH_Led2_Addr   		0x5b00	
#define FLASH_LED_SECTOR		  	45

#define S_FLASH_profile_addr   	  	0x5f00	//sector 34
#define S_FLASH_DebounceTime_Addr   0x5f00+1	//sector 36
#define S_FLASH_Lod_addr   	  		0x5f00+3	//sector 36
#define S_FLASH_YaqiangColor_Addr   0x5f00+7	//sector 37
#define FLASH_Profile_SECTOR	  	47

#define S_FLASH_Macro_Addr   		0x6000	//sector 38-58
#define FLASH_Macro_SECTOR    	    48


#define MOUSE_SECTOR      			55

#define LED_DataLength			    115 
#define Key_DataLength			    80 
#define YiangQ_Color_DataLength		38 

#define Macro_DataLength			512
#define UNUSED_SECTOR				0x00	//  sector Reserve


//===============================================================================================
//								C���Լ򻯶���
//===============================================================================================
#define	Byte	unsigned char
#define	Word	unsigned int
#define	Dword	unsigned long

#define U8		unsigned	char
#define S8		signed		char
#define U16		unsigned	int
#define S16		signed		int
#define U32		unsigned	long
#define S32		signed		long



#define	MAKEWORD(v1,v2)	(((Word)(v1)<<8) + (Word)(v2))
#define	MAKEDWORD(v1,v2)(((Dword)(v1)<<16) + (Dword)(v2))
#define	HIBYTE(v1)		((Byte)((v1)>>8))
#define	LOBYTE(v1)		((Byte)((v1)&0xff))

#define LongToBin(n) \
(                    \
((n >> 21) & 0x80) | \
((n >> 18) & 0x40) | \
((n >> 15) & 0x20) | \
((n >> 12) & 0x10) | \
((n >>  9) & 0x08) | \
((n >>  6) & 0x04) | \
((n >>  3) & 0x02) | \
((n      ) & 0x01)   \
)
#define Bin(n) LongToBin(0x##n##l)	//write binary charactor set,exsample : Bin(11111111) = 0xff


#define BIT7 (unsigned char)(1 << 7)
#define BIT6 (unsigned char)(1 << 6)
#define BIT5 (unsigned char)(1 << 5)
#define BIT4 (unsigned char)(1 << 4)
#define BIT3 (unsigned char)(1 << 3)
#define BIT2 (unsigned char)(1 << 2)
#define BIT1 (unsigned char)(1 << 1)
#define BIT0 (unsigned char)(1 << 0)
//=========================================


#endif
