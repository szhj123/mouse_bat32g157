#ifndef __MOUSE_API_H__
#define __MOUSE_API_H__

#include ".\include\define.h"

extern void mouse_button_application(U8 button);

extern void mouse_NormalButton_application(U8 button);
	
extern void mouse_XY_application(U8 XY_data,U8 flag);

extern void mouse_wheel_application(U8 wheel);

extern void mouse_DPI_application(U8 data_type);

extern void mouse_DPI_Lock_application(U8 Shift_data);

extern void mouse_Ctrl_application(U8 data_type);

extern void mouse_macro_application(U8 macro_addr, U8 macro_style,U8 macro_repeat);

extern void mouse_fire_application(U8 button,U8 firetime,U8 firecnt);

extern void mouse_fire_function(void);

extern void KB_fire_application(U8 code1,U8 firetime,U8 firecnt,U8 TYPE);

extern void KB_fire_function(void);

//extern void NormalKB_application(U8 wincode, U8 normalcode1);

extern void KB_normal_application(U8 wincode, U8 normalcode1);

extern void KB_consumer_application(U8 code1,U8 code2,U8 code3);

extern void Clear_NormalKey(void);

extern void mouse_KeyUP(void);

extern void MacroProcess(void);

extern void mouse_Yaqiang_application(U8 number, U8 type,U8 speed,U8 y);

extern void mouse_YaQiang_LeftButton(U8 index,U8 type,U8 speed,U8 y);
#endif