
#ifndef	_PWM_CONTROL_H
#define	_PWM_CONTROL_H
///////////////////////enable led pwm output////////////////////////////////////////////////////

#define PWM00_ENABLE		(PWM00CON |= 0X88)
#define PWM01_ENABLE		(PWM01CON |= 0X08)
#define PWM02_ENABLE		(PWM02CON |= 0X08)
#define PWM03_ENABLE		(PWM03CON |= 0X08)
#define PWM04_ENABLE		(PWM04CON |= 0X08)
#define PWM05_ENABLE		(PWM05CON |= 0X08)

#define PWM10_ENABLE		(PWM10CON |= 0X08)
#define PWM11_ENABLE		(PWM11CON |= 0X08)
#define PWM12_ENABLE		(PWM12CON |= 0X08)
#define PWM13_ENABLE		(PWM13CON |= 0X08)
#define PWM14_ENABLE		(PWM14CON |= 0X08)
#define PWM15_ENABLE		(PWM15CON |= 0X08)

#define PWM20_ENABLE		(PWM20CON |= 0X08)
#define PWM21_ENABLE		(PWM21CON |= 0X08)
#define PWM22_ENABLE		(PWM22CON |= 0X08)
#define PWM23_ENABLE		(PWM23CON |= 0X08)
#define PWM24_ENABLE		(PWM24CON |= 0X08)
#define PWM25_ENABLE		(PWM25CON |= 0X08)

#define PWM30_ENABLE		(PWM30CON |= 0X88)
#define PWM31_ENABLE		(PWM31CON |= 0X08)
#define PWM32_ENABLE		(PWM32CON |= 0X08)
#define PWM33_ENABLE		(PWM33CON |= 0X08)

#define PWM40_ENABLE		(PWM40CON |= 0X08)
#define PWM41_ENABLE		(PWM41CON |= 0X08)
#define PWM42_ENABLE		(PWM42CON |= 0X08)

///////////////////////enable led pwm output////////////////////////////////////////////////////
/*
#define PWM00_ENABLE		{PWM00CON = 0x8f;}//(PWM00CON |= 0X08)
#define PWM01_ENABLE		{PWM01CON = 0x08;}
#define PWM02_ENABLE		{PWM02CON = 0x08;}
#define PWM03_ENABLE		{PWM03CON = 0x08;}
#define PWM04_ENABLE		{PWM04CON = 0x08;}
#define PWM05_ENABLE		{PWM05CON = 0x08;}

#define PWM10_ENABLE		{PWM10CON = 0x8f;}
#define PWM11_ENABLE		{PWM11CON = 0x08;}
#define PWM12_ENABLE		{PWM12CON = 0x08;}
#define PWM13_ENABLE		{PWM13CON = 0x08;}
#define PWM14_ENABLE		{PWM14CON = 0x08;}
#define PWM15_ENABLE		{PWM15CON = 0x08;}

#define PWM20_ENABLE		{PWM20CON = 0x8f;}
#define PWM21_ENABLE		{PWM21CON = 0x08;}
#define PWM22_ENABLE		{PWM22CON = 0x08;}
#define PWM23_ENABLE		{PWM23CON = 0x08;}
#define PWM24_ENABLE		{PWM24CON = 0x08;}
#define PWM25_ENABLE		{PWM25CON = 0x08;}

#define PWM30_ENABLE		{PWM30CON = 0x8f;}
#define PWM31_ENABLE		{PWM31CON = 0x08;}
#define PWM32_ENABLE		{PWM32CON = 0x08;}
#define PWM33_ENABLE		{PWM33CON = 0x08;}

#define PWM40_ENABLE		{PWM40CON = 0x8a;}
#define PWM41_ENABLE		{PWM41CON = 0x08;}
#define PWM42_ENABLE		{PWM42CON = 0x08;}
*/
///////////////////////disable led pwm output////////////////////////////////////////////////////

#define PWM00_DISABLE		(PWM00CON &= (~0X88))
#define PWM01_DISABLE		(PWM01CON &= (~0X08))
#define PWM02_DISABLE		(PWM02CON &= (~0X08))
#define PWM03_DISABLE		(PWM03CON &= (~0X08))
#define PWM04_DISABLE		(PWM04CON &= (~0X08))
#define PWM05_DISABLE		(PWM05CON &= (~0X08))

#define PWM10_DISABLE		(PWM10CON &= (~0X08))
#define PWM11_DISABLE		(PWM11CON &= (~0X08))
#define PWM12_DISABLE		(PWM12CON &= (~0X08))
#define PWM13_DISABLE		(PWM13CON &= (~0X08))
#define PWM14_DISABLE		(PWM14CON &= (~0X08))
#define PWM15_DISABLE		(PWM15CON &= (~0X08))

#define PWM20_DISABLE		(PWM20CON &= (~0X08))
#define PWM21_DISABLE		(PWM21CON &= (~0X08))
#define PWM22_DISABLE		(PWM22CON &= (~0X08))
#define PWM23_DISABLE		(PWM23CON &= (~0X08))
#define PWM24_DISABLE		(PWM24CON &= (~0X08))
#define PWM25_DISABLE		(PWM25CON &= (~0X08))

#define PWM30_DISABLE		(PWM30CON &= (~0X88))
#define PWM31_DISABLE		(PWM31CON &= (~0X08))
#define PWM32_DISABLE		(PWM32CON &= (~0X08))
#define PWM33_DISABLE		(PWM33CON &= (~0X08))

#define PWM40_DISABLE		(PWM40CON &= (~0X08))
#define PWM41_DISABLE		(PWM41CON &= (~0X08))
#define PWM42_DISABLE		(PWM42CON &= (~0X08))

///////////////////////disable led pwm output////////////////////////////////////////////////////
/*
#define PWM00_DISABLE		{PWM00CON = 0x07;}//(PWM00CON &= (~0X08))
#define PWM01_DISABLE		{PWM01CON = 0x00;}
#define PWM02_DISABLE		{PWM02CON = 0x00;}
#define PWM03_DISABLE		{PWM03CON = 0x00;}
#define PWM04_DISABLE		{PWM04CON = 0x00;}
#define PWM05_DISABLE		{PWM05CON = 0x00;}

#define PWM10_DISABLE		{PWM10CON = 0x07;}
#define PWM11_DISABLE		{PWM11CON = 0x00;}
#define PWM12_DISABLE		{PWM12CON = 0x00;}
#define PWM13_DISABLE		{PWM13CON = 0x00;}
#define PWM14_DISABLE		{PWM14CON = 0x00;}
#define PWM15_DISABLE		{PWM15CON = 0x00;}

#define PWM20_DISABLE		{PWM20CON = 0x07;}
#define PWM21_DISABLE		{PWM21CON = 0x00;}
#define PWM22_DISABLE		{PWM22CON = 0x00;}
#define PWM23_DISABLE		{PWM23CON = 0x00;}
#define PWM24_DISABLE		{PWM24CON = 0x00;}
#define PWM25_DISABLE		{PWM25CON = 0x00;}

#define PWM30_DISABLE		{PWM30CON = 0x02;}
#define PWM31_DISABLE		{PWM31CON = 0x00;}
#define PWM32_DISABLE		{PWM32CON = 0x00;}
#define PWM33_DISABLE		{PWM33CON = 0x00;}

#define PWM40_DISABLE		{PWM40CON = 0x02;}
#define PWM41_DISABLE		{PWM41CON = 0x00;}
#define PWM42_DISABLE		{PWM42CON = 0x00;}
*/
////////////////////////////////////////////////////////////////////////

//#define LOG_LED_ON   PWM33_ENABLE
//#define LOG_LED_OFF  PWM33_DISABLE
#endif
