
#ifndef	_HW_DEF_H_
#define	_HW_DEF_H_

#define Profile_Key	 0// 1		// SH68F88

/***********************************************/
//IO WAKE UP PD init
#define ENABLE_INT2  {IEN0|=0X08;}
#define ENABLE_INT3  {IEN0|=0X04;}

#define ENABLE_INT4  {IEN0|=0X02;}	
#define ENABLE_IO_INT  {IENC |= 0x4d;}	

#define     WDT_INIT            0
#define     CLRWDT()           (RSTSTAT = WDT_INIT)
#define EMS_USB_TIMEOUT		2000	// 400us*250=100ms

#define WHEEL1  P5_3
#define WHEEL2  P5_4
#define WHEEL_DirIn		P5CR &= ~0x18
#define WHEEL_PullEn	P5PCR |= 0x18


#define Key_0_DirIn		P0CR &= ~0xa0
#define Key_4_DirIn		P4CR &= ~0x1c
#define Key_6_DirIn		P6CR &= ~0x06
#define Key_7_DirIn		P7CR &= ~0xc1

#define Key_K1		P0_5	//L
#define Key_K2		P0_7	//R
#define Key_K3		P4_2	//M
#define Key_K4		P4_3	//4//
#define Key_K5		P7_0	//5
#define Key_K6		P6_1	// DPI+
#define Key_K7		P6_2    // DPI-
#define Key_K8		P4_4	//5
#define Key_K9		P7_7	// 4
#define Key_K10		P7_6	//5

//================================================================================/
//========A9800     

#define Sensor_A9800_IODir_Init		{ P7PCR |= 0x0C;P6PCR |= 0x01;} 
//#define Sensor_A9800_IOPULL			{ P7PCR |= 0x18;P6PCR |= 0x01;} 

#define NCS_ADNS			P6_0
#define NCS_ADNS_Out0				{ P6_0 = 0; P6CR |= 0x01; P6_0 = 0;}
#define NCS_ADNS_Out1				{ P6CR &= ~0x01;P6_0 = 1;}
#define MISO_ADNS			P7_1
#define SCLK_ADNS			P7_3
#define SCLK_ADNS_Out0				{ P7_3 = 0; P7CR |= 0x08; P7_3 = 0; }
#define SCLK_ADNS_Out1				{ P7CR &= ~0x08; P7_3 = 1; }
#define MOSI_ADNS			P7_2
#define MOSI_ADNS_Out0				{ P7_2 = 0; P7CR |= 0x04; P7_2 = 0; }
#define MOSI_ADNS_Out1				{ P7CR &= ~0x04;P7_2 = 1; }


//========A3050     
#define A3050_NCS_Out0				{ P6_0 = 0; P6CR |= 0x01; P6_0 = 0;}
#define A3050_NCS_Out1				{ P6CR &= ~0x01; P6_0 = 1; }
#define A3050_MOSI_Out0				{ P7_2 = 0; P7CR |= 0x04; P7_2 = 0; }
#define A3050_MOSI_Out1				{ P7CR &= ~0x04; P7_2 = 1; }
#define A3050_SCLK_Out0				{ P7_3 = 0; P7CR |= 0x08; P7_3 = 0; }
#define A3050_SCLK_Out1				{ P7CR &= ~0x08;	P7_3 = 0; }

#define Sensor_A3050_IODir_Init		{ P7CR |= 0x0C;P6CR |= 0x01;} 
//#define Sensor_A3050_IOPULL			{ P7PCR |= 0x0C;P6PCR |= 0x01;} 


//#if 0
//------ 0:input  1:output
#define A5050_SDIO_ADNS		P7_1
#define A5050_SDIO_ADNS_DirIn		{ P7CR &= ~0x02;}
#define A5050_SDIO_ADNS_Out0		{ P7CR |= 0x02;P7_1 = 0;}
#define A5050_SDIO_ADNS_Out1		{ P7CR &= ~0x02;P7_1 = 0;}

#define A5050_NRSET_ADNS	P7_2
#define A5050_NRSET_ADNS_Out0		{ P7_2 = 0; P7CR |= 0x04; P7_2 = 0; }
#define A5050_NRSET_ADNS_Out1		{ P7_2 = 1; P7CR &= ~0x04; P7_2 = 1; }
#define Sensor_A5050_IODir_Init		{ P7CR &= ~0x0C;P6CR &= ~0x01;}
//#define Sensor_A5050_IOPULL			{ P7PCR |= 0x18;P6PCR |= 0x01;}  



//#endif
//===A3320  VCC-3.3V
#define A3320_SDIO_ADNS		  P7_1
#define A3320_SDIO_ADNS_DirIn		{ P7CR &= ~0x02;}
#define A3320_SDIO_ADNS_Out0		{ P7CR |= 0x02;P7_1 = 0;}
#define A3320_SDIO_ADNS_Out1		{ P7CR &= ~0x02;P7_1 = 1;}

#define A3320_NCS_ADNS_Out0			{ P6_0 = 0; P6CR |= 0x01; P6_0 = 0;}
#define A3320_NCS_ADNS_Out1			{ P6CR &= ~0x01; P6_0 = 1; }
#define A3320_SCLK_Out0				{ P7_3 = 0; P7CR |= 0x08; P7_3 = 0; }
#define A3320_SCLK_Out1				{ P7CR &= ~0x08; P7_3 = 1; }

#define Sensor_A3320_IODir_Init		{ P7CR &= ~0x0C;P6CR &= ~0x01;}
//#define Sensor_A3320_IOPULL			{ P7PCR |= 0x18;P6PCR |= 0x01;} 


//===PAW3330

#define Sensor_P3330_IODir_Init	{ P7CR &= ~0x0C;P6CR &= ~0x01;}
//#define Sensor_P3330_IOPULL			{ P7PCR |= 0x0C;P6PCR |= 0x01;} 

//=======================================================================================================
#define LED_P6_VH 	P6 |= 0x38;


#define HIGH		1
#define LOW			0


#endif

