#ifndef	_SENSOR_H
#define	_SENSOR_H
#include ".\include\define.h"


#define  D_A9800_ID	0x33
#define  D_A3050_ID	0x09
#define  D_A5050_ID	0x12
#define  D_A3320_ID	0x3b
#define  D_P3330_ID	0x45
#define  D_P3360_ID	0x42
#define  D_P3610_ID	0x3E
#define  D_P3325_ID 0x43
#define  D_P3389_ID 0x47
#define  D_P3327_ID 0x4C 
#define  D_P3212_ID	0x30
#define  D_P3104_ID 0x31 
#define  D_P3333_ID 0x4C 



#define A9800_Support	0
#define A3050_Support	0
#define A5050_Support	0
#define A3320_Support	0
#define P3325_Support	1
#define P3327_Support	0

#define P3330_Support	0
#define P3360_Support	0
#define P3610_Support	0
#define P3212_Support 0
#define P3389_Support	0
#define P3333_Support	0



#define A9500_Support	0
#define A7550_Support	0
#define A7530_Support	0
#define A3090_Support	0
#define P3205_Support	0

#define P3104_Support	0

#define SensorType_Error	0x00



#if A5050_Support
	#define SensorType_A5050	0x01
#endif
#if A3050_Support
	#define SensorType_A3050	0x02
#endif
#if A9800_Support
	#define SensorType_A9800	0x03
#endif

#if A3320_Support
	#define SensorType_A3320	0x04
#endif

#if P3330_Support
	#define SensorType_P3330	0x05
#endif

#if P3360_Support
	#define SensorType_P3360	0x06
#endif

#if P3610_Support
	#define SensorType_P3610	0x07
#endif

#if P3212_Support
	#define SensorType_P3212	0x08
#endif

#if P3205_Support
	#define SensorType_P3205	0x09
#endif

#if P3325_Support
	#define SensorType_P3325	0x0B
#endif

#if P3327_Support
	#define SensorType_P3327	0x0e
#endif


#if P3389_Support
	#define SensorType_P3389	0x0f
#endif

#if P3104_Support
	#define SensorType_P3104	19
#endif

#if P3333_Support
	#define SensorType_P3333	21
#endif

//*********************************************************************************
//====A3050
#define A3050_DPI_500		0x01
#define A3050_DPI_750		0x02
#define A3050_DPI_1000		0x03
#define A3050_DPI_1250		0x04
#define A3050_DPI_1500		0x05
#define A3050_DPI_1750		0x06
#define A3050_DPI_2000		0x07
#define A3050_DPI_2500		0x08
#define A3050_DPI_3000		0x09
#define A3050_DPI_3500		0x0A
#define A3050_DPI_4000		0x0B

//====A5050
#define A5050_DPI_500		0x01
#define A5050_DPI_750		0x02
#define A5050_DPI_1000		0x03
#define A5050_DPI_1250		0x04
#define A5050_DPI_1375		0x05
#define A5050_DPI_1500		0x06
#define A5050_DPI_1750		0x07

#define A5050_DPI_2000		0x08
#define A5050_DPI_2500		0x09
#define A5050_DPI_2750		0x0A

//====A3320

#define A3320_DPI_500		0x01
#define A3320_DPI_750		0x02
#define A3320_DPI_1000		0x03
#define A3320_DPI_1250		0x04
#define A3320_DPI_1500		0x05
#define A3320_DPI_1750		0x06
#define A3320_DPI_2000		0x07
#define A3320_DPI_2250		0x08
#define A3320_DPI_2500		0x09
#define A3320_DPI_2750		0x0A
#define A3320_DPI_3000		0x0B
#define A3320_DPI_3250		0x0C
#define A3320_DPI_3500		0x0D
#define A3320_DPI_4000		0x0E
#define A3320_DPI_4500		0x0F
#define A3320_DPI_5000		0x10
#define A3320_DPI_6000		0x11
#define A3320_DPI_7000		0x12

//====P3325

#define P3325_DPI_500		0x01
#define P3325_DPI_800		0x02
#define P3325_DPI_1000		0x03
#define P3325_DPI_1200		0x04
#define P3325_DPI_1500		0x05
#define P3325_DPI_2000		0x06
#define P3325_DPI_2500		0x07
#define P3325_DPI_2800		0x08
#define P3325_DPI_3000		0x09
#define P3325_DPI_3200		0x0A
#define P3325_DPI_3500		0x0B
#define P3325_DPI_4000		0x0C
#define P3325_DPI_4500		0x0D
#define P3325_DPI_4800		0x0E
#define P3325_DPI_5000		0x0F
#define P3325_DPI_6000		0x10
#define P3325_DPI_7000		0x11
#define P3325_DPI_8000		0x12
#define P3325_DPI_9000		0x13
#define P3325_DPI_10000		0x14

//====A3050
#define P3104_DPI_250		0x01
#define P3104_DPI_500		0x02
#define P3104_DPI_750		0x03
#define P3104_DPI_1000		0x04
#define P3104_DPI_1250		0x05
#define P3104_DPI_1500		0x06
#define P3104_DPI_1750		0x07
#define P3104_DPI_2000		0x08
#define P3104_DPI_2250		0x09
#define P3104_DPI_2500		0x0A
#define P3104_DPI_2750		0x0B
#define P3104_DPI_3000		0x0C
#define P3104_DPI_3250		0x0D
#define P3104_DPI_3500		0x0E
#define P3104_DPI_3750		0x0F
#define P3104_DPI_4000		0x10
#define P3104_DPI_4500		0x11
#define P3104_DPI_5000		0x12
#define P3104_DPI_5500		0x13
#define P3104_DPI_6000		0x14
#define P3104_DPI_6500		0x15
#define P3104_DPI_7000		0x16
#define P3104_DPI_7500		0x17
#define P3104_DPI_8000		0x18
//====A9800

#define A9800_DPI_500		0x01
#define A9800_DPI_750		0x02
#define A9800_DPI_1000		0x03
#define A9800_DPI_1200		0x04
#define A9800_DPI_1600		0x05
#define A9800_DPI_1750		0x06
#define A9800_DPI_2000		0x07
#define A9800_DPI_2250		0x08
#define A9800_DPI_2400		0x09
#define A9800_DPI_2750		0x0a
#define A9800_DPI_3000		0x0b
#define A9800_DPI_3250		0x0c
#define A9800_DPI_3500		0x0d
#define A9800_DPI_3750		0x0e
#define A9800_DPI_4000		0x0f
#define A9800_DPI_4500		0x10
#define A9800_DPI_5000		0x11
#define A9800_DPI_6000		0x12
#define A9800_DPI_7000		0x13
#define A9800_DPI_8200		0x14
#define A9800_DPI_16400		0x15

//====P3330

#define P3330_DPI_500		0x01
#define P3330_DPI_750		0x02
#define P3330_DPI_1000		0x03
#define P3330_DPI_1250		0x04
#define P3330_DPI_1500		0x05
#define P3330_DPI_1750		0x06
#define P3330_DPI_2000		0x07
#define P3330_DPI_2250		0x08
#define P3330_DPI_2500		0x09
#define P3330_DPI_2750		0x0a
#define P3330_DPI_3000		0x0b
#define P3330_DPI_3200		0x0c
#define P3330_DPI_3500		0x0d
#define P3330_DPI_4000		0x0e
#define P3330_DPI_4500		0x0f
#define P3330_DPI_5000		0x10
#define P3330_DPI_6000		0x11
#define P3330_DPI_7200		0x12
#define P3330_DPI_14400		0x13


//====P3360

#define P3360_DPI_500		0x01
#define P3360_DPI_800		0x02
#define P3360_DPI_1000		0x03
#define P3360_DPI_1200		0x04
#define P3360_DPI_1600		0x05
#define P3360_DPI_2000		0x06
#define P3360_DPI_2500		0x07
#define P3360_DPI_2800		0x08
#define P3360_DPI_3000		0x09
#define P3360_DPI_3200		0x0A
#define P3360_DPI_3500		0x0B
#define P3360_DPI_4000		0x0C
#define P3360_DPI_4500		0x0D
#define P3360_DPI_5000		0x0E
#define P3360_DPI_6000		0x0F
#define P3360_DPI_7000		0x10
#define P3360_DPI_8000		0x11
#define P3360_DPI_9000		0x12
#define P3360_DPI_10000		0x13
#define P3360_DPI_12000		0x14
#define P3360_DPI_24000		0x15


//====P3610

#define P3610_DPI_400		0x01
#define P3610_DPI_800		0x02
#define P3610_DPI_1000		0x03
#define P3610_DPI_1200		0x04
#define P3610_DPI_1600		0x05
#define P3610_DPI_2000		0x06
#define P3610_DPI_2400		0x07
#define P3610_DPI_2800		0x08
#define P3610_DPI_3000		0x09
#define P3610_DPI_3200		0x0a
#define P3610_DPI_4000		0x0b
#define P3610_DPI_4800		0x0c
#define P3610_DPI_5600		0x0d
#define P3610_DPI_6400		0x0e

//====P3212

#define P3212_DPI_500		0x01
#define P3212_DPI_750		0x02
#define P3212_DPI_1000		0x03
#define P3212_DPI_1200		0x04
#define P3212_DPI_1600		0x05
#define P3212_DPI_2000		0x06
#define P3212_DPI_2400		0x07
#define P3212_DPI_3000		0x08
#define P3212_DPI_3200		0x09
#define P3212_DPI_3500		0x0a
#define P3212_DPI_4000		0x0b
#define P3212_DPI_4500		0x0c
#define P3212_DPI_5000		0x0D
#define P3212_DPI_5500		0x0E
#define P3212_DPI_6000		0x0F
#define P3212_DPI_7200		0x10

//*********************************************************************************
extern void ms_delay(U16 x);

extern void delay(Word n);		// 18*(n+2)*Tsys
//*********************************************************************************

#if A3050_Support
	extern void A3050_init(void);
	extern void A3050_motion(void);
	extern void A3050_Shutdown(void);
	extern void A3050_wake_up(void);
	extern void write_A3050_DPI(void);
#endif

//******************************************************************************************
#if A5050_Support
	extern void A5050_init(void);
	extern void A5050_motion(void);
	extern void A5050_Shutdown(void);
	extern void A5050_wake_up(void);
	extern void write_A5050_DPI(void);

#endif

//******************************************************************************************
#if P3325_Support
	extern void P3325_init(void);
	extern void P3325_motion(void);
	extern void P3325_Shutdown(void);
	extern void P3325_wake_up(void);
	extern void write_P3325_DPI(void);
#endif
//******************************************************************************************
#if P3327_Support
	extern void P3327_init(void);
	extern void P3327_motion(void);
	extern void P3327_Shutdown(void);
	extern void P3327_wake_up(void);
	extern void write_P3327_DPI(void);
#endif

//******************************************************************************************
#if A3320_Support
	extern void A3320_init(void);
	extern void A3320_motion(void);
	extern void A3320_Shutdown(void);
	extern void A3320_wake_up(void);
	extern void write_A3320_DPI(void);
#endif
//******************************************************************************************
#if P3212_Support
	extern void P3212_init(void);
	extern void P3212_motion(void);
	extern void P3212_Shutdown(void);
	extern void P3212_wake_up(void);
	extern void write_P3212_DPI(void);
#endif

//******************************************************************************************
#if P3330_Support
	extern void P3330_init(void);
	extern void P3330_motion(void);
	extern void P3330_Shutdown(void);
	extern void P3330_wake_up(void);
	extern void write_P3330_DPI(void);
#endif
//******************************************************************************************

#if P3360_Support	
	extern void P3360_init(void);
	extern void P3360_motion(void);
	extern void P3360_Shutdown(void);
	extern void P3360_wake_up(void);
	extern void write_P3360_DPI(void);
#endif
	#if (P3360_Support||P3389_Support)
	extern void Sensor_Lift_Set(void);
#endif
//******************************************************************************************

#if P3389_Support	
	extern void P3389_init(void);
	extern void P3389_motion(void);
	extern void P3389_Shutdown(void);
	extern void P3389_wake_up(void);
	extern void write_P3389_DPI(void);
#endif

//******************************************************************************************
#if P3104_Support
	extern void P3104_motion(void);
	extern void P3104_Shutdown(void);
	extern void P3104_wake_up(void);
	extern void write_P3104_DPI(void);
#endif

//******************************************************************************************
#if P3333_Support
	extern void P3333_init(void);
	extern void P3333_motion(void);
	extern void P3333_Shutdown(void);
	extern void P3333_wake_up(void);
	extern void write_P3333_DPI(void);
#endif

//******************************************************************************************
extern void sensor_init(void);
extern void sensor_wake_up(void);
extern void sensor_Shutdown(void);
extern void DPI_Process(void);
extern void sensor_motion_read(void);

//extern void LOD_Init(void);

//extern void LOD_hight_correct(void);

//extern void LOD_hight_Changed(void);

//******************************************************************************************

#endif
