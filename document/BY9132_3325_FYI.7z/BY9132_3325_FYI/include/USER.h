#ifndef	__USER_H__
#define	__USER_H__

/**********************
* TYPEDEFS		      *
**********************/
#define bool						bit
//#define BYTE		                unsigned char
//#define INT8  		                signed char 
#define UINT8 		                unsigned char
//#define U8 		                    unsigned char
//#define INT16 		                signed int
//#define UINT16 		                unsigned int
//#define U16 		                unsigned int
//#define WORD                        unsigned int
//#define INT32 		                signed long
//#define UINT32 		                unsigned long
//#define U32 		                unsigned long


#define false  		    			0
#define true  		    			1
#define FALSE                       0
#define TRUE                        1
#define LOW                         0
#define HIGH                        1
#define PRESS   					1
#define RELEASE 					0
#define ENABLE  					1
#define DISABLE 					0

#define BIT7 (unsigned char)(1 << 7)
#define BIT6 (unsigned char)(1 << 6)
#define BIT5 (unsigned char)(1 << 5)
#define BIT4 (unsigned char)(1 << 4)
#define BIT3 (unsigned char)(1 << 3)
#define BIT2 (unsigned char)(1 << 2)
#define BIT1 (unsigned char)(1 << 1)
#define BIT0 (unsigned char)(1 << 0)
	
#define PIP0          BIT0
#define PIP1          BIT1
#define PIP2          BIT2
#define PIP3          BIT3
#define PIP4          BIT4
#define PIP5          BIT5
/********************senser***************************/
#define BK2401_CE     P5_5
#define BK2401_CSN		P5_6
#define BK2401_SCK		P7_4  
#define BK2401_MOSI		P7_2  
#define BK2401_MISO		P7_1
#define BK2401_IRQ		P2_2

typedef struct 
{
	U8 dpi_d;
  U8 dpi_f;	
}sensor_t;

/********************mosue report rate ***************************/
#define S_REPORTRATE_125		0x00
#define S_REPORTRATE_250		0x01
#define S_REPORTRATE_500		0x02
#define S_REPORTRATE_1000		0x03

typedef struct 
{
	U8 sensor_dpi;
	U8 report_rate;
	U8 led_control;
	U8 led_mode;
	U8 led_brightness;
	U8 led_rate;
	U8 led_red;
	U8 led_green;
	U8 led_blue;
}m_t;

typedef struct 
{
	U16 prog_key_addr;
	U16 prog_key_delay;
	U8 prog_key_idx;
	U16 prog_key_length;
}p_t;
typedef struct 
{
	U8 normal_key[8];
	U8 consumer_key[3];
	U8 normal_key_flag;
	U8 normal_key_press;
	U8 consumer_key_flag;
	U8 consumer_key_press;
}k_t;
/********************mosue report rate ***************************/
#define MOUSE_MODE_SECTOR      50
#define MOUSE_KEY_SECTOR      51
/************************************************function***********************************************/

#endif
