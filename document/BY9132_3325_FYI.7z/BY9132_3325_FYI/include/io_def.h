
#ifndef	_IO_DEF_H
#define	_IO_DEF_H

#include "..\include\mcu_def.h"
#include "..\include\SH68F91.h"
/////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////key scan define/////////////////////////////////////////////////
#define MS0_LINE_INPUT   {P0CR	&= Bin(01011111);P0PCR	|= Bin(10100000);}
#define MS1_LINE_INPUT   {P4CR	&= Bin(11100011);P0PCR	|= Bin(00011100);}
#define MS2_LINE_INPUT   {P5CR	&= Bin(11100111);P0PCR	|= Bin(00011000);}
#define MS3_LINE_INPUT   {P6CR	&= Bin(11000001);P0PCR	|= Bin(00111110);}
#define MS4_LINE_INPUT   {P7CR	&= Bin(11111110);P0PCR	|= Bin(00000001);}

#define WHEEL2		P5_4
#define WHEEL1		P5_3
#define WHEEL3		P6_4
#define WHEEL4		P6_5
#define L_KEY		P0_5
#define R_KEY		P0_7
#define M_KEY		P4_2
#define B_KEY		P4_3
#define H_KEY		P7_0
#define DPU_KEY		P6_1
#define DPD_KEY		P6_2
#define FIRE_KEY	P6_3
#define MODE_KEY	P4_4	
/***********************************************/
//IO WAKE UP PD init
#define ENABLE_INT2  {IEN0|=0X08;}
#define ENABLE_INT3  {IEN0|=0X04;}

#define ENABLE_INT4  {IEN0|=0X02;}	
#define ENABLE_IO_INT  {IENC |= 0x4d;}	
/********************************************************************************************/
/************************sensor**********************************************/
//Sensor
#define SENSOR_SCLK_OUTPUT     {P7CR	|= Bin(00001000);}
#define SENSOR_NCS_OUTPUT      {P6CR	|= Bin(00000001);}
//////////////////////////////////////////////
//Sensor

#define  SCLK       P7_3
#define  SDIO       P7_1
#define  NCS        P6_0


#define  SCLK_HIGH   {SCLK =1;}
#define  SCLK_LOW    {SCLK =0;}
#define  NCS_HIGH    {NCS =1;} 
#define  NCS_LOW     {NCS =0;}
#define  SDIO_HIGH   {SDIO = 1;}
#define  SDIO_LOW    {SDIO = 0;}



/********************************************************************************************/
/************************led**********************************************/
/************************LED SCAN define**********************************************/
/********************************************************************************************/
/*
      |  P2.0 | P2.1 | P2.2 | P2.3 |
driver|-------|------|------|------|
------|-------|------|------|------|
PWM33 |  -|-  | -|-  | -|-  | -|-  |
PWM32 |  -|-  | -|-  | -|-  | -|-  |
PWM32 |  -|-  | -|-  | -|-  | -|-  |
------|-------|------|------|------|
*/

#define PWM33_LINE_IDX   0
#define PWM32_LINE_IDX   1
#define PWM31_LINE_IDX   2
///////////////////RED LED/////////////////
#define ROW_RED     PWM33_LINE_IDX
#define ROW_GREEN   PWM32_LINE_IDX
#define ROW_BLUE    PWM31_LINE_IDX

///////////////////////LED LOGO////////////////////////////////////////

#define LOGO_RED     0
#define LOGO_GREEN   1
#define LOGO_BLUE    2








#endif
