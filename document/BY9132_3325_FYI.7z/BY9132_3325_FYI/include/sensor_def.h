
#ifndef	_SENSOR_DEF_H
#define	_SENSOR_DEF_H
/////////////////////////////////////////
//*****************************PWM3330 Registers**********************************
	/*															      //Default	 Value
#define PROD_ID_addr                         0x00					  
#define MOTION_addr                          0x02					  
#define DELTA_X_L_addr                       0x03					  
#define DELTA_X_H_addr                       0x04					  
#define DELTA_Y_L_addr                       0x05					  
#define DELTA_Y_H_addr                       0x06					  
#define SQUAL_addr                           0x07					  
#define PIXEL_SUM_addr                       0x08					  
#define MAXIMUM_PIXEL_addr                   0x09					 
#define MINIMUM_PIXEL_addr                   0x0A					  
#define SHUTTER_LOWER_addr                   0x0B					  
#define SHUTTER_UPPER_addr                   0x0C					  
#define CHIP_OBSERVATION_addr                0x15					  
#define BURST_MOTION_READ_addr               0x16					  
#define PIX_GRAB_STATUS_addr                 0x19					  
#define RESOLUTION_addr                      0x1B					  
#define ANGLE_SNAP_addr                      0x1E					 
#define AXIS_CONTROL_addr                    0x20					  
#define LIFTCUTOFF_CALIBRATION_CONTROL_addr  0x22					  
#define LIFTCUTOFF_CALIBRATION_STATUS_addr   0x23					  
#define RUN_DOWNSHIFT_addr                   0x24					  
#define REST1_PERIOD_addr                    0x25					  
#define REST1_DOWNSHIFT_addr                 0x26					  
#define REST2_PERIOD_addr                    0x27					  
#define REST2_DOWNSHIFT_addr                 0x28					  
#define REST3_PERIOD_addr                    0x29					  
#define PIX_GRAB_addr                        0x32					  
#define POWER_UP_RESET_addr                  0x3A					  
#define SHUTDOWN_addr                        0x3B					 
#define INV_PRODUCT_ID_addr                  0x3F					  
#define CONFIG_addr                          0x40					 
#define MIN_SQUAL_RUN_LCC_PAF_addr           0x4E					 
#define LCC_MSQ_addr                         0x70					  
#define LCC_SQTH_addr                        0x71					  
*/
//*****************************PWM3325 Registers**********************************


#define  PRODUCT_ID                       0X00
#define  S_MOTION                         0X02 
#define  DELTA_X_L                        0X03
#define  DELTA_X_H                        0X04
#define  DELTA_Y_L                        0X05
#define  DELTA_Y_H                        0X06
#define  SQUAL                            0X07
#define  PIXEL_SUM                        0X08
#define  MAXIMUM_PIXEL                    0X09
#define  MINIMUM_PIXEL                    0X0A
#define  SHUTTER_LOWER                    0X0B  
#define  SHUTTER_UPPER                    0X0C
#define  CHIP_OBSERVATION                 0X15
#define  BURST_MOTION_READ                0X16
#define  PIX_GRAB_STATUS                  0X19   
#define  RESOLUTION                       0X1B
#define  ANGLE_SNAP                       0X1E
#define  AXIS_CONTROL                     0X20 
#define  RUN_DOWNSHIFT                    0X24
#define  REST1_PERIOD                     0X25
#define  REST1_DOWNSHIFT                  0X26 
#define  REST2_PERIOD                     0X27
#define  REST2_DOWNSHIFT                  0X28
#define  REST3_PERIOD                     0X29
#define  PIX_GRAB                         0X32
#define  POWER_UP_RESET                   0X3A 
#define  SHUTDOWN                         0X3B
#define  INV_PRODUCT_ID                   0X3F
#define  P_CONFIG                         0X40



#endif
