#ifndef __USB_DEF_H
#define __USB_DEF_H

/******************************************************************************************
USB����
******************************************************************************************/

/* USB�豸���� */
//BIT7	���ݴ��䷽��	BIT6~BIT5	����		BIT4~BIT0	������
// 0	�������豸		0			��׼			0		�豸    		
// 1	�豸������		1			����			1		�ӿ�
//						2			��Ӧ��			2		�˵�
//						3			����			3		����
//					......			����
#define	HOST_TO_DEVICE			 	0x00
#define	DEVICE_TO_HOST			 	0x80
#define	STANDARD				 	0x00
#define	CLASS					 	0x20
#define	VENDOR					 	0x40
#define	DEVICE					 	0x00
#define	INTERFACE				 	0x01
#define	ENDPOINT				 	0x02
#define	OTHER					 	0x03

/* ��׼�豸������� */	
#define USB_GET_STATUS				0x00
#define USB_CLEAR_FEATURE			0x01
#define USB_SET_FEATURE				0x03
#define USB_SET_ADDRESS				0x05
#define USB_GET_DESCRIPTOR		0x06
#define USB_SET_DESCRIPTOR		0x07
#define	USB_GET_CONFIGURATION	0x08
#define	USB_SET_CONFIGURATION	0x09
#define	USB_GET_INTERFACE			0x0A
#define	USB_SET_INTERFACE			0x0B
#define USB_SYNCH_FRAME				0x0C

/* HID�豸��������� */	
#define HID_GET_REPORT				0x01
#define HID_GET_IDLE				0x02
#define HID_GET_PROTOCOL			0x03
#define HID_SET_REPORT				0x09
#define HID_SET_IDLE				0x0A
#define HID_SET_PROTOCOL			0x0B	

/* USB���������� */
#define	USB_DEVICE					0x01
#define	USB_CONFIGURATION			0x02
#define	USB_STRING					0x03
#define	USB_INTERFACE				0x04
#define	USB_ENDPOINT				0x05
	
/* �ַ������������� */	
#define STRING_LANGUAGE_ID		0x00
#define STRING_MANUFACTURER		0x01
#define STRING_PRODUCT			0x02
#define STRING_SERIAL_NUMBER	0x03
#define STRING_SINO				0xFF
	
/* HID�豸������ */
#define	USB_HID							0x21
#define	USB_REPORT						0x22


/* ENDPOINT1 ����ID���� */	
#define KEYBOARD_RID					1
#define ACPI_RID					    2
#define CONSUMER_RID					2
#define CONFIG_RID						3
#define General_RID						4
#define ISP_RID							5
#define	MatrixKey_RID					4
#define DPI_RID							7
#define Mode_RID						8




/* ��������ȡֵ */
#define REPORT_TYPE_INPUT   	1	
#define REPORT_TYPE_OUTPUT  	2
#define REPORT_TYPE_FEATURE 	3

//#define REMOTE_WAKEUP		0x02		//GET STATUS�����豸ʱ�����ص������ֽڵ�BIT1��Զ�̻��ѣ�BIT0���Թ���
#define DEVICE_REMOTE_WAKEUP		1
#define BOOT_PROTOCOL		0
#define REPORT_PROTOCOL		1


/* ��������״̬ */
#define DEVICE_TYPE					0
#define INTERFACE_TYPE				1
#define ENDPOINT_TYPE				2

/* EP0���� */
#define NEW_SETUP_PHASE				0x00
#define IN0_DATA_PHASE				0x01
#define OUT0_STATUS_PHASE			0x02
#define IN0_STATUS_PHASE			0x03
#define OUT0_LED_PHASE				0x0a
#define OUT0_ISP_PHASE				0x09

#define  OUT0_Mode_PHASE        	0x05 
#define  OUT0_General_PHASE     	0x04             
#define  OUT0_KeyMacro_PHASE    	0x06  



/* interface���� */
#define interface0_PHASE			0x00
#define interface1_PHASE			0x01




/* USB���BUFFER��ַ */
//#define OUT0_BUFFER_ADDRESS	  0x0A00
//#define IN0_BUFFER_ADDRESS	  0x0A08
//#define IN1_BUFFER_ADDRESS	  0x0A20
//#define IN2_BUFFER_ADDRESS	  0x0A70
#define OUT0_BUFFER_ADDRESS	  0x0b28
#define IN0_BUFFER_ADDRESS	  0x0b30
#define IN1_BUFFER_ADDRESS	  0x0b48
#define IN2_BUFFER_ADDRESS	  0x0ba8



/* ENDPOINT0 ���BUFFER */
#define EP0_MAX_SIZE					8

/* ��ȡ���������� */
#define GET_DEVICE_DESCRIPTOR	1
#define GET_CONFIG_DESCRIPTOR	2
#define GET_STRING_DESCRIPTOR	3

#define IN0_SET_READY		{ SFR2BANK1; EP0CON |= BIT2; SFR2BANK0; }
			
#define IN0_SET_STALL		{ SFR2BANK1; EP0CON |= BIT3; SFR2BANK0; }

#define IN0_CANCEL_STALL	{ SFR2BANK1; EP0CON &= ~BIT3; SFR2BANK0; }

#define OUT0_SET_READY_1	{ SFR2BANK1; EP0CON |= BIT0; SFR2BANK0; }

#define OUT0_SET_STALL		{ SFR2BANK1; EP0CON |= BIT1; SFR2BANK0; }

#define OUT0_CANCEL_STALL	{ SFR2BANK1; EP0CON &= ~BIT1; SFR2BANK0; }

#define IN1_SET_READY		{ SFR2BANK1; EP1CON |= BIT2; SFR2BANK0; }

#define IN1_SET_STALL		{ SFR2BANK1; EP1CON |= BIT3; SFR2BANK0; }

#define IN1_CANCEL_STALL	{ SFR2BANK1; EP1CON &= ~BIT3; SFR2BANK0; }

#define IN2_SET_READY		{ SFR2BANK1; EP2CON |= BIT2; SFR2BANK0; }

#define IN2_SET_STALL		{ SFR2BANK1; EP2CON |= BIT3; SFR2BANK0; }

#define IN2_CANCEL_STALL	{ SFR2BANK1; EP2CON &= ~BIT3; SFR2BANK0; }
	
/******************************************************************************************

						procedure  declare

******************************************************************************************/
void USB_INIT(void);
static void prep_ep0_in_dat(void);

static void stall_ep0(void);

static void clear_remote_wakeup(void);
static void clear_endpoint_halt(void);
static void set_remote_wakeup(void);
static void set_endpoint_halt(void);
static void set_address(void);
static void set_configuration(void);
static void set_interface(void);
static void set_descriptor(void);
static void get_device_status(void);
static void get_interface_status(void);
static void get_endpoint_status(void);
static void get_descriptor(void);
static void get_configuration(void);
static void get_interface(void);
static void get_report(void);
static void set_report(void);
static void USB_HID_SETIDLE(void);
static void USB_HID_GET_IDLE(void);
static void USB_HID_SETPROTOCOL(void);
static void USB_HID_GETPROTOCOL(void);
#endif
