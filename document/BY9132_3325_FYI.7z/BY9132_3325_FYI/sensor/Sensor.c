#include "..\include\sensor.h"
#include "..\include\Variable.h"


void Handle_Sensor_Angle(void);

U8 bdata sensor_data;
	sbit sensor_DI = sensor_data ^ 0;
	sbit sensor_DO = sensor_data ^ 7;


S16 xdata Temp_Int;
S16 xdata SumX = 0; //Old smoother parameters
S16 xdata PreX = 0;
S16 xdata SumY = 0;
S16 xdata PreY = 0;

S8 xdata Dyn_SM_NTH1;		//Hill, 2009.10.28
S8 xdata Dyn_SM_NTH2;

#define  Dyn_SM_PTH1 0x03
#define  Dyn_SM_PTH2 0x02

volatile bit fg_ASM;


void ms_delay(U16 x)
{
	U8 i,j;	
	while(x--)	
	{
		for(j=0;j<5;j++)
		for(i=0;i<255;i++)
		{
			_nop_();_nop_();
			_nop_();
		  	Resetflag = EMS_USB_TIMEOUT;
		}
	}
}


/*******************************avago_A3320*****************************************/
#if (A3320_Support||P3325_Support||P3212_Support||P3104_Support)
U8 Read_Sensor_A3320(U8 address)
{
	U8 i;
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3320_NCS_ADNS_Out0;
	A3320_SCLK_Out1;
	sensor_data = address;
	for(i=0; i<8; i++)
	{
		A3320_SCLK_Out0;
		if(sensor_DO)
		{
			A3320_SDIO_ADNS_Out1;
		}
		else
		{
			A3320_SDIO_ADNS_Out0;
		}
		sensor_data <<= 1;
		_nop_();_nop_();
		A3320_SCLK_Out1;
		_nop_();
	}
	delay(50);
	A3320_SDIO_ADNS_DirIn;
	for(i=0; i<8; i++)
	{
		A3320_SCLK_Out0;
		sensor_data <<= 1;
		_nop_();_nop_();
		A3320_SCLK_Out1;
		_nop_();
		sensor_DI = A3320_SDIO_ADNS;
	}
	A3320_NCS_ADNS_Out1;
	delay(1);
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
	return(sensor_data);
}
void Write_Sensor_A3320(U8 address, U8 wdata)
{
	U8 i;
   // switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3320_NCS_ADNS_Out0;
	A3320_SCLK_Out1;	
	sensor_data = (address | BIT7);		//set bit 7 to high (SPI write mode)
	for(i=0; i<8; i++)
	{
		A3320_SCLK_Out0;
		if(sensor_DO)
		{
			A3320_SDIO_ADNS_Out1;
		}
		else
		{
			A3320_SDIO_ADNS_Out0;
		}
		sensor_data <<= 1;
		_nop_();_nop_();
		A3320_SCLK_Out1;
		_nop_();
	}
	sensor_data = wdata;
	for(i=0; i<8; i++)
	{
		A3320_SCLK_Out0;
		if(sensor_DO)
		{
			A3320_SDIO_ADNS_Out1;
		}
		else
		{
			A3320_SDIO_ADNS_Out0;
		}
		sensor_data <<= 1;
		_nop_();_nop_();
		A3320_SCLK_Out1;
		_nop_();
	}
	delay(1);
	A3320_NCS_ADNS_Out1;
	A3320_SDIO_ADNS_DirIn;
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
	delay(50);
}
#endif


/**********************************************************/
#if (A3050_Support||P3327_Support||P3333_Support)
void Sensor_A3050_IOInit(void)
{
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3050_SCLK_Out1;
	A3050_NCS_Out1;
	Sensor_A3050_IODir_Init;
//	Sensor_A3050_IOPULL;
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
	delay(50);
}
#endif
#if A5050_Support
void Sensor_A5050_IOInit(void)
{
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A5050_NRSET_ADNS_Out0;		// Reset.
	delay(100);					// Reset low Pulse Width lest 250ns.
	A5050_NRSET_ADNS_Out1;		// Reset release.
	NCS_ADNS_Out1;
	SCLK_ADNS_Out1;
	A5050_SDIO_ADNS_Out1;
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
}
#endif

#if (A3320_Support||P3325_Support||P3212_Support||P3104_Support)
void Sensor_A3320_IOInit(void)
{
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3320_NCS_ADNS_Out1;
	A3320_SCLK_Out1;
	A3320_SDIO_ADNS_Out1;
	delay(30);
	A3320_NCS_ADNS_Out0;
	ms_delay(2);
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
}
#endif

#if (P3330_Support||P3360_Support)
void Sensor_P3330_IOInit(void)
{	
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3050_NCS_Out1;
	delay(10);	
	A3050_NCS_Out0;
	//switch_SFR_Bank0(); 	//*** Notice: to bank0
}	
#endif


#if (P3212_Support||P3104_Support)
void Sensor_Sync(void)
{
	A3320_SCLK_Out0;
	delay(30);
	A3320_SCLK_Out1;
	delay(30);		// 32ms
}
#endif


/**********************************************************/
void sensor_detect(void)
{
	U8 ID1;
	U8 i;

	sensor_type = SensorType_Error;
	
	#if (P3325_Support)
	if(sensor_type == SensorType_Error)
	{
		Sensor_A3320_IOInit();
		Write_Sensor_A3320(0x3A, 0x5A);		//Reset sensor
		delay(1000);//800us
		Write_Sensor_A3320(0x18, 0x39); 
		ms_delay(50);
		ms_delay(50);
		for(i=0;i<10;i++)
		{
			ID1 = Read_Sensor_A3320(0x00);			//Read Product ID, ensure IC
			if(ID1==D_P3325_ID)
			{
				sensor_type = SensorType_P3325;		//P3325
				break;
			}
		}
	}
	#endif	

	

	//*
	#if (A3050_Support||P3327_Support)
	if(sensor_type == SensorType_Error)
	{
		Sensor_A3050_IOInit();
		Write_A3050_Sensor(0x3A,0x5A);			//sensor reset
		ms_delay(50);
		for(i=0;i<10;i++)
		{
			ID1 = Read_A3050_Sensor(0x00);		//Read Product ID, ensure IC
			#if A3050_Support
			if(ID1 == D_A3050_ID)
			{
				sensor_type = SensorType_A3050;		//adns3050
				break;
			}
			#endif
			#if P3327_Support
			if(ID1==D_P3327_ID)
			{
				sensor_type = SensorType_P3327;		//P3327
				break;
			}
			#endif
		}
	}
	#endif
	
	
		
	

	sensor_type_save1 = sensor_type;
}

/**********************************************************/
void sensor_init(void)
{
	CLR_WDT();
	sensor_detect();
	switch(sensor_type)
	{

		#if A3050_Support
		case SensorType_A3050:			//a3050 init
			A3050_init();
			break;
		#endif
		
		#if A5050_Support
		case SensorType_A5050:			//a5050 init
			A5050_init();
			break;
		#endif
		
		#if P3325_Support
		case SensorType_P3325:			//P3325 init
			P3325_init();
			break;
		#endif

		#if P3212_Support
		case SensorType_P3212:			//P3212
			P3212_init();
			break;
		#endif

		#if P3327_Support
		case SensorType_P3327:			//P3327 init
			P3327_init();
			break;
		#endif

		#if P3360_Support
		case SensorType_P3360:			//P3360 init
			P3360_init();
			break;
		#endif

		#if P3333_Support
		case SensorType_P3333:			//P3333 init
			P3333_init();
			break;
		#endif

		#if P3104_Support
		case SensorType_P3104:			//P3104
			//P3104_init();
			break;
		#endif

		default:
			break;
	}
}
/**********************************************************/
/*void sensor_type_check()
{
	if(sensor_type != sensor_type_save1)
	{
		sensor_init();
	}
}
/**********************************************************/
#if 0
void automotion(void)
{
	testxynum++;
	testxynum &= 0x03;
	sensor_data_x = testxy[testxynum][0];
	sensor_data_y= testxy[testxynum][1];
}
#endif
/**********************************************************/
void sensor_motion_read(void)
{
	//sensor_type_check();
	if(fg_Sensor_OK)
	{
		switch(sensor_type)
		{
			
			#if A3050_Support
			case SensorType_A3050:			//a3050
				A3050_motion();
				break;
			#endif
			
			#if A5050_Support
			case SensorType_A5050:			//a5050
				A5050_motion();
				break;
			#endif

			#if P3325_Support
			case SensorType_P3325:			//PWM3325
				P3325_motion();
				break;
			#endif	

			#if P3212_Support
			case SensorType_P3212:			//P3212
				P3212_motion();
				break;
			#endif	

			#if P3327_Support
			case SensorType_P3327:			//PWM3327
				P3327_motion();
				break;
			#endif

			
			#if P3360_Support
			case SensorType_P3360:			//PWM3360
				P3360_motion();
				break;
			#endif

			#if P3104_Support
			case SensorType_P3104:			//P3104
				P3104_motion();
				break;
			#endif	

			#if P3333_Support
			case SensorType_P3333:			//P3333
				P3333_motion();
				break;
			#endif	
			
			case SensorType_Error:			// Sensor Type Error
			default:
				//automotion();
				break;
			}
		
	}

	if(sensor_data_x || sensor_data_y)
	{

		fg_mouse_send = 1;		
	}		
}
/**********************************************************/
void sensor_Shutdown(void)
{
	//sensor_type_check();
	if(fg_Sensor_OK)
	{
		switch(sensor_type)
		{
					
			#if A3050_Support
			case SensorType_A3050:			//a3050
				A3050_Shutdown();
				break;
			#endif
			
			#if A5050_Support
			case SensorType_A5050:			//a5050
				A5050_Shutdown();
				break;
			#endif
			
			#if P3325_Support
			case SensorType_P3325:			//P3325
				P3325_Shutdown();
				break;
			#endif

			#if P3212_Support
			case SensorType_P3212:			//P3212
				P3212_Shutdown();
				break;
			#endif

			#if P3327_Support
			case SensorType_P3327:			//P3327
				P3327_Shutdown();
				break;
			#endif

			#if P3360_Support
			case SensorType_P3360:			//P3360
				P3360_Shutdown();
				break;
			#endif
			
			#if P3104_Support
			case SensorType_P3104:			//P3104
				P3104_Shutdown();
				break;
			#endif

			#if P3333_Support
			case SensorType_P3333:			//P3333
				P3333_Shutdown();
				break;
			#endif
						
			default:
				break;
		}
	}
}
/**********************************************************/
void sensor_wake_up(void)
{
	//sensor_type_check();
	if(fg_Sensor_OK)
	{
		switch(sensor_type)
		{

			#if A3050_Support
			case SensorType_A3050:			//a3050
				A3050_wake_up();
				break;
			#endif
			#if A5050_Support
			case SensorType_A5050:			//a5050
				A5050_wake_up();
				break;
			#endif

			#if P3325_Support
			case SensorType_P3325:			//P3325
				P3325_wake_up();
				break;
			#endif

			#if P3212_Support
			case SensorType_P3212:			//P3212
				P3212_wake_up();
				break;
			#endif

			#if P3327_Support
			case SensorType_P3327:			//P3327
				P3327_wake_up();
				break;
			#endif

			#if P3360_Support
			case SensorType_P3360:			//P3360
				P3360_wake_up();
				break;
			#endif
			
			#if P3104_Support
			case SensorType_P3104:			//P3104
				P3104_wake_up();
				break;
			#endif

			#if P3333_Support
			case SensorType_P3333:			// P3333
				P3333_wake_up();
				break;
			#endif

			default:
				break;
		}
	}
}

/**********************************************************/
void DPI_Process(void)
{
	//sensor_type_check();
	if(fg_Sensor_OK)
	{
		switch(sensor_type)
		{			
			
			#if A3050_Support
			case SensorType_A3050:			//a3050
				write_A3050_DPI();
				break;
			#endif
			
			#if A5050_Support
			case SensorType_A5050:			//a5050
				write_A5050_DPI();
				break;
			#endif
			
			#if P3325_Support
			case SensorType_P3325:			//P3325
				write_P3325_DPI();
				break;
			#endif

			#if P3212_Support
			case SensorType_P3212:			//P3212
				write_P3212_DPI();
				break;
			#endif

			#if P3327_Support
			case SensorType_P3327:			//P3327
				write_P3327_DPI();
				break;
			#endif

			#if P3360_Support
			case SensorType_P3360:			//P3360
				write_P3360_DPI();
				break;
			#endif
			
			#if P3104_Support
			case SensorType_P3104:			//P3104
				write_P3104_DPI();
				break;
			#endif

			#if P3333_Support
			case SensorType_P3333:			//P3333
				write_P3333_DPI();
				break;
			#endif
		
			default:
				break;
		}
	}
}

