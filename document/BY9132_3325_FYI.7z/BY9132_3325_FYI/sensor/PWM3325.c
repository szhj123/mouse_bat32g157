
#include ".\include\sensor.h"
#include ".\include\Variable.h"

#if P3325_Support
#include ".\include\P3325.h"

extern U8 Read_Sensor_A3320(U8 address);

extern void Write_Sensor_A3320(U8 address, U8 wdata);


code U8 P3325_DPI[] =
{
	0x00,
	0x04,//200		1
	0x06,//300     	2
	0x08,//400     	3
	0x0b,//500     	4
	0x0d,//600     	5
	0x0f,//700     	6
	0x12,//800     	7
	0x14,//900     	8
	0x16,//1000     	9
	0x19,//1100     	10
	0x1b,//1200     	11
	0x1d,//1300     	12
	0x20,//1400     	13
	0x22,//1500     	14
	0x24,//1600     	15
	0x27,//1700     	16
	0x29,//1800     	17
	0x2b,//1900     	18
	0x2e,//2000     	19

	0x30,//2100     	20
	0x32,//2200     	21
	0x34,//2300     	22
	0x37,//2400		23
	0x39,//2500		24
	0x3b,//2600		25

	0x3e,//2700		26
	0x40,//2800		27
	0x42,//2900		28
	0x45,//3000		29
	0x47,//3100		30
	0x49,//3200		31
	0x4c,//3300		32
	0x4e,//3400		33
	0x50,//3500		34
	0x53,//3600		35
	0x55,//3700 		36
	0x57,//3800 		37
	0x5a,//3900 		38
	0x5c,//4000		39
	0x5e,//4100		40
	0x61,//4200		41
	0x63,//4300		42
	0x65,//4400		43
	0x68,//4500		44
	0x6a,//4600		45
	0x6c,//4700		46
	0x6f,//4800		47
	0x71,//4900		48
	0x73,//5000		49

	0x40,//5500		50
	0x45,//6000		51
	0x4c,//6500		52
	0x50,//7000         53
	0x57,//7500         54
	0x5c,//8000		55
	0x63,//8500       	56
	0x68,//9000		57
	0x6f,//9500		58
	0x73 //10000	59
};
code U8 register_3325[29][2] = 
{
    //Register Address, Value(Modify) Note, Value(Default)
    {0x78, 0x80},    
    {0x79, 0x80}, 
    {0x14, 0x80},

	{0x20, 0x40}, 
    {0x1a, 0x40},
    {0x47, 0x00}, 
    {0x48, 0x01},

	{0x60, 0x01},
    {0x69, 0x03}, 
    {0x1d, 0x90},

	{0x1b, 0x2e},
    {0x24, 0x05}, 
    {0x56, 0x00},

	{0x2c, 0x8a},
	{0x2d, 0x58},
    {0x40, 0x80}, 
    {0x7f, 0x01},
    {0x7a, 0x32}, 
    {0x6a, 0x93},
    {0x6b, 0x68},
    {0x6c, 0x71},
    {0x6d, 0x50},
    {0x7f, 0x00},
    {0x7f, 0x02},
    {0x29, 0x1c},
    {0x2a, 0x1a},
    {0x2b, 0x90},
    {0x40, 0x80},
    {0x7f, 0x00}
	
};


/*************************************************************/
void P3325_init(void)
{
	U8 i;
	i=Read_Sensor_A3320(0x02);
	i=Read_Sensor_A3320(0x03); 
	i=Read_Sensor_A3320(0x04);
	i=Read_Sensor_A3320(0x05); 
	i=Read_Sensor_A3320(0x06);
	for(i=0;i<29;i++)
	Write_Sensor_A3320(register_3325[i][0], register_3325[i][1]);		//Reset sensor
}
/*************************************************************/
void P3325_read_burst_data(void)
{
	U8 i,ck;
	//switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	A3320_NCS_ADNS_Out0;
	A3320_SCLK_Out1;
	sensor_data = Brust_motion_addr3325;
	for(i=0; i<8; i++)
	{
		A3320_SCLK_Out0;
		if(sensor_DO)
		{
			A3320_SDIO_ADNS_Out1;
		}
		else
		{
			A3320_SDIO_ADNS_Out0;
		}
		sensor_data <<= 1;
		_nop_();_nop_();
		A3320_SCLK_Out1;
		_nop_();
	}
	delay(50);
	A3320_SDIO_ADNS_DirIn;
	for(ck=0;ck<6;ck++)
	{
		for(i=0; i<8; i++)
		{
			A3320_SCLK_Out0;
			sensor_data <<= 1;
			_nop_();_nop_();
			A3320_SCLK_Out1;
			_nop_();
			sensor_DI = A3320_SDIO_ADNS;
		}
		burst_data[ck] = sensor_data;
	}
	delay(1);
	A3320_NCS_ADNS_Out1;
	//switch_SFR_Bank0(); 	//*** Notice: in bank0
}


void P3325_motion(void)
{
	P3325_read_burst_data();
	if(burst_data[0]&0x80)
	{
		if(burst_data[1] == 0)
			P3325_init();
		else
		{		
			sensor_data_x =	(S16)( burst_data[3]<<8 | burst_data[2] );
			sensor_data_y = (S16)( burst_data[5]<<8 | burst_data[4] );
			if(DPI_X>=50)
			{
				if(sensor_data_x & 0x8000)
				{
					if(sensor_data_x & 0x4000)
					{
						sensor_data_x <<= 1;
					}
					else
					{
						sensor_data_x = 0x8001;
					}
				}
				else
				{
					if( !(sensor_data_x & 0x4000) )
					{
						sensor_data_x <<= 1;
					}
					else
					{
						sensor_data_x = 0x7FFF;
					}
				}
				if(sensor_data_y & 0x8000)
				{
					if(sensor_data_y & 0x4000)
					{
						sensor_data_y <<= 1;
					}
					else
					{
						sensor_data_y = 0x8001;
					}
				}
				else
				{
					if( !(sensor_data_y & 0x4000) )
					{
						sensor_data_y <<= 1;
					}
					else
					{
						sensor_data_y = 0x7FFF;
					}
				}			
			}
		}			
	}
}

/*************************************************************/
void P3325_Shutdown(void)
{
	Write_Sensor_A3320(Shutdown_addr3325,0xB6);		//pd
}
/*************************************************************/

void P3325_wake_up(void)
{
	Write_Sensor_A3320(Power_UP_Reset_addr3325, D_POWERUP_RESET);		//Reset sensor
	delay(1000);//800us
	Write_Sensor_A3320(0x18, 0x39);	
	ms_delay(50);
	P3325_init();
}
/*************************************************************/
void write_P3325_DPI(void)
{
	if(fg_DPIShift)
	{
		DPI_X=DPI_Shift_Data;
	}
	else
	{	
		DPI_X=DPI_Buffer[Sensor_DPI-1];
	}
	Write_Sensor_A3320(Resolution_addr3325,P3325_DPI[DPI_X]);	//dpi 500
}
#endif
