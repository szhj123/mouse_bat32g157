#include ".\include\Variable.h"

U8 bdata wheel_now;
	sbit  wheel_now1 = wheel_now ^ 0;
	sbit  wheel_now2 = wheel_now ^ 1; 

U8 idata wheel_pre;
U8 idata wheel_status;

void Wheel_Handle(void)
{	
	if(!fg_scan_wheel)
	return;
	
	fg_scan_wheel=0;
	switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	WHEEL_DirIn;			// wheel direction input
	WHEEL_PullEn;			// enable wheel pull high 
	wheel_now = 0x00;
	wheel_now1 = WHEEL1;
	wheel_now2 = WHEEL2;
	switch_SFR_Bank0(); 	//*** Notice: to bank0 ***
	
	if(wheel_now != wheel_pre)
	{
		wheel_status = ((wheel_status << 2) & 0x3C) | (wheel_now & 0x03);
		switch(wheel_status)
		{
			case 0x38:
			case 0x07:
				{
					wheel_data++;
					fg_mouse_send = 1;
					break;
				}
			case 0x34:
			case 0x0B:
				{
					wheel_data--;
					fg_mouse_send = 1;
					break;
				}
		}
		wheel_pre = wheel_now;
	}
}
