#include ".\include\Variable.h"
#include ".\include\sensor.h"
#include ".\include\mouse_api.h"
#include ".\include\flash_driver.h"
#include ".\include\LedDriver.h"
#include ".\include\keycode.h"

U16 xdata fire_cnt;
U8 xdata  fire_period;
U8 xdata  fire_delay_time;

U16 xdata KB_fire_cnt;
U8 xdata  KB_fire_period;
U8 xdata  KB_fire_delay_time;

U8 xdata KB_code=0;

U8 xdata MS_button=0;

U8 data DPI_Shift_Data=0;


U8 xdata YaQiang_Count=0;

U8 xdata YaQiang_Number1=0;

U8 xdata YaQiang_Number2=0;


U8 xdata YaQiang_action_num=0;

U8 xdata YaQiang_Repeat_cnt=0;

U8 xdata YaQiang_data_addr=0;


volatile bit fg_fire_always=0;

volatile bit fg_Modeled=0;

volatile bit fg_YaQiang_2times=0;

volatile bit fg_Normal_FireKey=0;

U8 xdata Key_HoldTime=0;
volatile bit fg_Key_HoldTime=0;
/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void Clear_NormalKey(void)
{
	U8 i;
	for(i=0; i<7; i++)
	{
		normalkey_Buf[i] = 0x00;
	}		
}
/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void mouse_button_application(U8 button)
{
	if(fg_key_status)
	{
		Button_Mouse |= button;
	}
	else 
	{
		Button_Mouse &= ~button;
	}
	fg_mouse_send = 1;
}
/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void mouse_NormalButton_application(U8 button)
{
	if(fg_key_status)
	{
		Button_Mouse |= button;
		ProgSW_bkBuf[RdProgSW_TH] |= button;
		fg_mouse_send = 1;
		if(CurrentLedMode==10) fLedModeUpdata=1;
		
	}
}



/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void mouse_XY_application(U8 XY_data,U8 flag)
{
	if(fg_key_status)
	{
		if(flag)
		{
			sensor_data_x1=XY_data;
			if(XY_data&0x80)
			sensor_data_x1 = (0xff00|XY_data);
		}
		else
		{
			sensor_data_y1=XY_data;
			if(XY_data&0x80)
			sensor_data_y1 = (0xff00|XY_data);
		}
		fg_mouse_send = 1;
		
	}
}

/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void mouse_wheel_application(U8 wheel)
{
	if(fg_key_status)
	{
		wheel_data = wheel;
		fg_mouse_send = 1;
	}
}




/*****************************************************************************
* Function		: 	hot_key_send
* Description	:	       	
* Input			: 	
*****************************************************************************/
void hot_key_send(U8 wincode)
{
	if(wincode < 1)	
	return;
	
	if (fg_key_status)
	{
		normalkey_Buf[0] |= wincode;
		
		SystemKey_bkBuf[RdProgSW_TH]=wincode;
		fg_NormalKey_send = 1;
	}
}

/*****************************************************************************
* Function		: 	
* Description		: 												
* Input			: 	
*****************************************************************************/
void normal_key_send(U8 normalcode)
{
	U8 i;
	
	if(normalcode < 4)	
	return;

	if (fg_key_status)			//make 
	{
		for (i=1; i<7; i++)
		{
			if (!normalkey_Buf[i])
			{	
				normalkey_Buf[i] = normalcode;
		//		KeyNum_bkBuf[RdProgSW_TH]=i;
		//		NormalKey_bkBuf[RdProgSW_TH]=normalcode;
				break;
			}
		}
	}
	else 					//break			
	{
		for (i=1; i<7; i++)
		{
			if ( normalkey_Buf[i] == normalcode )
			normalkey_Buf[i] = 0x00;
		}
	} 
	fg_NormalKey_send = 1;
}

/*****************************************************************************
* Function		: 	SystemKey_send
* Description	:	       	
* Input			: 	
*****************************************************************************
void SystemKey_send(U8 wincode)
{
	if(wincode < 1)	
	return;
	
	if (fg_key_status)
	{
		normalkey_Buf[0] |= wincode;
		
		SystemKey_bkBuf[RdProgSW_TH]=wincode;
		fg_NormalKey_send = 1;
	}
}
/*****************************************************************************
* Function		: 	
* Description		: 												
* Input			: 	
*****************************************************************************
void NormalKey_send(U8 normalcode)
{
	U8 i;
	
	if(normalcode < 4)	
	return;

	if (fg_key_status)			//make 
	{
		for (i=1; i<7; i++)
		{
			if (!normalkey_Buf[i])
			{	
				normalkey_Buf[i] = normalcode;
				KeyNum_bkBuf[RdProgSW_TH]=i;
				NormalKey_bkBuf[RdProgSW_TH]=normalcode;
				break;
			}
		}
		fg_NormalKey_send = 1;
	}
}

/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************
void NormalKB_application(U8 wincode, U8 normalcode1)
{
	SystemKey_send(wincode);
	NormalKey_send(normalcode1);
}

/*****************************************************************************
* Function		: 
* Description	: 	
* Input			: 	
*****************************************************************************/
void KB_normal_application(U8 wincode, U8 normalcode1)
{
	hot_key_send(wincode);
	normal_key_send(normalcode1);
}







//*************************************************************************


