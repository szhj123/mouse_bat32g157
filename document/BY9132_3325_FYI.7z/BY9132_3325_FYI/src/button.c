#include ".\include\sensor.h"
#include ".\include\Variable.h"
#include ".\include\flash_driver.h"
#include ".\include\mouse_api.h"
#include ".\include\keycode.h"


U16 xdata key_pre=0;
U16 xdata key_current;
//U8 xdata Key_HoldTime;
//U8 xdata flag_KeyHold;
//U8 xdata flag_KeyRealse;
U8 xdata key_debounce_type;

U8 xdata debounce_delay;

#define F_DPI_KEY_DEBOUNCE  1
#define B_DPI_KEY_DEBOUNCE  2
extern volatile bit fg_Key_HoldTime;
extern U8 xdata Key_HoldTime;

/******************************************************************************
 *	void check_multiple_keys(void)
 *	Input: Null
 *	Output:
 *    Function: 
                                     4    +  DPI .............................�л��ر���
                                     5    +  DPI .............................������л�
 *****************************************************************************/
void check_multiple_keys(void)
{
	U16 F_M,B_M;
	F_M = key_current&0x0c;
	//B_M = key_current&0x14;
	B_M = key_current&0x21;
  	
	if((key_pre&0x21) != B_M )
	{
		if(B_M  == 0x21)	//
		{
				if(key_debounce_type == 0)
			{
				key_debounce_type =  F_DPI_KEY_DEBOUNCE;//
				if(!fg_Modeled)
				fg_LedMode_Hd      =  1;
			}
		}
		else
		{
			if(key_debounce_type ==  F_DPI_KEY_DEBOUNCE)
			{
				key_debounce_type = 0;
			}
		}	
	}	
	
	if((key_pre&0x0c) != F_M)
	{
		if(F_M == 0x0c)	// ǰ��+ ��
		{
	
			if(key_debounce_type == 0)
			{
				key_debounce_type =  B_DPI_KEY_DEBOUNCE;//
				ReportRate++;
				if(ReportRate>S_ReportRate_1000)
				ReportRate=S_ReportRate_125;
				
				ReportLED_Init();
				Save_Inf_Data();
			}
		}
		else
		{
			if(key_debounce_type ==  B_DPI_KEY_DEBOUNCE)
			{
				key_debounce_type = 0;
			}
		}	
	}	
	
	/*
	if((key_pre&0x14) != B_M)
	{
		if(B_M == 0x14)	// ����+ ��
		{
			if(key_debounce_type == 0)
			{
				key_debounce_type =  F_DPI_KEY_DEBOUNCE;//
				fg_RGBOFF=!fg_RGBOFF;
				if(!fg_RGBOFF)
				{
					if(fg_Modeled)
					Set_YaQiang_LED();
					else fLedModeUpdata=1;	
				}
				Save_Inf_Data();	
			}
		}
		else
		{
			if(key_debounce_type ==  F_DPI_KEY_DEBOUNCE)
			{
				key_debounce_type = 0;
			}
		}	
	}
	*/
}
 
/******************************************************************************
 *	void Scan_Key(void)
 *	Input: Null
 *	Output:
 *****************************************************************************/
void Scan_Key(void)
{
	U8 row_index;
	U16 change_map,mask,status=0;
	if(!fg_scan_key)
	return;
	
	fg_scan_key=0;
	Key_0_DirIn;
	Key_4_DirIn;
	Key_7_DirIn;
	Key_6_DirIn;
	delay(3);

	switch_SFR_Bank1(); 	//*** Notice: SFR of P5&P6 in bank1 ***
	if(!Key_K1) status |= 0x01;    // L
	
	if(!Key_K2) status |= 0x02;    // R
	
	if(!Key_K3) status |= 0x04;    // M
	
	if(!Key_K4) status |= 0x10;    // 4
	
	if(!Key_K5) status |= 0x08;    // 5

	if(!Key_K6) status |= 0x20;    // DPI +

	//if(!Key_K7) status |= 0x40;    //DPI -
	
	//if(!Key_K9) status |= 0x80;    // 5

	//if(!Key_K8) status |= 0x40;    //˫����

	//if(!Key_K10) status |= 0x200;    //4
	switch_SFR_Bank0(); 
	
	if(key_current != status)
	{
		key_current = status;	
		debounce_delay= 2;	
	}
	else
	{
		if(debounce_delay)
		debounce_delay--;
	}
	if(!debounce_delay)
	{
		debounce_delay=2;
		check_multiple_keys();
		if(key_pre != key_current)
		{
			change_map = key_current ^ key_pre;
			for(row_index=0, mask=1; row_index<12; row_index++, mask<<=1)
			{
				if(change_map & mask)
				{
					RdProgSW_TH = row_index;
					if(key_current & mask)	fg_key_status = 1;
					else					fg_key_status = 0;	
					
					if(fg_key_status)
					{
						
						ProgramKey_Handle();
					}	
					else								// Break-Key 
					{
						fg_key_status=0;
									
						ProgramKey_Handle();
						
						Key_HoldTime=0;
						fg_Key_HoldTime=0;
					}
				}
			}
			key_pre = key_current;
		}	
		else
		{
			
		}
	}
}

