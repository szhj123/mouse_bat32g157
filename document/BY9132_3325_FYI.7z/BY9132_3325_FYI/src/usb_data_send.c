#include ".\include\Variable.h"
#include ".\include\usb.h"
//******************************************************************************
//*�˵�1�����ж�*
//******************************************************************************
void IN1_Prog(void)
{
	U8 xdata *EP1BUFFER_ADDR;
	if( (EP1CON&0x04)==0x00 )
	{
		if(fg_mouse_send)
		{	
			fg_mouse_send = 0;
			if(Protocol_type0 == REPORT_PROTOCOL)
			{
				IEP1CNT = 0x07;
				
				EP1BUFFER_ADDR = IN1_BUFFER_ADDRESS;
				
				*EP1BUFFER_ADDR++ = Button_Mouse&0x1f;
				*EP1BUFFER_ADDR++ = sensor_data_x+sensor_data_x1;
				*EP1BUFFER_ADDR++ = (sensor_data_x+sensor_data_x1)>>8;
				*EP1BUFFER_ADDR++ = sensor_data_y+sensor_data_y1;
				*EP1BUFFER_ADDR++ = (sensor_data_y+sensor_data_y1)>>8;
				*EP1BUFFER_ADDR++ = wheel_data;
				*EP1BUFFER_ADDR   = Tiltwheel;
				IN1_SET_READY;
			}
			else 
			{
				IEP1CNT = 0x03;
				EP1BUFFER_ADDR = IN1_BUFFER_ADDRESS;
				
				*EP1BUFFER_ADDR++ = Button_Mouse&0x07;
				*EP1BUFFER_ADDR++ = sensor_data_x+sensor_data_x1;
				*EP1BUFFER_ADDR   = sensor_data_y+sensor_data_y1;
				//*BUFFER_ADDR   = wheel_data;
				IN1_SET_READY;
			}
			sensor_data_x = 0;
			sensor_data_y = 0;
			sensor_data_x1= 0;
			sensor_data_y1= 0;
			wheel_data    = 0;
			Tiltwheel     = 0;
		}
	}
}


//******************************************************************************
//*�˵�2�����ж�*
//******************************************************************************
void IN2_Prog(void)
{
	U8 xdata *EP2BUFFER_ADDR;
	if( (EP2CON&0x04)==0x00 )
	{
		if(fg_NormalKey_send)
		{	
			fg_NormalKey_send = 0;
			if(Protocol_type1 == REPORT_PROTOCOL)
			{
				IEP2CNT = 0x08;
				EP2BUFFER_ADDR = IN2_BUFFER_ADDRESS;
	
				*EP2BUFFER_ADDR++ = KEYBOARD_RID;
				*EP2BUFFER_ADDR++ = normalkey_Buf[0];
				*EP2BUFFER_ADDR++ = normalkey_Buf[1];
				*EP2BUFFER_ADDR++ = normalkey_Buf[2];
				*EP2BUFFER_ADDR++ = normalkey_Buf[3];
				*EP2BUFFER_ADDR++ = normalkey_Buf[4];
				*EP2BUFFER_ADDR++ = normalkey_Buf[5];
				*EP2BUFFER_ADDR   = normalkey_Buf[6];
				IN2_SET_READY;
			}
		}
		else if(fg_DPI)
		{	
			fg_DPI = 0;
			if(Protocol_type1 == REPORT_PROTOCOL)
			{
				IEP2CNT = 0x08;

				EP2BUFFER_ADDR = IN2_BUFFER_ADDRESS;
				*EP2BUFFER_ADDR++ = DPI_RID;
				*EP2BUFFER_ADDR++ = Profile;
				*EP2BUFFER_ADDR++ = (sensor_type<<4)|(Sensor_DPI);
				*EP2BUFFER_ADDR++ = DPI_X;
				*EP2BUFFER_ADDR++ = DPI_Y;	
				*EP2BUFFER_ADDR++ = Lift_height;	
				*EP2BUFFER_ADDR++ = 0;	
				*EP2BUFFER_ADDR   = 0;	
				IN2_SET_READY;
			}
		}
		else if(fg_ConsumerKey_send)
		{
			fg_ConsumerKey_send = 0;
			if(Protocol_type1 == REPORT_PROTOCOL)
			{
				IEP2CNT = 0x04;
				EP2BUFFER_ADDR = IN2_BUFFER_ADDRESS;

				*EP2BUFFER_ADDR++ = CONSUMER_RID;
				*EP2BUFFER_ADDR++ = Consumer_Buf[0];
				*EP2BUFFER_ADDR++ = Consumer_Buf[1];
				*EP2BUFFER_ADDR   = Consumer_Buf[2];
				IN2_SET_READY;
			}
		}
	}
}

