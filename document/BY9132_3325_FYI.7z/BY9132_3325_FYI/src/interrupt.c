#include "..\include\SH68F91.h"
#include ".\include\define.h"
#include "..\include\USER.h"
#include "..\include\usb_def.h"
#include "..\include\CFG.h"
#include ".\include\Variable.h"
#include <intrins.h>
#include <string.h>
//////////////////////////////////////////////
extern void time_flag(void);
extern void rgb_led_con(void);
extern void led_mode_change(void);
extern U8 xdata led_on_change;
extern bit re_mote_wkup;
extern U16 xdata esd_sof_cnt;
extern bit esd_cnt_start_flag;

U16 idata Resetflag;

volatile U8 data Led_PCA00;
volatile U8 data Led_PCA01;
volatile U8 data Led_PCA02;
volatile U8 data Led_PCA10;
volatile U8 data Led_PCA11;
volatile U8 data Led_PCA12;
volatile U8 data Led_PCA13;

volatile U8 data Led_PCA33;
extern U8 xdata Pwm0PT;
extern U8 xdata Pwm1PT;
extern U8 xdata Pwm2PT;	   

code const U8 Led_Scan_Pin[3] =
{
	(1<<3),		// S01	P0_0
	(1<<4),		// S02	P0_1
	(1<<5),		// S03	P0_2
};

/////////////////////////////////////////////
void  T2_ISR(void)	interrupt  0
{ 
	

}
//////////////////////////////////////////////

//////////////////////////////////////////////////////////////
void  pwm2_ISR(void)	interrupt  10
{
	PWM20CON &= 0xdf;          //clr flag	
	esd_sof_cnt++;
	CLR_WDT();
}

/************************************************************************************
/////////////////////////////////////////////////////////////
void  pwm3_ISR(void)	interrupt  11
{
	
}

***********************************************************************************/


#ifdef	MODIFYED_20210319
void  pwm4_ISR(void)	interrupt  12
{

	
}
#endif

void  INT4_ISR(void)	interrupt  1
{
	 EXF1 = 0 ;
	 re_mote_wkup = 1;
}

void  INT3_ISR(void)	interrupt  2
{
	 EXF0 &= 0XFD ;
	re_mote_wkup = 1;
}

void  INT2_ISR(void)	interrupt  3
{
	 EXF0 &= 0XFE;
	re_mote_wkup = 1;
}
void USB_IRQ_Prog() interrupt 7
{
	

	
}
