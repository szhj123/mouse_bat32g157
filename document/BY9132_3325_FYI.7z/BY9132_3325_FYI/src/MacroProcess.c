#include ".\include\Variable.h"
#include ".\include\mouse_api.h"
#include ".\include\keycode.h"
#include ".\include\flash_driver.h"

U8 data Muse_button=0;


//*************************************************************************
