#include ".\include\Variable.h"

/****************************************************************************************/
code const U8 Password[4]=
{
	0x39, // 9
	0x36, // 6
	0x37, // 7
	0x36  // 6
};


/****************************************************************************************/
code const U8 LEDRGB11[7][3] = 
{
	{0xff,0x00,0x00},
	{0x00,0xff,0x00},
	{0x00,0x00,0xff},
	{0xff,0xff,0x00},
	{0xff,0x00,0xff},
	{0x00,0xff,0xff},
	{0xff,0xff,0xff},
};

code const U8 RGBLumin_TAB[5] = {0,2,5,7,10};

/****************************************************************************************/
volatile U8 xdata YaQiang_Macro[10]={0};

/****************************************************************************************/
U8 xdata LedPWMBuff[LED_MAX_MATRIX_COLUMN][4];//19�� RGB LED ; ����ǰ3��RGB����
/****************************************************************************************/
U8 xdata PaomaLedPosition[2];
/****************************************************************************************/
U8 xdata LedLastMode;		//����LED����ǰģʽ
U8 xdata LedLastLum;
U8 xdata LedLastSpeed;
U8 xdata LedLastColorMode; 

U8 idata CurrentLedMode;
U8 idata CurrentLedLumian;
U8 idata CurrentLedSpeed;
U8 idata CurrentLedColor;

volatile U16 idata CountTmp;
volatile U16 idata TimeCount1;
volatile U16 idata TimeCount2;

U8 idata DPI_BreathTime;

volatile U8 idata time_1ms_cn;
volatile U8 idata LedScanLine;

U8 data pwm_stage;
U8 data pwm_r,pwm_b,pwm_g;
U8 data PwmDutyCount;
U8 data pwm_max;


U8 data LedMode_cnt;

volatile bit fg_Invert=0;
volatile bit fUpDateLed=0;
volatile bit fLedModeUpdata=0;
volatile bit fLoadDefaulData=0;

volatile bit fg_LedMode_Hd=0;

U8 xdata Flash_Temp_Buf[250];

U8 idata ProgSW_bkBuf[16];
U8 xdata KeyNum_bkBuf[16];
U8 xdata NormalKey_bkBuf[16];
U8 xdata SystemKey_bkBuf[16];

U8 xdata ConsumerKey_bkBuf1[16];
U8 xdata ConsumerKey_bkBuf2[16];
U8 xdata ConsumerKey_bkBuf3[16];

//******************************************************************************************
U8 idata Consumer_Buf[3];
U8 idata normalkey_Buf[7];
//******************************************************************************************
volatile bit fg_mouse_send=0;
volatile bit fg_NormalKey_send=0;
volatile bit fg_ConsumerKey_send=0;
volatile bit fg_ConsumerKey_Press=0;
//******************************************************************************************
S8 data Tiltwheel;

U8 data DPI_X;
U8 data DPI_Y;
U8 data DPI_Steps;
U8 data Sensor_DPI;
U8 data sensor_type;
U8 data Sensor_Direction;
U8 data sensor_type_save1;
S16 data sensor_data_x,sensor_data_y;
S16 data sensor_data_x1,sensor_data_y1;

U8 xdata DPI_Buffer[16];

U8 idata burst_data[6];

volatile bit fg_XY_axes=0;

volatile bit fg_Sensor_OK=0;

volatile bit fg_DPI=0;

volatile bit fg_DPIShift=0;
//******************************************************************************************
U8 data Profile;
U8 data ReportRate;
U8 data Button_Mouse;
S8 data wheel_data;
U8 data RdProgSW_TH;

U16 xdata usb_int_cnt=0;

volatile bit fg_RGBOFF=0;
volatile bit fg_DPIOFF=0;

//******************************************************************************************
volatile bit fg_Firkey=0;

volatile bit fg_scan_key=0;

volatile bit fg_scan_wheel=0;

volatile bit fg_key_status=0;

//******************************************************************************************
U8 data Macro_Style=0;

U8 data macro_index=0;

U8 xdata MacroRealse_TH=0;


U8 data macro_action_num=0;

U16 data macro_send_addr=0;

U16 data macro_Repeat_cnt=0;

U16 idata Macro_Delay_Time=0;

volatile bit fg_macro_send=0;

volatile bit fg_macro_head=0;

volatile bit fg_medical=0;

//******************************************************************************************
U8 data Yaqiang_Style;

volatile bit Yaqiang_send;	

U8 xdata Yaqiang_RealseTH=0;

//******************************************************************************************

//volatile bit fg_LedPar=0; //ģʽ�����趨

//volatile bit fg_height_Changed=0; //�߶ȸ���

//volatile bit fg_correct=0;

//volatile bit fg_Mixture=0;

//U8 xdata LOD_Steps=0;

//U8 xdata LOD_height=0;

//volatile bit LOD_effect=0;

//volatile bit fg_PON=0;

//U16 xdata DPI_Flash_Period=0;

//U16 xdata DPI_limit_Period=0;

//volatile bit fg_DPILED_ON=0;

//volatile bit fg_DPILED_Flash=0;

volatile bit fg_DPIkey=0;

volatile bit fg_DebounceTime=0;

U8 xdata Key_DebounceTime=0;


U8 xdata Lift_height=0;

U8 xdata Lift_TMP=0;

U8 xdata Angle_snap=0;

U8 xdata Angle_snap_Tmp=0;



