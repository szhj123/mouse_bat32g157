#include "..\include\SH68F91.h"
#include ".\include\define.h"
#include "..\include\usb_db.h"
#include "..\include\mcu_def.h"
#include "..\include\usb_def.h"
#include <intrins.h>
#include <string.h>
#include "..\include\USER.h"
#include ".\include\variable.h"
#include ".\include\keycode.h"

U8 xdata	usb_irq_reg1;
U8 xdata usb_irq_reg2;
U8 xdata *isp_buffer_addr;
U8 xdata *in0_buffer_addr;
U8 xdata *out0_buffer_addr;
U8 xdata *out1_buffer_addr;
U8 xdata *in2_buffer_addr;
U8 xdata *out2_buffer_addr;
U8 xdata usb_rx_data[8];	
U8 xdata ep0_phase;
xdata U8 code *code_pt;
U16 xdata in0_dat_cnt;
U16 xdata usb_length;
volatile U16 data out0_dat_cnt;
data U8 code *code_ptr_feature;
bit device_remote_wakeup_f;
bit	fg_suspend;
data U8 get_mcu_id;
U8 xdata EP1_IDLE_TIME;
U8 xdata EP1_IDLE_COUNT;
U8 data Protocol_type0,Protocol_type1;
U16 xdata Suspend_Counter;
U8 xdata configution_value;
U8 xdata usb_config_flag;

U8 xdata *out_address;
U8 xdata out2_length;
extern bit esd_flag;
extern U16 xdata esd_sof_cnt;
extern xdata m_t mouse;
extern xdata k_t mouse_key;
volatile bit fg_Yaqiang_LED=0;

volatile bit fg_Profile_LED=0;
volatile bit fg_Profile_Key=0;
volatile bit fg_Macro_Key=0;

volatile bit fg_Profile=0;

volatile bit fg_LOD_Update=0;
U8 xdata RX0_buffer[8];
U8 xdata Data_cnt=0;
 /////////////////////////////////////////////////////////
extern void usb_init(void);
void isp_id_check(void);
extern void ISPJMP(void);
static void prep_ep0_out_dat(U8 *RXbuffer);
/******************************************************************************************
Code emu (���ú�����ַ)
******************************************************************************************/
code void (*request_func_table[]) (void) =
{
	stall_ep0,					     //0
	clear_remote_wakeup,		//1
	clear_endpoint_halt,		//2
	set_remote_wakeup,			//3
	set_endpoint_halt,			//4
	set_address,				    //5
	set_configuration,			//6
	set_interface,					//7
	set_descriptor,					//8
	get_device_status,			//9
	get_interface_status,		//10
	get_endpoint_status,		//11
	get_descriptor,					//12
	get_configuration,			//13
	get_interface,					//14
	get_report,							//15
	set_report,							//16
	USB_HID_SETIDLE,				//17
	USB_HID_GET_IDLE,				//18
	USB_HID_SETPROTOCOL,		//19
	USB_HID_GETPROTOCOL			//20
};
/******************************************************************************************
setup_request_index
******************************************************************************************/
enum setup_request_index
{
	stall_ep0_index,					//0
	ClearRemoteWakeup_index,	//1
	ClearEndpointHalt_index,	//2
	SetRemoteWakeup_index,		//3
	SetEndpointStall_index,		//4
	SetAddress_index,					//5
	SetConfiguration_index,		//6
	SetInterface_index,				//7
	SetDescriptor_index,			//8
	GetDeviceStatus_index,		//9
	GetInterfaceStatus_index,	//10
	GetEndpointStatus_index,	//11
	GetDescriptor_index,			//12
	GetConfiguration_index,		//13
	GetInterface_index,				//14
	GetReport_index,					//15
	SetReport_index,					//16
	USB_HID_SETIDLE_index,		//17
	USB_HID_GET_IDLE_index,		//18
	USB_HID_SET_PROTOCOL_index,	//19
	USB_HID_GET_PROTOCOL_index	//20
};
enum setup_request_index function_index;
/******************************************************************************************
SETUP data
******************************************************************************************/

const U8 code setup_req_table[] =
{
	HOST_TO_DEVICE | STANDARD | DEVICE,	USB_CLEAR_FEATURE,
	ClearRemoteWakeup_index,		// clear device feature 0x00, 0x01

	HOST_TO_DEVICE | STANDARD | ENDPOINT,	USB_CLEAR_FEATURE,
	ClearEndpointHalt_index,		// clear feature: clear endpoint halt //0x02, 0x01

	HOST_TO_DEVICE | STANDARD | DEVICE,	USB_SET_FEATURE,
	SetRemoteWakeup_index,			// set device feature 0x00, 0x03

	HOST_TO_DEVICE | STANDARD | ENDPOINT,	USB_SET_FEATURE,
	SetEndpointStall_index,			// set feature: set endpoint stall //0x02 0x03

	HOST_TO_DEVICE | STANDARD | DEVICE,	USB_SET_ADDRESS,
	SetAddress_index,				// set address 0x00, 0x05

	HOST_TO_DEVICE | STANDARD | DEVICE,	USB_SET_CONFIGURATION,
	SetConfiguration_index,			// set configuration 0x00, 0x09

	HOST_TO_DEVICE | STANDARD | INTERFACE,	USB_SET_INTERFACE,
	SetInterface_index,				// set interface 0x01, 0x0B

	HOST_TO_DEVICE | STANDARD | DEVICE,	USB_SET_DESCRIPTOR,
	SetDescriptor_index,			// set descriptor 0x00, 0x07

	DEVICE_TO_HOST | STANDARD | DEVICE,	USB_GET_STATUS,
	GetDeviceStatus_index,			// get device status :0x80 0x00

	DEVICE_TO_HOST | STANDARD | DEVICE,	USB_GET_DESCRIPTOR,
	GetDescriptor_index,			// get descriptor //0x80 0x06

	DEVICE_TO_HOST | STANDARD | INTERFACE,	USB_GET_DESCRIPTOR,
	GetDescriptor_index,			// get descriptor //0x81 0x06

	DEVICE_TO_HOST | STANDARD | DEVICE,	USB_GET_CONFIGURATION,
	GetConfiguration_index,			// get configuration //0x80 0x08

	DEVICE_TO_HOST | STANDARD | INTERFACE,	USB_GET_STATUS,
	GetInterfaceStatus_index,		// get interface status //0x81 0x00

	DEVICE_TO_HOST | STANDARD | ENDPOINT,	USB_GET_STATUS,
	GetEndpointStatus_index,		// get endpoint status //0x82 0x00

	DEVICE_TO_HOST | STANDARD | INTERFACE,	USB_GET_INTERFACE,
	GetInterface_index,				// get endpoint status //0x81 0x0A

	DEVICE_TO_HOST | CLASS | INTERFACE,	HID_GET_REPORT,
	GetReport_index,				// get report: 0xA1, 0x01

	HOST_TO_DEVICE | CLASS | INTERFACE,	HID_SET_REPORT,
	SetReport_index,				// set report: 0x21, 0x09

	HOST_TO_DEVICE | CLASS | INTERFACE,		HID_SET_IDLE,
	USB_HID_SETIDLE_index,			//set idle: 0x21, 0x0A

	DEVICE_TO_HOST | CLASS | INTERFACE,		HID_GET_IDLE,
	USB_HID_GET_IDLE_index,			//get idle: 0xA1, 0x02

	HOST_TO_DEVICE | CLASS | INTERFACE,		HID_SET_PROTOCOL,
	USB_HID_SET_PROTOCOL_index,		//set protocol: 0x21, 0x0b

	DEVICE_TO_HOST | CLASS | INTERFACE,		HID_GET_PROTOCOL,
	USB_HID_GET_PROTOCOL_index,		//get protocol: 0xA1, 0x03
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* USB_COMPUTER_PROCESS*/
extern U8 xdata mousedata[8];
extern const U8 code  testxy[4][2];
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void USB_QueryINT_Prog(void)
{

}


/******************************************************************************
USB emu task Prog

******************************************************************************/
/************************SETUP INT*******************************************/
void SETUP_IRQ_Prog(void)
{
	
}


/************************function_index = 0 (stall_ep0)/*stop out*//*******************************************/
static void stall_ep0(void)
{
	IN0_SET_STALL;
	OUT0_SET_STALL;
}


/************************function_index = 1 (clear_remote_wakeup)/*���Զ�̻���*//*******************************************/

static void clear_remote_wakeup(void)
{
	ep0_phase = NEW_SETUP_PHASE;

	if((usb_rx_data[0]&0x1f)==DEVICE_TYPE)
	{
		device_remote_wakeup_f = 0;
	}
	IN0_SetReady();
}

/************************function_index = 2 (clear_endpoint_halt)/*���EP0,EP1,EP2��ֹ������*//*********************/
static void clear_endpoint_halt(void)
{
	
}

/************************function_index = 3 (set_remote_wakeup)/*����Զ�̻���*//*******************************************/
 
static void set_remote_wakeup(void)
{

}

/************************function_index = 4 (set_endpoint_halt)/*����EP1��EP2ֹͣ����*//********************************/
static void set_endpoint_halt(void)
{
	
} 


/************************function_index = 5 (set_address)/*����USB��ַָ��*//********************************/

static void set_address(void)
{
	
}

/************************function_index = 6 (set_configuration)/*��������ָ��*//********************************/

static void set_configuration(void)
{
	
}

/************************function_index = 7 (set_interface)/*���ýӿ�ָ��*//********************************/
/*,interface0��mouse����,interface1�����б�׼����,��ý�����,ISP�ȶ��ֹ���*/

static void set_interface(void)
{
	
}


 /************************function_index = 8 (set_descriptor)//*����������,��֧��*///********************************/
 
static void set_descriptor(void)
{
	stall_ep0();
}


/************************function_index = 9 (get_device_status)//*��ȡ�豸״̬*///********************************/
 
static void get_device_status(void)
{
	
}

/************************function_index = 10 (get_interface_status)//*��ȡ�ӿ�״̬*///********************************/

static void get_interface_status(void)
{
	
} 

/************************function_index = 11 (get_endpoint_status)//*��ȡ�˵�״̬*///********************************/

static void get_endpoint_status(void)
{
	
}

/************************function_index = 12 (get_descriptor)//*��ȡ������*///********************************/

static void get_descriptor(void)
{
	if(usb_rx_data[3]==GET_DEVICE_DESCRIPTOR)			//��ȡ�豸������
	{
		code_pt = (U8 code *)device_descriptor;
		in0_dat_cnt = sizeof(device_descriptor);
		usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
		in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
	}
	else if(usb_rx_data[3]==GET_CONFIG_DESCRIPTOR)		//��ȡ����������
	{
		code_pt = (U8 code *)config_descriptor;
		in0_dat_cnt = sizeof(config_descriptor);
		usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
		in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
	}
	else if(usb_rx_data[3]==GET_STRING_DESCRIPTOR)		//��ȡ�ַ���������
	{
		if(usb_rx_data[2]==STRING_LANGUAGE_ID)				//����
		{
			code_pt = (U8 code *)str_dp_langID;
			in0_dat_cnt = sizeof(str_dp_langID);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[2]==STRING_MANUFACTURER)		//����
		{
			code_pt = (U8 code *)str_dp_manufact;
			in0_dat_cnt = sizeof(str_dp_manufact);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[2]==STRING_PRODUCT)				//��Ʒ
		{
			code_pt = (U8 code *)str_dp_product;
			in0_dat_cnt = sizeof(str_dp_product);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[2]==STRING_SERIAL_NUMBER)		//�汾��
		{
			code_pt = (U8 code *)str_dp_sn;
			in0_dat_cnt = sizeof(str_dp_sn);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[2]==STRING_SINO)				//��ӱ�豸����
		{
			code_pt = (U8 code *)str_dp_sino;
			in0_dat_cnt = sizeof(str_dp_sino);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else
		{
			stall_ep0();
			return;
		}
	}
	else if(usb_rx_data[3]==USB_REPORT)					//��ȡUSB����������
	{
		if(usb_rx_data[4] == 0)								//��ȡ�˵�1����������
		{
			code_pt = (U8 code *)HID_report_desc1;
			in0_dat_cnt = sizeof(HID_report_desc1);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[4] == 1)					//��ȡ�˵�2����������
		{
			code_pt = (U8 code *)HID_report_desc2;
			in0_dat_cnt = sizeof(HID_report_desc2);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else
		{
			stall_ep0();
			return;
		}
	}
	else if(usb_rx_data[3]==USB_HID)					//��ȡHID������
	{												
		if(usb_rx_data[4] == 0)								//��ȡHID1������
		{
			code_pt = (U8 code *)hid_descriptor1;
			in0_dat_cnt = sizeof(hid_descriptor1);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else if(usb_rx_data[4] == 1)					//��ȡHID2������
		{
			code_pt = (U8 code *)hid_descriptor2;
			in0_dat_cnt = sizeof(hid_descriptor2);
			usb_length = (usb_rx_data[7]<<8) | usb_rx_data[6];
			in0_dat_cnt = (usb_length<in0_dat_cnt)?usb_length:in0_dat_cnt;
		}
		else
		{
			stall_ep0();
			return;
		}
	}
	else
	{
		stall_ep0();
		return;
	}
	prep_ep0_in_dat();
	USBIF2 &= ~BIT0;
	IN0_SET_READY;
}

/************************function_index = 13 (get_configuration)//*��ȡ��������*///********************************/

static void get_configuration(void)
{
	
}


/************************function_index = 14 (get_interface)//*��ȡ�ӿ�����*///********************************/
  
static void get_interface(void)
{
	ep0_phase = OUT0_STATUS_PHASE;
	IEP0CNT &= ~0x0f;
	IEP0CNT = 1;
	in0_buffer_addr = IN0_BUFFER_ADDRESS;
	*in0_buffer_addr = 0;
	IN0_SET_READY;
}

/************************function_index = 15 (get_report)//*��ȡHID�豸����*///********************************/

static void get_report(void)
{
	
	if(get_mcu_id == 0xaa)
	{		
		get_mcu_id = 0;
    isp_id_check();
    return;
	}	
  switch(usb_rx_data[2]) 
	{
		case 0:
		{
			if( (usb_rx_data[5]==0x00) && (usb_rx_data[4]==interface0_PHASE) 		\
			 && (usb_rx_data[3]==REPORT_TYPE_OUTPUT) && (usb_rx_data[6]==0x00) )	//get LED status
			{
				
			}
			else
			{
				
			}		
		}
		break;
		
//////////////////////////////////////////////////////		
		case SENSOR_CONFIG_RID:	
		{
			if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
				
			}	
			else
				stall_ep0();	
		}
		break;
//////////////////////////////////////////////////////	
		case LED_CONFIG_RID:	
		{
			if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
				
			}	
			else
				stall_ep0();	
		}
		break;		
//////////////////////////////////////////////////////				
		case ProgKey_RID:
		{
			if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
				
				
			}	
			else
				stall_ep0();	
		}
		break;	
		
		case ISP_CTRL_RID:
			if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
				
			}
			else
				stall_ep0();
		break;
//////////////////////////////////////////////////////////	
	
	}
}

/************************function_index = 16 (set_report)//*����HID�豸����*///********************************/

static void set_report(void)
{
  switch(usb_rx_data[2])
	{
		case 0:
		{
			if( (usb_rx_data[3]==REPORT_TYPE_OUTPUT) && (usb_rx_data[4]==interface0_PHASE)		\
			 && (usb_rx_data[5]==0x00) && (usb_rx_data[6]==0x01) && (usb_rx_data[7]==0x00) )
			{
				
			}	
			else if( (usb_rx_data[3]==REPORT_TYPE_OUTPUT) && (usb_rx_data[4]==interface1_PHASE)		\
			 && (usb_rx_data[5]==0x00) && (usb_rx_data[6]==0x01) && (usb_rx_data[7]==0x00) )
			{
				
			}
			else
				stall_ep0();
		}
		break;
//////////////////////////////////////////////////////		
		case SENSOR_CONFIG_RID:	
		case LED_CONFIG_RID:
		{
		 if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{

			}	
			else
				stall_ep0();	
		}
		break;
		
		case ProgKey_RID:
		{
			if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
		
			}	
			else
				stall_ep0();	
		}
		break;	
//////////////////////////////////////////////////////////		
		case ISP_CTRL_RID:
		{
		 if((usb_rx_data[3]==REPORT_TYPE_FEATURE)&&(usb_rx_data[4]==interface1_PHASE))
			{
		
			}	
			else
				stall_ep0();
		}
		break;
		
		default:
				stall_ep0();
    break;
	}
}

/************************function_index = 17 (USB_HID_SETIDLE)//*����IDLE*///********************************/
 
static void USB_HID_SETIDLE(void)
{
	
}
/************************function_index = 18 (USB_HID_GET_IDLE)/ /*��ȡIDLE*///********************************/

static void USB_HID_GET_IDLE(void)
{
	
}

/************************function_index = 19 (USB_HID_SETPROTOCOL)/ /*����Э��*///********************************/

static void USB_HID_SETPROTOCOL(void)
{
	
}

/************************function_index = 20 (USB_HID_GETPROTOCOL)/ /*��ȡЭ��*///********************************/

static void USB_HID_GETPROTOCOL(void)
{
	
}


//******************************************************************************
//*USB�����ж�*
//******************************************************************************
void SUSPEND_IRQ_Prog(void)
{
	if(Suspend_Counter > 200)	 
	{
		fg_suspend = 1;
	}
	else
	{
		Suspend_Counter++;
	}	
}

//******************************************************************************
//*�˵�0����ж�*
//******************************************************************************
void OUT0_IRQ_Prog(void)
{

}
//******************************************************************************
//*�˵�0�����ж�*
//******************************************************************************
void IN0_IRQ_Prog(void)
{
	if(ep0_phase == IN0_DATA_PHASE)
	{
		
	}
	else if(ep0_phase == OUT0_STATUS_PHASE)
	{
	
	}
	else if(ep0_phase == IN0_TYPE_KEY_PHASE)
	{

	}
	else								//NEW_SETUP_PHASE
	{
	
	}
}

	
//******************************************************************************
//*�˵�1����ж�*
//******************************************************************************
/*
void OUT1_IRQ_Prog(void)
{	
	usb_out_mgr.entry_len[usb_out_mgr.in_index] = OEP1CNT;
	memcpy(&usb_out_buf[0][0],OUT1_BUFFER_ADDRESS,OEP1CNT);

	OUT1_SET_READY

}*/

//******************************************************************************
//*�˵�2����ж�*
//******************************************************************************
/*
void OUT2_IRQ_Prog(void)
{	
		;
}*/
//******************************************************************************
//*�˵�2�����ж�*
//******************************************************************************
/*
void IN2_IRQ_Prog(U8 *ctr, U8 len)
{
	U8 i;
	in2_buffer_addr = IN2_BUFFER_ADDRESS;

	for(i=0;i<len;i++)
	{
		in2_buffer_addr[i] = *ctr;
		ctr++;
	}

	IEP2CNT	= len;
	IN2_SET_READY;
}
*/
//******************************************************************************
//* USB task base define
//******************************************************************************
void get_out_usb_buffer(void)
{
	
}

void IN0_SetReady(void)
{

}

//void fill_in0_buf(U8 code *ctr, U8 len)
//{
//	
//}

static void prep_ep0_in_dat(void)
{
	
}


/*******************************************************************************/
void isp_id_check(void)
{
	
}


