#include ".\include\Variable.h"
#include ".\include\mouse_api.h"
#include ".\include\keycode.h"

/*****************************************************************************
 *	void ProgramKey_Handle(
 *	Input:
 *	Output:
 *
 ****************************************************************************/
void ProgramKey_Handle(void)
{
	U8 keydata_tab[4];
	if(Profile==1)
	{
		keydata_tab[0] = Key1Data_Buffer[4*RdProgSW_TH];
		keydata_tab[1] = Key1Data_Buffer[4*RdProgSW_TH+1];
		keydata_tab[2] = Key1Data_Buffer[4*RdProgSW_TH+2];
		keydata_tab[3] = Key1Data_Buffer[4*RdProgSW_TH+3];
	}
	else if(Profile==2)
	{
		keydata_tab[0] = Key2Data_Buffer[4*RdProgSW_TH];
		keydata_tab[1] = Key2Data_Buffer[4*RdProgSW_TH+1];
		keydata_tab[2] = Key2Data_Buffer[4*RdProgSW_TH+2];
		keydata_tab[3] = Key2Data_Buffer[4*RdProgSW_TH+3];
	}
	switch(keydata_tab[0])
	{
		case MS_TYPE:     mouse_NormalButton_application(keydata_tab[1]);						break;	
		case MS_WHEEL:    mouse_wheel_application(keydata_tab[1]);							    break;	
		case KB_Normal:   KB_normal_application(keydata_tab[1],keydata_tab[2]);					break;	
		default:  break;
	}
}
//*********************************************************************************************************

