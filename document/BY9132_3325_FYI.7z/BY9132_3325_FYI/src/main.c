#include "..\include\SH68F91.h"
#include ".\include\define.h"
#include "..\include\CFG.h"
#include <intrins.h>
#include <string.h>
#include "..\include\USER.h"
#include "..\include\usb_def.h"
//#include "..\include\key_decode.h"
#include "..\include\sensor.h"
#include ".\include\usb.h"
#include ".\include\Variable.h"
#include ".\include\sensor.h"
#include ".\include\mouse_api.h"
#include ".\include\LedDriver.h"
#include ".\include\flash_driver.h"
/////////////////////////////////////////////////////////
void init_data(void);
void PowerDown(void);
void delay_us(U16 cnt);
void pwm2_int_set_ms(U16 time_ms); //10ms
void pwm3_int_set_ms(U16 time_ms); //1100us

void pwm4_int_set_ms(U16 time_ms); //1100us
void esd_protect(void);
void disable_pwm_int(void);

//////////////////////////////////////////////////////////
U8 xdata mousedata[8];
UINT8 bdata  mcu_flag;
	sbit fg_1ms = mcu_flag^0;
	sbit fg_2ms = mcu_flag^1;
	sbit fg_4ms = mcu_flag^2;
	sbit fg_8ms = mcu_flag^3;
	sbit mouse_data_fg = mcu_flag^4;
	
U8 xdata tm2_cnt,tm4_cnt,tm8_cnt;
bit re_mote_wkup;
U16 xdata esd_sof_cnt;
bit esd_cnt_start_flag;
U8 xdata ck_DP_ST;
U8 xdata ck_DM_ST;
bit esd_flag;
xdata k_t mouse_key;
U8 xdata led_on_change;
////////////////////////////////////////////////////////////
extern void sensor_key_data_init(void);
extern void led_mode_change(void);
extern void led_init(void);
extern void shutdown_sensor(void);
extern void mouse_key_IN2(void);
extern void read_mouse_mode(void);
extern void led_mode_change(void);
extern void check_button(void);
extern void sys_init(void);
extern void wheel(void);
extern void MSdata_prepare();
extern void sensor_motion_read(void);
extern void sensor_init(void);
extern void shut_all_led(void);
extern void DPILED_Flash(void);
///////////////////////////////////////////////
extern bit device_remote_wakeup_f;
extern U8 xdata usb_config_flag;
extern U16 xdata Suspend_Counter;
extern bit	fg_suspend;
extern xdata p_t MouseKey;
extern xdata m_t mouse;
///////////////////////////////////////////////////////////
void Sensor_Scan(void)
{
	if(fg_1ms)
	{
		fg_1ms = 0;	
		if(ReportRate==S_ReportRate_1000)
		{
			sensor_motion_read();	
		}
	}
	if(fg_2ms)
	{
		fg_2ms = 0;
		if(ReportRate==S_ReportRate_500)
		{
			sensor_motion_read();
		}
	}
	if(fg_4ms)
	{
		fg_4ms = 0;
		if(ReportRate==S_ReportRate_250)
		{
			sensor_motion_read();
		}
	}
	if(fg_8ms)
	{
		fg_8ms = 0;
		if(ReportRate==S_ReportRate_125)
		{
			sensor_motion_read();
		}
	}
}
//=================================================

void main(void)
{
	EA = 0;
	sys_init();
	init_data();
////////////////////////
//	read_mouse_mode();               //mouse/LED init 
/////////////////////////
	pwm2_int_set_ms(10);		// 1ms��timer�� ������������


	pwm4_int_set_ms(2);			// PWMˢ�²���timer�� ��Լ300usһ��

	
	sensor_init();					// 3325 �������ĳ�ʼ��
	
	

	
	usb_init();
	
	EA = 1;
////////////////////////
	while(1)
	{

		CLR_WDT();
		
		if((fg_suspend)||(usb_int_cnt>10000))
		{
			usb_int_cnt = 0;
			PowerDown();			// USB����ģʽ�����԰�������sensor�������������������������豸��
		}	
		
//////////////////////////////////////////////////	
		if(usb_config_flag)
		{
			TR2 = 1;
			
			IN1_Prog();		//���������֣�XY λ�����ݣ����ϱ� EP1 �˵㡣�ر����д˿��ƣ�1ms �Ĳ�ѯ�����
			IN2_Prog();		//���̽ӿڣ�ð�ݶ˵�EP2�� �ϱ����̰����룬�Լ�DPI�ȶ������ݡ�		


			Wheel_Handle();	//���ֲ�ѯ
			Sensor_Scan();	//3325�ȴ�����λ�����ݶ�ȡ����
			Scan_Key();			//������ѯ


		}
	}
}

///////////////////////////////////////////////////////////////
void init_data(void)
{
  esd_flag = 0;
	fg_suspend = 0;
	led_on_change = 0;
	Suspend_Counter = 0;
	device_remote_wakeup_f = 0;
	mcu_flag =0;
	usb_config_flag = 0;
	esd_cnt_start_flag = 0;
	mouse_key.normal_key_flag = 0;
	mouse_key.consumer_key_flag = 0;
//	led_init();
}
/////////////////////////////////////////////////////////////////
void delay_us(U16 cnt)
{
		U16 i;
		for(i=0;i<cnt;i++)
		{
				_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
				CLR_WDT();
		}
}

///////////////////////////////ESD PROTECT	////////////////////////
void pwm2_int_set_ms(U16 time_ms) //10ms
{
	PWM20CON = 0x03;      // 3M
	PWM2PERDH = (U8)((time_ms*3000)>>8);
	PWM2PERDL = (U8)(time_ms*3000);	
	PWM20CON = 0xc3;      // 3M
	IEN1 &= ~0x08;   //enable pwm2 intrrupt
}
///////////////////////////////ESD PROTECT	////////////////////////
//void pwm3_int_set_ms(U16 time_ms) //10ms
//{
//	PWM30CON = 0x03;      // 3M
//	PWM3PERDH = (U8)((time_ms*300)>>8);
//	PWM3PERDL = (U8)(time_ms*300);	
//	PWM30CON = 0xc3;      // 3M
//	IEN1 |= 0x10;   //enable pwm3 intrrupt
//}

#ifdef MODIFYED_20210319
void pwm4_int_set_ms(U16 time_ms) //10ms
{
	PWM40CON = 0x03;      // 3M
	PWM4PERDH = (U8)((time_ms*300)>>8);
	PWM4PERDL = (U8)(time_ms*300);	
	PWM40CON = 0xc3;//|0x08;      // 3M
	IEN1 |= 0x20;   //enable pwm3 intrrupt
}
#endif


/****************************************************************************/
void PowerDown(void) 
{
	
}
