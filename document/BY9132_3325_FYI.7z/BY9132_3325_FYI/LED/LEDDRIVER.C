#include ".\include\Variable.h"
#include ".\include\LedDriver.h"

code const U8  M1_Count[5]={0,3,2,1,1};				//����

code const U16 M3_Count[5]={0,50,25,12,10};				//����  6S--4S--2S

code const U8  M5_Count[7]={0,15,8,4,1};		       //�޺�  5s---3s--1s

code const U16 M4_Count[4]={0,350,250,150};		   //��β

code const U16 M7_Count[4]={0,240,120,60};			//��˸

code const U16 M8_Count[4] ={0,300,200,100};		//���ǵ��

code const U16 M9_Count[4]={0,480,240,120};		  	//7�ʲ���

code const U16 M10_Count[5]={0,60,40,20,10};			//��Ӧ

extern void LedResponse_Init(void);


/*****************************************************************************
* Function		: 	
* Description		: 												
* Input			: 	
*****************************************************************************/
void SetPwmBuf(U8 r,U8 g,U8 b)
{		
	U8 i;
	for(i=0;i<LED_MAX_MATRIX_COLUMN;i++)	
	{		
		LedPWMBuff[i][0]=r;
		LedPWMBuff[i][1]=g;
		LedPWMBuff[i][2]=b;	
	}
}
/****************************************************************************/


/*****************************************************************************
* Function		: 	
* Description		: 												
* Input			: 	
*****************************************************************************/
void Led_Mode_Show(void)
{  

}
		
