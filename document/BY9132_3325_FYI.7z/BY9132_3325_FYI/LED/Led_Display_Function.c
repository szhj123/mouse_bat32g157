#include "..\include\Variable.h"

//extern U8 xdata YaQiang_Color[38];

U8 data tmp_r=0;
U8 data tmp_g=0;
U8 data tmp_b=0;

U8 xdata Pwm0PT=0;
U8 xdata Pwm1PT=0;
U8 xdata Pwm2PT=0;	   
U8 xdata PwmCnt=0;
U8 xdata PWM_Duty=0;

volatile bit fg_Breath_UP=0;// 0-->up


volatile bit fg_LED_ON=0;

volatile bit fg_LED_Flash=0;

U8 xdata LED_Flash_Cnt=0;

U16 xdata LED_Flash_Period=0;

U16 xdata LED_limit_Period=0;


/****************************************************************************
 *	void Set_LED_Param(U16 limit_period, U8 limit_cnt)
 *	Input:	limit_period limit_cnt
 *	Output:	
 *    ��LED ��˸Ƶ��/����
 ****************************************************************************/
void Set_LED_Param(U16 limit_period, U8 limit_cnt)
{
	LED_Flash_Period=limit_period;
	LED_limit_Period=limit_period;
	LED_Flash_Cnt=limit_cnt;

	fg_LED_ON=1;
	fg_LED_Flash=1;
	fLedModeUpdata=0;
}
//void TailLED_Changed_PWM(void)
//{
//	if((CurrentLedMode==4)||(CurrentLedMode==8))
//	{
//		PWM_AllLED_Off;
//		PWM0PL = PWM_PERIOD; // 4095/3MHz = 1365us
//		PWM0PH = 0; 
//		PWM1PL = PWM_PERIOD;
//		PWM1PH = 0;
//		PWM2PL = PWM_PERIOD;
//		PWM2PH = 0;
//	
//		PWM0CON = Bin(10110001);
//		PWM1CON = Bin(10110001);
//		PWM2CON = Bin(10110001);
//	}
//}
/********************************************************************
*  void  Set_DPI_LED(void)
*  ����:	   
*  DPI �������£�LEDָʾ
********************************************************************/
void Set_DPI_LED(void)
{
	
	if(fg_Sensor_OK)
	{
	
		Pwm0PT=DPI_color[3*(Sensor_DPI-1)+0];
		Pwm1PT=DPI_color[3*(Sensor_DPI-1)+1];
		Pwm2PT=DPI_color[3*(Sensor_DPI-1)+2];
		PwmCnt=0;
		PWM_Duty=0;
		fg_Breath_UP=0;
		
		tmp_r=DPI_color[3*(Sensor_DPI-1)+0];	// PCA2ģ��0	 R
		tmp_g=DPI_color[3*(Sensor_DPI-1)+1];
		tmp_b=DPI_color[3*(Sensor_DPI-1)+2];
		SetPwmBuf(tmp_r,tmp_g,tmp_b);		
		Set_LED_Param(310,3);
		
//		DPI_LED_Off;
//		if(DPI_color[3*(Sensor_DPI-1)+0])
//		DPI_RLED_ON;
//	
//		if(DPI_color[3*(Sensor_DPI-1)+1])
//		DPI_GLED_ON;
//	
//		if(DPI_color[3*(Sensor_DPI-1)+2])
//		DPI_BLED_ON;
	}
}
/*
void LED_TestMode_Show(void)
{
	switch(RdProgSW_TH)
	{
		case 0:
			SetPwmBuf(255,0,0);
		break;

		case 1:
			SetPwmBuf(0,255,0);
		break;

		case 2:
			SetPwmBuf(0,0,255);
		break;

		case 3:
			SetPwmBuf(255,255,0);
		break;

		case 4:
			SetPwmBuf(255,0,255);
		break;
		
		default:
		break;
	}
}

void LED_Enter_TestMode(void)
{
	if(fg_LED_Test)
	{
		SetPwmBuf(255,255,255);
		fLedModeUpdata=0;
	}
}*/

/********************************************************************
*  void  Set_YaQiang_LED(void)
*  ����:	   
*  DPI�Ƴ���3�룬�ص�������Ч
********************************************************************/
void Set_YaQiang_LED(void)
{
	fg_Modeled=1;
	fg_LED_Flash=0;
	fLedModeUpdata=0;
	
	tmp_r = YaQiang_Color[3*(YaQiang_Number1-1)+0];
  tmp_g = YaQiang_Color[3*(YaQiang_Number1-1)+1];	
    tmp_b = YaQiang_Color[3*(YaQiang_Number1-1)+2];
	
	SetPwmBuf(tmp_r,tmp_g,tmp_b);
//	TailLED_Changed_PWM();
}

/********************************************************************
*  void  ModeLED_Init(void)
*  ����:	   
*  
********************************************************************/
void ModeLED_Init(void)
{
	if(Profile==1)
	{
		tmp_r=255;
		tmp_g=0;	
		tmp_b=0;
	}
	else if(Profile==2)
	{
		tmp_r=0;
		tmp_g=0;	
		tmp_b=255;
	}
	SetPwmBuf(tmp_r,tmp_g,tmp_b);
	Set_LED_Param(320,3);
//	TailLED_Changed_PWM();
	
}


//#ifdef MODIFYED_20210322
void ReportLED_Init()
{
	
	if(fg_Sensor_OK)
	{
		tmp_r=255;//DPI_color[3*(Sensor_DPI-1)+0];	// PCA2ģ��0	 R
		tmp_g=255;//DPI_color[3*(Sensor_DPI-1)+1];
		tmp_b=255;//DPI_color[3*(Sensor_DPI-1)+2];
		SetPwmBuf(tmp_r,tmp_g,tmp_b);
		Set_LED_Param(300,3);
		
//		DPI_LED_Off;
//		if(DPI_color[3*(Sensor_DPI-1)+0])
//		DPI_RLED_ON;
//	
//		if(DPI_color[3*(Sensor_DPI-1)+1])
//		DPI_GLED_ON;
//	
//		if(DPI_color[3*(Sensor_DPI-1)+2])
//		DPI_BLED_ON;
	}
}


//#endif

