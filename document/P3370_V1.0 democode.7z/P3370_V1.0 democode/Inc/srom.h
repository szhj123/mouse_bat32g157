#include "Type.h"

extern U8 SROM[];
extern const U16 sromTableSize;

