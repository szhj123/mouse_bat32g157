#include "..\include\SH68F90.h"
#include "..\include\stdtype.h"
#include "..\include\mcu_def.h"
#include "..\include\key_decode.h"
#include "..\include\usb_def.h"
#include "..\include\pwm_control.h"
#include "..\include\auser.h"
extern U8 data	LED_status;
U8 xdata	Last_LED_status;
void updata_Status_Led(void)
{

	 /*
	if(!Mode_USB)
		return;
	if(Ready_ok)
		return;	
	if(LED_status!=Last_LED_status)
	{	
		Last_LED_status=LED_status;
		Module_Led_Data(LED_status);
	}
	 */
}












