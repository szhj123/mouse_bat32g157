#include "..\include\SH68F90.h"
#include "..\include\stdtype.h"
#include "..\include\mcu_def.h"
#include "..\include\pwm_control.h"
#include ".\include\Auser.h"
#include "..\include\CFG.h"
#include ".\include\ABSACC.H"
#include <intrins.h>
#include <string.h>
U8 xdata Image_Times;
bit b_Record_Mode;
